# Architecture decisions

| # | Decision | Why | Revisit when |
|---|---|---|---|
| 001 | **Supabase** (Postgres + PostGIS + Auth + Realtime + Edge Functions) | Small team, no servers to run, standard Postgres we can self-host later | > ~5k scans/minute sustained, or data-residency rules require self-hosting |
| 002 | **Critical logic in Postgres functions** (scan, ledger, redeem) | One transaction + hard constraints = no double points / negative stock even under races; ~4 ms per scan locally | if business rules need code the DB cannot express cleanly |
| 003 | **Scan only via edge function (service role)** | Edge adds IP rate limits, attestation, VPN intel; the DB function never trusts client claims | — |
| 004 | **Double-entry points ledger with funding wallets** | Every point has a payer; coverage is computable; reversals are exact | — |
| 005 | **Printed QR = derived opaque token, no signature** | Copying (not forging) is the threat; presence checks stop copies; derived tokens allow re-printing without storing secrets | — |
| 006 | **Risk tiers with step-up** instead of hard rejects | Better UX for honest users; fraud needs the physical cashier screen | — |
| 007 | **PWA first, native in Phase 2 by wrapping the same app with Capacitor** (replaces the earlier Expo plan) | One codebase for web/iOS/Android; native adds mock-location detection and device attestation | before Baghdad launch |
| 008 | **Subscription + campaigns billed per Generated Visit** | Merchant pays for measurable results; AMOUNI earns more as it delivers more | after pilot pricing data |
| 009 | **Big prizes on achievement, not chance** (e.g. most distinct verified places per district per month) | Lower legal risk than draws; rewards the core behaviour; harder to farm | needs legal review before launch |
| 010 | **Rules-based discovery with explanations; AI later behind rule checks** | Explainable, testable, no data yet to train on | after ~10k verified visits |
| 011 | **One web app, three lazy-loaded consoles** (user / merchant / admin) | One design system, one API client, one deploy; consoles don't bloat the user bundle (main ≈ 140 KB gzip) | if admin needs a separate domain/IP allow-list |
| 012 | **AI proposes, rules decide** (`ai_recommendations` + deterministic caps + audit) | Useful automation without giving a model authority over points, money or trust | after pilot data allows real models |
| 013 | **WhatsApp-first OTP with SMS fallback** via the Supabase Send-SMS hook | ~$0.02 vs ~$0.50 per SMS to Iraq; WhatsApp is near-universal | if WhatsApp template delivery rate drops |
| 014 | **Docker-free devstack** using the real GoTrue/PostgREST/Deno binaries | Same auth + API behaviour as production, runs anywhere Postgres runs | — |
| 015 | **Shared result codes** (`_shared/result_codes.ts` imported by web and edge) | One source of truth for error copy in Arabic/English | — |
