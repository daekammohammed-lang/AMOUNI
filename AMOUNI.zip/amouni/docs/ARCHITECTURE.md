# AMOUNI — Architecture (MVP)

> People physically discover places → scan a QR → prove presence → earn points → redeem → merchants see measurable visits.

## 1. System at a glance

```
 ┌───────────── clients ─────────────┐        ┌──────────────── Supabase (eu-central / Frankfurt) ────────────────┐
 │ User PWA  (→ Capacitor native)    │  JWT   │  Auth (phone OTP)                                                │
 │ Merchant web + Cashier mode       │ ─────▶ │  Edge Functions  /scan  /step-up   (validate, rate-limit, risk)  │
 │ Admin command center              │        │        │ service role                                            │
 └───────────────────────────────────┘        │        ▼                                                         │
              │  read-only RPCs (RLS)          │  PostgreSQL 15+ · PostGIS                                         │
              └──────────────────────────────▶ │   public  : tables (RLS, deny by default) + RPC functions         │
                                               │   private : secrets, config, trust weights, tokens (not exposed)  │
                                               │   pg_cron : release held · housekeeping · rotate QR · campaigns   │
                                               └────────────────────────────────────────────────────────────────────┘
```

**API-first.** Every screen (web, iOS, Android) talks to the same RPCs / edge functions. Nothing is tied to HTML.

## 2. Security model

1. **Tables are locked.** RLS is enabled and forced on every table. Clients may read only public catalogue data and their own rows (column-level grants hide trust scores, IPs, IQD values).
2. **Writes only through functions.** Each `SECURITY DEFINER` function validates the caller (`require_user`, `require_member`, `require_platform`), runs in one transaction, and writes `audit_log` for admin/merchant actions.
3. **The scan transaction is not client-callable.** `scan_v1` / `step_up_v1` are granted to `service_role` only. The `/scan` edge function authenticates the JWT, validates input (zod), rate-limits by IP, evaluates edge-only signals (VPN, device attestation) and then calls the database.
4. **Secrets live in `private`.** Printed QR tokens are *derived* (`HMAC(master, qr_id)`) and stored only as SHA-256; dynamic-QR keys, redeem codes, config and trust weights are never exposed. On Supabase, move `private.app_secrets` into Vault.
5. **Database constraints are the last line of defence** — even a bug in application code cannot:
   - pay a user twice for a spot (`scans_one_success_per_spot`),
   - double-post a ledger event (`ledger_tx unique(kind, ref_type, ref_id)`),
   - unbalance the ledger (deferred zero-sum trigger) or overdraw a wallet (`balance >= 0`),
   - sell more than the stock (`qty_left >= 0`, `stock >= 0`),
   - redeem a reward twice (`redemptions.bag_item_id unique`),
   - claim a mission twice (`mission_claims` primary key),
   - rewrite history (`ledger_*`, `audit_log` are append-only, also against TRUNCATE).

## 3. QR system

| Type | Content | Lifetime | Use |
|---|---|---|---|
| Printed | `https://amouni.app/q/<22-char token>` + short code `AM-XXXX-XX` | until rotated (monthly/weekly/manual); 24 h grace; `leak` kills instantly | normal spots |
| Cashier screen | `https://amouni.app/d/<branch_public_id>/<HMAC(window)>` | 30 s window, current + previous accepted; older = `DYNAMIC_STALE` | Golden Drops, step-up |
| Redemption | `AMR1.<token_id>.<secret>` + 6-digit code | 60 s, single use | redeem rewards |

**Why no signed payload on printed QRs:** the threat is *copying*, not forging. A signature does not stop a photo being shared; presence verification does. The token is an opaque random-equivalent secret that maps server-side to `qr → branch → spot`.

**Leak detection:** ≥ 3 distinct users scanning one QR from > 1 km within an hour → QR auto-disabled, merchant notified.

## 4. Proof of presence & trust

`trust = 100 − Σ signal weights` (weights in `private.trust_weights`, editable).

| Signal | Source |
|---|---|
| location_edge, gps_accuracy | GPS distance vs geofence, reported accuracy |
| no_session | no active hunt / nonce not presented |
| no_trail, arrival_too_fast | hunt start point, location pings, travel time |
| impossible_travel, velocity | scan history |
| shared_device | device fingerprint graph (HMAC-peppered) |
| new_account_high_value, low_account_trust, collusion | account history |
| qr_leak_suspect | far scans of the same QR |
| vpn_datacenter, mock_location, device_integrity_fail | edge function (IP intel, native attestation) |

| Trust | Decision | User sees |
|---|---|---|
| ≥ 71 | **valid** → points now | «لكيتها!» |
| 41–70 | **step_up** if the branch has a cashier screen (scan it within 10 min), else **held** 24 h | «خطوة أخيرة…» / «تتثبت خلال 24 ساعة» |
| 21–40 | **review** by an analyst | «نتأكد من مسحك» |
| ≤ 20 | **rejected** (spot not burned; a genuine retry works) | «ما كدرنا نتأكد» |

Skipping a step-up never leads to points: it falls to human review. Golden Drops additionally need GPS ≤ 50 m and an account older than 48 h.

## 5. Points economy (double-entry)

Every point comes from a funding wallet:

```
valid scan     amouni_marketing −80 −100   campaign −150        user_available +330
held scan      …same sources…                                    user_held      +330
release        user_held −330 → user_available +330
reverse        exact negation of the original entries (points return to their funders)
store purchase user_available −400 → store_sink +400
campaign       amouni_marketing −1500 → campaign wallet +1500 (funded on approval, unused returned on close)
```

- Quote = `min(base + active boosts + discovery, cap)`; lines are itemised and **locked 45 min** in the hunt.
- Caps: 500/scan (Drops by admin), 1,500/day (trimmed, then `DAILY_LIMIT`), one success per spot, one branch per 7 days.
- Coverage ratio = store value in points ÷ outstanding user points (alert below 1.2) — `admin_economy()`.
- If a campaign wallet runs dry mid-hunt, AMOUNI marketing honours the quoted points.

## 6. Merchant value

- **Generated Visit** = verified visit where the user viewed/started the spot in the last 24 h, had no verified visit at the merchant in 60 days, and is not staff.
- Campaigns: merchant describes a goal → AMOUNI approves → points wallet funded + boosts attached → each Generated Visit is billed at the agreed CPV (`merchant_charges`) → auto-complete at goal/budget/end.
- `merchant_stats()` returns generated vs returning visits, cost per Generated Visit, estimated revenue (from the merchant's average ticket), 30-day return rate and quiet hours.

## 7. Discovery (rules now, models later)

`score = points / (1 + km) + 50·new_category + 30·boost_active + 40·category_affinity`, halved when the place is above 80 % of capacity in the last hour (balance traffic — rank lower, never hide). One card per merchant. Every card carries an explainable `reason` (`near`, `hot`, `new_category`, `you_like`, `points`). Mystery spots return a circle (randomly offset centre), never the shop.

### 7.1 AI layer (built)

`job_ai_suggest` (pg_cron, every 30 min) writes **proposals** into `ai_recommendations`:
- `traffic_balance` — a branch is below `ai.quiet_ratio` of its usual traffic for this hour → propose a `quiet_place` boost.
- `campaign_tip` — plain-language advice shown on the merchant dashboard.

A deterministic rule check decides every proposal: merchant active, spot live, boost ≤ `ai.max_quiet_boost`, duration ≤ `ai.boost_hours`, total ≤ `ai.daily_boost_points` per day, funded from the marketing wallet. Proposals are only auto-applied when `ai.auto_apply = true`; otherwise an admin applies or dismisses them in the AI center. Every decision is audited. **The model never writes points, money or trust.**

## 7.2 Frontend

One React + TypeScript PWA (`apps/web`) serves three surfaces with lazy-loaded chunks: user app (`/app`), merchant console (`/merchant`, cashiers see only Cashier mode) and admin center (`/admin`, menu filtered by platform role). The client holds **no authority**: it calls RPCs/edge functions with the user's JWT, never computes points, never decides a scan, never stores state that matters (react-query cache only; `sessionStorage` holds just the hunt nonce, which the server verifies). Security lives in the DB (RLS + `require_*` checks inside each function); hiding a menu item is UX, not protection.

Native: the same app is wrapped with Capacitor for iOS/Android (adds Play Integrity / App Attest and mock-location detection — the edge already accepts those tokens).

## 7.3 Local devstack

`tools/devstack/devstack.mjs` runs the real Supabase pieces without Docker: GoTrue (phone OTP via the Send-SMS hook), PostgREST, Deno edge functions, and a gateway on `:54321` with the same paths as Supabase (`/auth/v1`, `/rest/v1`, `/functions/v1`). E2E tests run against it, so what is tested is what ships.

## 8. Privacy

Location is read only during a hunt/scan; movement pings are purged after 90 days; devices are stored as peppered HMACs; phone numbers are masked in admin views; users never see risk signals.

## 9. What is intentionally NOT in the MVP

Native attestation (Phase 2, via Capacitor), point-batch expiry FIFO (schema-ready, job pending), BLE/Wi-Fi presence, ML ranking, push/WhatsApp notification delivery (in-app inbox works, sender pending), invoicing, signup/invite rewards, Kurdish/English UI strings.
