"""
AMOUNI end-to-end: real browser → gateway → Supabase Auth (OTP) / PostgREST / edge functions → Postgres.
Run against the local stack (npm run stack:reset && npm run stack:up, after npm run build):
    python3 tests/e2e/e2e.py
Screenshots go to tests/e2e/shots/.
"""
import asyncio, os, re, subprocess, sys
from playwright.async_api import async_playwright, expect

BASE = os.environ.get('AMOUNI_URL', 'http://localhost:54321')
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shots'); os.makedirs(OUT, exist_ok=True)
PG = ['psql', '-h', os.environ.get('PGHOST', 'localhost'), '-p', os.environ.get('PGPORT', '54322'), '-U', 'postgres', '-d', os.environ.get('AMOUNI_DEV_DB', 'amouni_dev'), '-tAc']
SHOP = {'lat': 33.4229, 'lng': 43.2957}          # مطعم بيت الكص (seed branch 2)
errors: list[str] = []
# 1×1 transparent PNG: map tiles are served locally so the test never depends on the internet.
def _tile():
    import zlib, struct
    raw = b''.join(b'\x00' + bytes([0xE7, 0xE5, 0xF2]) * 256 for _ in range(256))
    chunk = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
    return b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', 256, 256, 8, 2, 0, 0, 0)) + chunk(b'IDAT', zlib.compress(raw)) + chunk(b'IEND', b'')
TILE = _tile()


def sql(q: str) -> str:
    return subprocess.check_output(PG + [q], text=True).strip()


async def context(browser, pos=SHOP, mobile=True):
    ctx = await browser.new_context(viewport={'width': 390, 'height': 844} if mobile else {'width': 1360, 'height': 900},
                                    device_scale_factor=2 if mobile else 1, locale='ar', permissions=['geolocation'],
                                    geolocation={'latitude': pos['lat'], 'longitude': pos['lng'], 'accuracy': 12})
    page = await ctx.new_page()
    page.on('pageerror', lambda e: errors.append(f'pageerror: {e}'))
    page.on('console', lambda m: errors.append(m.text) if m.type == 'error' and not re.search(r'openstreetmap|fonts\.g|ERR_FAILED|Failed to load resource', m.text) else None)
    await page.route('**/fonts.googleapis.com/**', lambda r: r.abort())
    await page.route('**/tile.openstreetmap.org/**', lambda r: r.fulfill(status=200, body=TILE, content_type='image/png'))
    return ctx, page


async def login(page, phone: str):
    await page.goto(f'{BASE}/login')
    await page.fill('input[autocomplete=tel]', phone)
    await page.click('button:has-text("أرسل الكود")')
    await page.click('text=اضغط لتعبئته', timeout=10_000)
    await page.click('button:has-text("دخول")')
    await page.wait_for_url(re.compile(r'/(app|welcome|merchant|admin)'), timeout=10_000)


async def shot(page, name, full=False):
    await page.wait_for_timeout(400)
    await page.screenshot(path=f'{OUT}/{name}.png', full_page=full)


async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()

        # ---------------- user: discover → hunt → scan → earn ----------------
        uctx, u = await context(b)
        await login(u, '07701234567')
        await expect(u.get_by_text('عندي لك 3 فرص اليوم')).to_be_visible()
        await shot(u, 'u01_home', True)
        await u.get_by_role('button', name=re.compile('مطعم بيت الكص')).first.click()
        await expect(u.get_by_text('النقاط اللي تاخذها')).to_be_visible(); await shot(u, 'u02_spot')
        await u.click('button:has-text("ابدأ اللقطة")')
        await expect(u.get_by_text('النقاط محجوزة')).to_be_visible(); await shot(u, 'u03_hunt')
        await u.click('button:has-text("امسح الباركود")')
        code = sql("select short_code from public.qr_codes where branch_id = '00000000-0000-4000-8004-000000000002' and status = 'active' limit 1")
        await u.fill('input[aria-label="الكود"]', code); await shot(u, 'u04_scan')
        await u.click('button:has-text("تحقق")')
        await expect(u.get_by_text('لكيتها!')).to_be_visible(timeout=10_000)
        await expect(u.get_by_text('+280').first).to_be_visible(); await shot(u, 'u05_found')
        assert sql("select count(*) from public.visits v join public.profiles p on p.id = v.user_id where p.phone = '9647701234567'") == '1'

        # same code again → server says already found
        await u.goto(f'{BASE}/app/scan'); await u.fill('input[aria-label="الكود"]', code); await u.click('button:has-text("تحقق")')
        await expect(u.get_by_text('لكيتها قبل')).to_be_visible(timeout=10_000); await shot(u, 'u06_already')

        # ---------------- user: store → bag → redeem code ----------------
        await u.goto(f'{BASE}/app/bag'); await u.click('button:has-text("متجر النقاط")')
        await u.get_by_role('button', name=re.compile('عصير طبيعي كبير')).click()
        await u.click('button:has-text("اشترِ بالنقاط")')
        await expect(u.get_by_text('انضافت لحقيبتك')).to_be_visible()
        await u.get_by_role('button', name='استبدل').first.click()
        await expect(u.get_by_text('يتجدد خلال')).to_be_visible(); await shot(u, 'u07_redeem')
        redeem_code = (await u.locator('.sheet .num').filter(has_text=re.compile(r'^\d{6}$')).first.inner_text()).strip()

        # ---------------- merchant: cashier redeems ----------------
        mctx, m = await context(b, mobile=False)
        await login(m, '07801112233')
        await m.goto(f'{BASE}/merchant'); await expect(m.get_by_text('شنو جابلك AMOUNI؟')).to_be_visible(timeout=10_000)
        await m.select_option('aside select', label='عصائر الواحة')
        await m.click('aside >> text=وضع الكاشير')
        await m.fill('input[aria-label="كود الزبون"]', redeem_code)
        await m.click('button:has-text("تأكيد الاستبدال")')
        await expect(m.get_by_text('عصير طبيعي كبير').first).to_be_visible(timeout=10_000); await shot(m, 'm01_redeemed')
        await expect(u.get_by_text('تم الاستبدال ✓')).to_be_visible(timeout=10_000); await shot(u, 'u08_redeemed')

        # ---------------- merchant: dashboard, QR, campaign ----------------
        await m.select_option('aside select', label='مطعم بيت الكص')
        await m.click('aside >> text=النتائج'); await expect(m.get_by_text('زبون جديد جابه AMOUNI')).to_be_visible(); await shot(m, 'm02_dashboard')
        await m.click('aside >> text=الباركود'); await expect(m.get_by_text(code)).to_be_visible(); await shot(m, 'm03_qr')
        await m.click('aside >> text=الحملات'); await m.click('button:has-text("حملة جديدة")')
        for _ in range(3): await m.click('.sheet button:has-text("التالي")')
        await expect(m.get_by_text('التقدير')).to_be_visible(); await shot(m, 'm04_wizard')
        await m.click('button:has-text("أرسل للموافقة")')
        await expect(m.get_by_text('بانتظار موافقة AMOUNI').first).to_be_visible(); await shot(m, 'm05_campaigns')

        # ---------------- admin: approve campaign, AI, audit ----------------
        actx, a = await context(b, mobile=False)
        await login(a, '07700000000')
        await a.goto(f'{BASE}/admin'); await expect(a.get_by_text('شنو صاير بالمدينة')).to_be_visible(timeout=10_000); await shot(a, 'a01_overview')
        await a.click('aside >> text=الحملات'); await a.click('button:has-text("موافقة")')
        await expect(a.get_by_text('شغّالة').first).to_be_visible(timeout=10_000); await shot(a, 'a02_campaigns')
        await a.click('aside >> text=اقتصاد النقاط'); await expect(a.get_by_text('نسبة التغطية')).to_be_visible(); await shot(a, 'a03_economy')
        await a.click('aside >> text=الثقة والاحتيال'); await shot(a, 'a04_trust')
        await a.click('aside >> text=الفرص والجوائز والمهام'); await shot(a, 'a05_catalog')
        await a.click('aside >> text=اقتراحات AI'); await a.click('button:has-text("حلّل هسه")'); await shot(a, 'a06_ai')
        await a.click('aside >> text=التدقيق والنظام'); await expect(a.get_by_text('campaign_approved').first).to_be_visible(); await shot(a, 'a07_audit')

        # the approved campaign now boosts the restaurant for a brand-new user
        nctx, n = await context(b)
        await login(n, '07709998877')
        await expect(n.get_by_text('خلّينا نتعرّف')).to_be_visible(); await shot(n, 'n01_onboarding')
        await n.fill('input[maxlength="40"]', 'سارة أحمد'); await n.click('button:has-text("التالي")')
        await n.click('button:has-text("تخطّي")'); await shot(n, 'n02_location')
        await n.click('button:has-text("بعدين")')
        await expect(n.get_by_text('هلا سارة')).to_be_visible(timeout=10_000)
        await n.get_by_role('button', name=re.compile('مطعم بيت الكص')).first.click()
        await expect(n.get_by_text('عرض المحل')).to_be_visible(); await shot(n, 'n03_spot_with_campaign')
        await n.goto(f'{BASE}/app/map'); await n.wait_for_timeout(1200); await shot(n, 'n04_map')
        await n.goto(f'{BASE}/app/missions'); await shot(n, 'n05_missions')
        await u.goto(f'{BASE}/app/profile'); await shot(u, 'u09_profile', True)
        await u.goto(f'{BASE}/app/history'); await shot(u, 'u10_history')

        # no horizontal overflow on phones
        for pg in (u, n):
            assert not await pg.evaluate('document.documentElement.scrollWidth > window.innerWidth'), 'horizontal overflow'
        await b.close()

    bad = [e for e in errors if 'favicon' not in e]
    if bad:
        print('Console errors:\n  ' + '\n  '.join(bad[:20])); sys.exit(1)
    print('✓ e2e passed — screenshots in', OUT)

asyncio.run(main())
