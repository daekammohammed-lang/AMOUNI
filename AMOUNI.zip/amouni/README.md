# AMOUNI

Real-world discovery & rewards platform for Iraq. People discover places, scan the AMOUNI QR inside, prove they were there, earn points and rewards. Merchants pay for measurable, verified visits.

```
amouni/
├─ apps/web/             ONE React PWA: user app (/app), merchant console (/merchant), admin center (/admin)
│  └─ src/
│     ├─ app/            routes, session, role guards
│     ├─ lib/            api client (RPC + edge), geo/device hooks, Arabic formatting
│     ├─ ui/             design system: kit, icons, map (MapLibre), QR image + camera scanner
│     └─ features/       public · user · merchant · admin  (lazy-loaded consoles)
├─ supabase/
│  ├─ migrations/        schema, ledger, scan pipeline, merchant, discovery, admin, security, app read-models + AI layer
│  ├─ functions/         edge: /scan, /step-up, /auth-sms-hook (WhatsApp → SMS OTP) + shared result codes
│  ├─ tests/             77 database tests (races, replay, fraud tiers, RLS, read models, AI caps)
│  └─ seed.sql           staging data (Ramadi pilot, fictional shops, 3 demo accounts)
├─ tests/e2e/            Playwright end-to-end through the real stack (user → merchant → admin)
├─ tools/devstack/       Docker-free local Supabase (GoTrue + PostgREST + Deno + gateway)
└─ docs/                 ARCHITECTURE.md · DECISIONS.md
```

## Run it locally

Requires Node 20+, PostgreSQL 15+ with PostGIS, Deno 2, Python 3.10+.
(Or use `supabase start` with the Supabase CLI + Docker — the app only needs `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.)

```bash
npm install
npm run stack:fetch     # downloads GoTrue + PostgREST binaries into .devstack/
npm run stack:reset     # creates DB amouni_dev: auth schema, migrations, seed
npm run stack:up        # API gateway on :54321, writes apps/web/.env.local
npm run dev             # app on http://localhost:5173
```

Env for the devstack: `PGHOST`, `PGPORT`, `AMOUNI_DEV_DB` (default `amouni_dev`).

Demo accounts (OTP code appears in the dev inbox button on the login screen):

| Phone | Role |
|---|---|
| 0770 123 4567 | user (علي حسين) |
| 0780 111 2233 | owner of the 11 pilot shops |
| 0770 000 0000 | super admin |

## Tests

```bash
export AMOUNI_PG="host=localhost port=5432 user=postgres"   # superuser connection
npm test             # typecheck + 77 DB tests + edge function checks/tests
npm run test:e2e     # full journey in Chromium against the running stack (needs stack:up + build)
npm run build        # production bundle in apps/web/dist
```

## Deploy to Supabase

1. Create a project (region **eu-central-1 / Frankfurt**, closest to Iraq).
2. Install the Supabase CLI, then inside the repo: `supabase init` (keeps existing migrations), `supabase link --project-ref <ref>`.
3. Database → Extensions: enable **pg_cron** (jobs schedule themselves on migrate).
4. `supabase db push` — applies all migrations. **Do not** run `seed.sql` in production.
5. Move `private.app_secrets` values into Vault (see ARCHITECTURE §2.4).
6. Auth → Hooks → **Send SMS hook** → `https://<ref>.supabase.co/functions/v1/auth-sms-hook`; set function secrets `SEND_SMS_HOOK_SECRET`, `WHATSAPP_TOKEN`, `WHATSAPP_PHONE_ID`, `WHATSAPP_OTP_TEMPLATE`, and the SMS fallback `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`. Never set `AMOUNI_DEV_OTP_INBOX` in production.
7. Edge functions: `supabase functions deploy scan step-up auth-sms-hook` and set secrets:
   `APP_ORIGIN`, optional `IPINFO_TOKEN`, `SCAN_IP_LIMIT_PER_MIN`; later `PLAY_INTEGRITY_VERIFIER_URL`, `APP_ATTEST_VERIFIER_URL`.
8. Frontend: `npm run build` with `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`, `VITE_MAP_STYLE` (a production vector style URL); host `apps/web/dist` on any static host (Cloudflare Pages / Vercel) with SPA fallback to `index.html`.
9. Grant the first admin: `insert into platform_roles (user_id, role) values ('<uuid>', 'super_admin');`

## API surface (summary)

| Who | Calls |
|---|---|
| Anyone | `discover_picks`, `discover_map`, `get_spot` |
| User | `complete_profile`, `start_hunt`, `hunt_ping`, `hunt_hint`, **POST /scan**, **POST /step-up**, `my_wallet`, `my_missions`, `claim_mission`, `my_discovery`, `buy_reward`, `issue_redeem_token` |
| Merchant | `merchant_apply`, `merchant_add_branch`, `merchant_add_staff`, `qr_create`, `qr_print`, `qr_rotate`, `branch_set_cashier_mode`, `cashier_token`, `merchant_redeem`, `merchant_reward_upsert`, `campaign_estimate/save/submit/pause`, `merchant_stats` |
| App read models | `my_roles`, `my_profile`, `my_bag`, `my_scans`, `my_notifications`, `store_list`, `merchant_home`, `merchant_campaigns`, `merchant_recent_visits`, `merchant_tips`, `admin_*` lists |
| Admin | `admin_review_queue`, `admin_resolve_scan`, `admin_user_status`, `admin_adjust_points`, `admin_set_config`, `admin_merchant_decide`, `admin_reward_price`, `admin_spot_create`, `admin_campaign_decide`, `admin_reverse_redemption`, `admin_economy`, `admin_city_pulse` |
| Jobs | `job_release_held`, `job_housekeeping`, `job_rotate_qr`, `job_campaigns`, `job_ai_suggest` |

Errors are raised as `AMOUNI:<CODE>`; user-facing copy lives in `supabase/functions/_shared/result_codes.ts` (Arabic + English).
