#!/usr/bin/env bash
# Downloads the Supabase Auth (GoTrue) and PostgREST binaries used by the local stack (Linux x86-64).
set -euo pipefail
BIN="$(cd "$(dirname "$0")/../.." && pwd)/.devstack/bin"
AUTH_VERSION="${AUTH_VERSION:-v2.180.0}"
POSTGREST_VERSION="${POSTGREST_VERSION:-v12.2.3}"
mkdir -p "$BIN" && cd "$BIN"
curl -fsSL "https://github.com/supabase/auth/releases/download/${AUTH_VERSION}/auth-${AUTH_VERSION}-x86.tar.gz" | tar xz
curl -fsSL "https://github.com/PostgREST/postgrest/releases/download/${POSTGREST_VERSION}/postgrest-${POSTGREST_VERSION}-linux-static-x64.tar.xz" | tar xJ
echo "✓ binaries in $BIN"; ls -1 "$BIN"
