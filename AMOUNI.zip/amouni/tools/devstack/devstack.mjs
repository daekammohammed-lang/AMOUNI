#!/usr/bin/env node
// AMOUNI local stack without Docker: the real Supabase Auth + PostgREST binaries, Deno edge
// functions and a single-origin gateway (like Supabase's Kong) on http://localhost:54321.
//
//   node tools/devstack/devstack.mjs reset   # fresh database: auth schema, migrations, seed
//   node tools/devstack/devstack.mjs up      # start everything (Ctrl+C stops)
//
// Requires: PostgreSQL 15+ with PostGIS (psql on PATH), Deno, and the binaries fetched by
// tools/devstack/fetch-binaries.sh. With Docker you can use `supabase start` instead.
import { spawn, execFileSync } from 'node:child_process';
import { createHmac, randomBytes } from 'node:crypto';
import { createServer, request } from 'node:http';
import { existsSync, readFileSync, readdirSync, statSync, writeFileSync, mkdirSync } from 'node:fs';
import { dirname, extname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const BIN = process.env.AMOUNI_STACK_BIN ?? join(ROOT, '.devstack/bin');
const PG = {
  host: process.env.PGHOST ?? 'localhost', port: process.env.PGPORT ?? '5432',
  user: process.env.PGUSER ?? 'postgres', db: process.env.AMOUNI_DEV_DB ?? 'amouni_dev',
};
const PORTS = { gateway: 54321, auth: 9999, rest: 3000, scan: 8101, 'step-up': 8102, 'auth-sms-hook': 8103 };
const JWT_SECRET = process.env.AMOUNI_JWT_SECRET ?? 'amouni-local-dev-jwt-secret-at-least-32-chars';
const HOOK_SECRET = 'v1,whsec_' + Buffer.from('amouni-local-hook-secret-0123456789').toString('base64');
const WEB_DIST = join(ROOT, 'apps/web/dist');

const b64url = (b) => Buffer.from(b).toString('base64url');
function jwt(payload) {
  const head = b64url(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64url(JSON.stringify(payload));
  return `${head}.${body}.${createHmac('sha256', JWT_SECRET).update(`${head}.${body}`).digest('base64url')}`;
}
const now = Math.floor(Date.now() / 1000);
const ANON_KEY = jwt({ role: 'anon', iss: 'amouni-local', iat: now, exp: now + 10 * 365 * 86400 });
const SERVICE_KEY = jwt({ role: 'service_role', iss: 'amouni-local', iat: now, exp: now + 10 * 365 * 86400 });

const psqlArgs = (db) => ['-h', PG.host, '-p', PG.port, '-U', PG.user, '-d', db, '-v', 'ON_ERROR_STOP=1', '-q'];
const psql = (db, sql) => execFileSync('psql', [...psqlArgs(db), '-c', sql], { stdio: 'pipe' });
const psqlFile = (db, file) => execFileSync('psql', [...psqlArgs(db), '-f', file], { stdio: 'pipe' });
const dbUrl = (user = PG.user, extra = '') =>
  `postgres://${user}${user === 'authenticator' ? ':authenticator' : ''}@${PG.host}:${PG.port}/${PG.db}?sslmode=disable${extra}`;

const authEnv = () => ({
  ...process.env,
  GOTRUE_DB_DRIVER: 'postgres', GOTRUE_DB_DATABASE_URL: dbUrl(PG.user, '&search_path=auth'), GOTRUE_DB_NAMESPACE: 'auth',
  GOTRUE_API_HOST: '127.0.0.1', PORT: String(PORTS.auth),
  API_EXTERNAL_URL: `http://localhost:${PORTS.gateway}/auth/v1`, GOTRUE_SITE_URL: `http://localhost:${PORTS.gateway}`,
  GOTRUE_JWT_SECRET: JWT_SECRET, GOTRUE_JWT_EXP: '3600', GOTRUE_JWT_AUD: 'authenticated',
  GOTRUE_JWT_DEFAULT_GROUP_NAME: 'authenticated', GOTRUE_JWT_ADMIN_ROLES: 'service_role',
  GOTRUE_EXTERNAL_PHONE_ENABLED: 'true', GOTRUE_SMS_AUTOCONFIRM: 'false', GOTRUE_SMS_OTP_LENGTH: '6', GOTRUE_SMS_OTP_EXP: '600',
  GOTRUE_SMS_PROVIDER: 'twilio', GOTRUE_SMS_TWILIO_ACCOUNT_SID: 'unused', GOTRUE_SMS_TWILIO_AUTH_TOKEN: 'unused',
  GOTRUE_SMS_TWILIO_MESSAGE_SERVICE_SID: 'unused', GOTRUE_SMS_MAX_FREQUENCY: '5s',
  GOTRUE_HOOK_SEND_SMS_ENABLED: 'true', GOTRUE_HOOK_SEND_SMS_URI: `http://localhost:${PORTS['auth-sms-hook']}`,
  GOTRUE_HOOK_SEND_SMS_SECRETS: HOOK_SECRET,
  GOTRUE_RATE_LIMIT_SMS_SENT: '1000', GOTRUE_RATE_LIMIT_VERIFY: '1000', GOTRUE_RATE_LIMIT_TOKEN_REFRESH: '1000',
  GOTRUE_DISABLE_SIGNUP: 'false', GOTRUE_LOG_LEVEL: 'warn',
});

function reset() {
  console.log(`• recreating database ${PG.db}`);
  execFileSync('psql', [...psqlArgs('postgres'), '-c', `drop database if exists ${PG.db} with (force)`, '-c', `create database ${PG.db}`], { stdio: 'pipe' });
  psqlFile(PG.db, join(ROOT, 'tools/devstack/roles.sql'));
  console.log('• Supabase Auth migrations');
  execFileSync(join(BIN, 'auth'), ['migrate'], { env: authEnv(), stdio: 'pipe', cwd: BIN });
  const migrations = readdirSync(join(ROOT, 'supabase/migrations')).filter((f) => f.endsWith('.sql')).sort();
  for (const f of migrations) { process.stdout.write(`• ${f}\n`); psqlFile(PG.db, join(ROOT, 'supabase/migrations', f)); }
  console.log('• seed.sql'); psqlFile(PG.db, join(ROOT, 'supabase/seed.sql'));
  psql(PG.db, "notify pgrst, 'reload schema'");
  console.log('✓ database ready');
}

function writeWebEnv() {
  const file = join(ROOT, 'apps/web/.env.local');
  mkdirSync(dirname(file), { recursive: true });
  writeFileSync(file, [
    `VITE_SUPABASE_URL=http://localhost:${PORTS.gateway}`,
    `VITE_SUPABASE_ANON_KEY=${ANON_KEY}`,
    'VITE_DEV_OTP_INBOX=true', '',
  ].join('\n'));
}

function proc(name, cmd, args, env, cwd = ROOT) {
  const p = spawn(cmd, args, { env, cwd, stdio: ['ignore', 'pipe', 'pipe'] });
  const tag = (d) => d.toString().split('\n').filter(Boolean).forEach((l) => console.log(`[${name}] ${l}`));
  p.stdout.on('data', tag); p.stderr.on('data', tag);
  p.on('exit', (c) => console.log(`[${name}] exited ${c}`));
  return p;
}

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.webp': 'image/webp', '.json': 'application/json', '.webmanifest': 'application/manifest+json',
  '.woff2': 'font/woff2', '.ico': 'image/x-icon', '.txt': 'text/plain' };
const CORS = {
  'access-control-allow-origin': '*',
  'access-control-allow-headers': 'authorization, x-client-info, apikey, content-type, idempotency-key, accept-language, accept-profile, content-profile, prefer, range, x-supabase-api-version',
  'access-control-allow-methods': 'GET, POST, PATCH, PUT, DELETE, OPTIONS',
  'access-control-expose-headers': 'content-range, x-supabase-api-version',
};

function gateway() {
  const routes = [
    ['/auth/v1', PORTS.auth], ['/rest/v1', PORTS.rest],
    ...Object.entries(PORTS).filter(([k]) => !['gateway', 'auth', 'rest'].includes(k)).map(([k, p]) => [`/functions/v1/${k}`, p]),
  ];
  createServer((req, res) => {
    const route = routes.find(([prefix]) => req.url === prefix || req.url.startsWith(prefix + '/') || req.url.startsWith(prefix + '?'));
    if (route) {
      if (req.method === 'OPTIONS') { res.writeHead(204, CORS); return res.end(); }
      let path = req.url.slice(route[0].length) || '/';
      if (!path.startsWith('/')) path = '/' + path;
      const up = request({ host: '127.0.0.1', port: route[1], path, method: req.method, headers: { ...req.headers, host: `127.0.0.1:${route[1]}` } }, (r) => {
        res.writeHead(r.statusCode ?? 502, { ...r.headers, ...CORS });
        r.pipe(res);
      });
      up.on('error', () => { res.writeHead(502, CORS); res.end('upstream unavailable'); });
      return req.pipe(up);
    }
    // Static web app with SPA fallback.
    if (!existsSync(WEB_DIST)) { res.writeHead(404); return res.end('build the web app first: npm run build'); }
    let file = join(WEB_DIST, decodeURIComponent(req.url.split('?')[0]));
    if (!file.startsWith(WEB_DIST) || !existsSync(file) || statSync(file).isDirectory()) file = join(WEB_DIST, 'index.html');
    res.writeHead(200, { 'content-type': MIME[extname(file)] ?? 'application/octet-stream',
      'cache-control': file.endsWith('index.html') ? 'no-cache' : 'public, max-age=31536000, immutable' });
    res.end(readFileSync(file));
  }).listen(PORTS.gateway, () => console.log(`✓ AMOUNI on http://localhost:${PORTS.gateway}`));
}

function up() {
  if (!existsSync(join(BIN, 'auth')) || !existsSync(join(BIN, 'postgrest'))) {
    console.error('Missing binaries. Run: bash tools/devstack/fetch-binaries.sh'); process.exit(1);
  }
  writeWebEnv();
  proc('auth', join(BIN, 'auth'), ['serve'], authEnv(), BIN);
  proc('rest', join(BIN, 'postgrest'), [], {
    ...process.env, PGRST_DB_URI: dbUrl('authenticator'), PGRST_DB_SCHEMAS: 'public', PGRST_DB_ANON_ROLE: 'anon',
    PGRST_JWT_SECRET: JWT_SECRET, PGRST_SERVER_PORT: String(PORTS.rest), PGRST_SERVER_HOST: '127.0.0.1',
    PGRST_DB_EXTRA_SEARCH_PATH: 'public,extensions', PGRST_LOG_LEVEL: 'warn',
  });
  const fnEnv = {
    ...process.env, SUPABASE_URL: `http://localhost:${PORTS.gateway}`, SUPABASE_ANON_KEY: ANON_KEY,
    SUPABASE_SERVICE_ROLE_KEY: SERVICE_KEY, SEND_SMS_HOOK_SECRET: HOOK_SECRET, AMOUNI_DEV_OTP_INBOX: 'true', APP_ORIGIN: '*',
  };
  for (const name of ['scan', 'step-up', 'auth-sms-hook']) {
    proc(name, 'deno', ['run', '--allow-net', '--allow-env', '--allow-read', join(ROOT, 'supabase/functions', name, 'index.ts')],
      { ...fnEnv, DENO_SERVE_ADDRESS: `tcp:127.0.0.1:${PORTS[name]}` });
  }
  gateway();
  console.log(`  anon key: ${ANON_KEY.slice(0, 24)}…   (written to apps/web/.env.local)`);
}

const cmd = process.argv[2];
if (cmd === 'reset') reset();
else if (cmd === 'up') up();
else if (cmd === 'keys') console.log(JSON.stringify({ anon: ANON_KEY, service: SERVICE_KEY }, null, 2));
else { console.log('usage: devstack.mjs reset | up | keys'); process.exit(1); }
