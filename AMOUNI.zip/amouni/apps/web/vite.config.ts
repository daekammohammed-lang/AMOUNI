import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../..', import.meta.url));
const stack = 'http://localhost:54321';

export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      // Result codes & user-facing messages have ONE source, shared with the edge functions.
      '@codes': fileURLToPath(new URL('../../supabase/functions/_shared/result_codes.ts', import.meta.url)),
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  server: {
    fs: { allow: [root] },
    proxy: { '/auth/v1': stack, '/rest/v1': stack, '/functions/v1': stack },
  },
  build: { target: 'es2020', chunkSizeWarningLimit: 900 },
});
