import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from 'react';
import { CatIcon, Icon } from './icons';
import type { SpotCard } from '@/lib/api';
import { dist, fmt, reasonText } from '@/lib/format';

// ---------- toast ----------
const ToastCtx = createContext<(m: string) => void>(() => {});
export function ToastProvider({ children }: { children: ReactNode }) {
  const [msg, setMsg] = useState<string | null>(null);
  useEffect(() => { if (!msg) return; const t = setTimeout(() => setMsg(null), 2600); return () => clearTimeout(t); }, [msg]);
  return <ToastCtx.Provider value={setMsg}>{children}{msg && <div className="toast" role="status">{msg}</div>}</ToastCtx.Provider>;
}
export const useToast = () => useContext(ToastCtx);

// ---------- sheet ----------
export function Sheet({ open, onClose, children, center }: { open: boolean; onClose: () => void; children: ReactNode; center?: boolean }) {
  useEffect(() => {
    if (!open) return;
    const k = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className={`scrim ${center ? 'center' : ''}`} onClick={(e) => e.target === e.currentTarget && onClose()}>
      <div className="sheet" role="dialog" aria-modal="true"><div className="grab" />{children}</div>
    </div>
  );
}

// ---------- small pieces ----------
export const Spinner = () => <div className="spinner" aria-label="جاري التحميل" />;
export function Empty({ title, children, icon }: { title: string; children?: ReactNode; icon?: Parameters<typeof Icon>[0]['name'] }) {
  return <div className="empty">{icon && <div style={{ opacity: .5, marginBottom: 8 }}><Icon name={icon} size={34} /></div>}<b>{title}</b>{children}</div>;
}
export function Bar({ pct, gold }: { pct: number; gold?: boolean }) {
  return <div className={`bar ${gold ? 'gold' : ''}`}><i style={{ width: `${Math.max(0, Math.min(100, pct))}%` }} /></div>;
}
export function Kpi({ v, l, hl }: { v: ReactNode; l: ReactNode; hl?: boolean }) {
  return <div className={`kpi ${hl ? 'hl' : ''}`}><div className="v num">{v}</div><div className="l">{l}</div></div>;
}
export function Lines({ lines, total }: { lines: { label_ar: string; points: number }[]; total?: number }) {
  return (
    <div className="lines">
      {lines.map((l, i) => <div className="ln" key={i}><span>{l.label_ar}</span><b className="num">+{fmt(l.points)}</b></div>)}
      {total !== undefined && <div className="ln total"><span>المجموع</span><span className="num" style={{ color: 'var(--gold)' }}>+{fmt(total)}</span></div>}
    </div>
  );
}
export function useAsync() {
  const [busy, setBusy] = useState(false);
  const toast = useToast();
  const run = useCallback(async <T,>(fn: () => Promise<T>, ok?: string): Promise<T | undefined> => {
    setBusy(true);
    try { const r = await fn(); if (ok) toast(ok); return r; }
    catch (e) { toast((e as Error).message || 'صار خلل'); return undefined; }
    finally { setBusy(false); }
  }, [toast]);
  return { busy, run };
}

// ---------- spot card ----------
export function catClass(s: Pick<SpotCard, 'kind' | 'category'>) {
  if (s.kind === 'mystery') return 'c-mystery';
  if (s.kind === 'golden_drop' || s.kind === 'first_finder') return 'c-gold';
  return `c-${s.category ?? 'retail'}`;
}
export function SpotThumb({ s, lg }: { s: Pick<SpotCard, 'kind' | 'category'>; lg?: boolean }) {
  const glyph = s.kind === 'mystery' ? 'mystery' : s.kind === 'golden_drop' || s.kind === 'first_finder' ? 'star' : s.category ?? 'retail';
  return <span className={`cat ${lg ? 'lg' : ''} ${catClass(s)}`}><CatIcon cat={glyph} /></span>;
}
export function SpotRow({ s, onClick, why }: { s: SpotCard; onClick: () => void; why?: boolean }) {
  const gold = s.kind === 'golden_drop' || s.kind === 'first_finder';
  return (
    <div>
      <button className={`spot ${gold ? 'gold' : ''}`} onClick={onClick}>
        <SpotThumb s={s} />
        <span className="grow">
          <b>{s.merchant ?? s.title_ar}</b>
          <span className="small muted" style={{ display: 'block' }}>{s.merchant ? s.title_ar : `داخل دائرة ${s.circle_m} م`}</span>
          <span className="row small muted" style={{ gap: 6, marginTop: 2 }}>
            <Icon name="walk" size={14} />{s.distance_m < 40 ? <span>إنت هنا</span> : <><span className="num">{dist(s.distance_m)}</span>·<span>{s.walk_min} د</span></>}
            {s.qty_left !== null && <span className="chip gold" style={{ padding: '0 8px' }}>باقي {s.qty_left}</span>}
            {s.hot && <span className="chip amber" style={{ padding: '0 8px' }}>نقاط إضافية هسه</span>}
          </span>
        </span>
        <span className="pts num">+{fmt(s.points)}</span>
      </button>
      {why && <p className="why">{reasonText(s.reason)}</p>}
    </div>
  );
}
