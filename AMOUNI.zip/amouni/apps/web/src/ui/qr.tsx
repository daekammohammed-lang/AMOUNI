import { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { Icon } from './icons';

/** Renders a QR as inline SVG (error correction Q, quiet zone 4 — the printing rule). */
export function QrImage({ value, size = 240, dark = '#15123A' }: { value: string; size?: number; dark?: string }) {
  const [svg, setSvg] = useState('');
  useEffect(() => {
    QRCode.toString(value, { type: 'svg', errorCorrectionLevel: 'Q', margin: 4, color: { dark, light: '#FFFFFF' } }).then(setSvg);
  }, [value, dark]);
  return <div style={{ width: size, maxWidth: '100%', margin: '0 auto', lineHeight: 0 }} dangerouslySetInnerHTML={{ __html: svg }} />;
}

function decode(img: CanvasImageSource, w: number, h: number) {
  const c = document.createElement('canvas');
  const scale = Math.min(1, 900 / Math.max(w, h));
  c.width = Math.round(w * scale); c.height = Math.round(h * scale);
  const ctx = c.getContext('2d', { willReadFrequently: true })!;
  ctx.drawImage(img, 0, 0, c.width, c.height);
  const d = ctx.getImageData(0, 0, c.width, c.height);
  return jsQR(d.data, d.width, d.height, { inversionAttempts: 'attemptBoth' })?.data ?? null;
}

/**
 * Camera scanner + photo upload + typed short code. It only READS the code;
 * whether it is valid, and what it is worth, is decided by the server.
 */
export function Scanner({ onResult, busy, title = 'وجّه الكاميرا على باركود AMOUNI' }: { onResult: (text: string) => void; busy?: boolean; title?: string }) {
  const video = useRef<HTMLVideoElement>(null);
  const [state, setState] = useState<'starting' | 'live' | 'blocked'>('starting');
  const [manual, setManual] = useState('');
  const [manualHint, setManualHint] = useState(false);
  const done = useRef(false);

  useEffect(() => {
    let stream: MediaStream | null = null; let raf = 0; let last = 0;
    done.current = false;
    (async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
        if (!video.current) return;
        video.current.srcObject = stream; await video.current.play(); setState('live');
        const tick = (t: number) => {
          raf = requestAnimationFrame(tick);
          const v = video.current;
          if (done.current || !v || t - last < 120 || !v.videoWidth) return;
          last = t;
          const text = decode(v, v.videoWidth, v.videoHeight);
          if (text) { done.current = true; navigator.vibrate?.(40); onResult(text); }
        };
        raf = requestAnimationFrame(tick);
      } catch { setState('blocked'); }
    })();
    return () => { cancelAnimationFrame(raf); stream?.getTracks().forEach((t) => t.stop()); };
  }, [onResult]);

  const fromFile = (f: File | undefined) => {
    if (!f) return;
    const img = new Image();
    img.onload = () => { const t = decode(img, img.naturalWidth, img.naturalHeight); if (t) onResult(t); else setManualHint(true); URL.revokeObjectURL(img.src); };
    img.src = URL.createObjectURL(f);
  };

  return (
    <div className="stack">
      <div className="scanbox">
        <video ref={video} playsInline muted />
        <div className="frame" />
        <div className="hint">{state === 'blocked' ? 'الكاميرا مو متاحة — ارفع صورة أو اكتب الكود' : busy ? 'نتأكد…' : title}</div>
      </div>
      <div className="row">
        <label className="btn grow" style={{ cursor: 'pointer' }}>
          <Icon name="image" /> صورة الباركود
          <input type="file" accept="image/*" hidden onChange={(e) => fromFile(e.target.files?.[0])} />
        </label>
      </div>
      <form className="card flat" onSubmit={(e) => { e.preventDefault(); if (manual.trim()) onResult(manual.trim().toUpperCase()); }}>
        <div className="small muted" style={{ marginBottom: 6 }}>{manualHint ? 'ما لكينا باركود بالصورة. اكتب الكود المطبوع تحته:' : 'أو اكتب الكود المطبوع تحت الباركود'}</div>
        <div className="row">
          <input className="in grow num" dir="ltr" placeholder="AM-XXXX-XX" value={manual} onChange={(e) => setManual(e.target.value)} aria-label="الكود" />
          <button className="btn primary" disabled={busy || !manual.trim()}>تحقق</button>
        </div>
      </form>
    </div>
  );
}
