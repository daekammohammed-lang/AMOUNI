import { useEffect, useRef } from 'react';
import maplibregl, { type StyleSpecification } from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import { catSvg } from './icons';

export type MapPoint = { id: string; lat: number; lng: number; kind?: string; category?: string | null; circle_m?: number | null; label?: string };

// Production: set VITE_MAP_STYLE to a vector style (MapTiler / self-hosted Protomaps). Dev falls back to OSM raster tiles.
const STYLE: string | StyleSpecification = import.meta.env.VITE_MAP_STYLE || {
  version: 8,
  sources: { osm: { type: 'raster', tiles: ['https://tile.openstreetmap.org/{z}/{x}/{y}.png'], tileSize: 256, attribution: '© OpenStreetMap' } },
  layers: [{ id: 'bg', type: 'background', paint: { 'background-color': '#E7E5F2' } }, { id: 'osm', type: 'raster', source: 'osm', paint: { 'raster-saturation': -0.6, 'raster-opacity': 0.9 } }],
};

function circle(lat: number, lng: number, m: number) {
  const pts: [number, number][] = [];
  for (let i = 0; i <= 48; i++) {
    const a = (i / 48) * 2 * Math.PI;
    pts.push([lng + (m / (111320 * Math.cos((lat * Math.PI) / 180))) * Math.cos(a), lat + (m / 110540) * Math.sin(a)]);
  }
  return pts;
}

function pinEl(p: MapPoint, onClick?: (id: string) => void) {
  const el = document.createElement('button');
  const gold = p.kind === 'golden_drop' || p.kind === 'first_finder';
  const glyph = p.kind === 'mystery' ? 'mystery' : gold ? 'star' : p.category ?? 'retail';
  el.className = `pin ${gold ? 'gold' : ''} c-${p.kind === 'mystery' ? 'mystery' : p.category ?? 'retail'}`;
  el.setAttribute('aria-label', p.label ?? 'فرصة');
  el.style.border = '';
  el.innerHTML = catSvg(glyph);
  if (onClick) el.addEventListener('click', (e) => { e.stopPropagation(); onClick(p.id); });
  return el;
}

export function AmouniMap({ center, points, me, onSelect, onPick, zoom = 14, className = '' }: {
  center: { lat: number; lng: number }; points: MapPoint[]; me?: { lat: number; lng: number } | null;
  onSelect?: (id: string) => void; onPick?: (p: { lat: number; lng: number }) => void; zoom?: number; className?: string;
}) {
  const box = useRef<HTMLDivElement>(null);
  const map = useRef<maplibregl.Map | null>(null);
  const markers = useRef<maplibregl.Marker[]>([]);

  useEffect(() => {
    if (!box.current) return;
    const m = new maplibregl.Map({ container: box.current, style: STYLE, center: [center.lng, center.lat], zoom, attributionControl: { compact: true } });
    map.current = m;
    m.addControl(new maplibregl.NavigationControl({ showCompass: false }), 'top-left');
    if (onPick) m.on('click', (e) => onPick({ lat: e.lngLat.lat, lng: e.lngLat.lng }));
    return () => { m.remove(); map.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const m = map.current; if (!m) return;
    markers.current.forEach((x) => x.remove()); markers.current = [];
    for (const p of points) {
      if (p.circle_m) continue;
      markers.current.push(new maplibregl.Marker({ element: pinEl(p, onSelect), anchor: 'bottom' }).setLngLat([p.lng, p.lat]).addTo(m));
    }
    if (me) {
      const d = document.createElement('div'); d.className = 'me-dot';
      markers.current.push(new maplibregl.Marker({ element: d }).setLngLat([me.lng, me.lat]).addTo(m));
    }
    const draw = () => {
      const data = { type: 'FeatureCollection' as const, features: points.filter((p) => p.circle_m).map((p) => ({
        type: 'Feature' as const, properties: { id: p.id }, geometry: { type: 'Polygon' as const, coordinates: [circle(p.lat, p.lng, p.circle_m!)] } })) };
      const src = m.getSource('mystery') as maplibregl.GeoJSONSource | undefined;
      if (src) src.setData(data);
      else {
        m.addSource('mystery', { type: 'geojson', data });
        m.addLayer({ id: 'mystery-fill', type: 'fill', source: 'mystery', paint: { 'fill-color': '#3B2FD9', 'fill-opacity': 0.12 } });
        m.addLayer({ id: 'mystery-line', type: 'line', source: 'mystery', paint: { 'line-color': '#3B2FD9', 'line-width': 2, 'line-dasharray': [2, 2] } });
        m.on('click', 'mystery-fill', (e) => { const id = e.features?.[0]?.properties?.id; if (id && onSelect) onSelect(String(id)); });
      }
    };
    if (m.isStyleLoaded()) draw(); else m.once('load', draw);
  }, [points, me, onSelect]);

  useEffect(() => { map.current?.easeTo({ center: [center.lng, center.lat] }); }, [center.lat, center.lng]);

  return <div ref={box} className={className} style={{ position: 'absolute', inset: 0 }} />;
}
