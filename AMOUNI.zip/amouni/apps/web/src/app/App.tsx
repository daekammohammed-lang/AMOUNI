import { lazy, Suspense, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useRoles, useSession } from './session';
import { Spinner } from '@/ui/kit';
import { Landing } from '@/features/public/Landing';
import { Login } from '@/features/public/Login';
import { Onboarding } from '@/features/public/Onboarding';
import { UserApp } from '@/features/user/UserApp';

// Merchant and admin consoles are separate chunks: the consumer app stays small on phones.
const MerchantApp = lazy(() => import('@/features/merchant/MerchantApp'));
const AdminApp = lazy(() => import('@/features/admin/AdminApp'));
const PrintPoster = lazy(() => import('@/features/merchant/PrintPoster'));

function RequireAuth({ children }: { children: ReactNode }) {
  const { session, loading } = useSession();
  const roles = useRoles();
  const loc = useLocation();
  if (loading || (session && roles.isLoading)) return <Spinner />;
  if (!session) return <Navigate to={`/login?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  if (roles.data && !roles.data.profile_complete && loc.pathname !== '/welcome') return <Navigate to="/welcome" replace />;
  return <>{children}</>;
}

function Home() {
  const { session, loading } = useSession();
  if (loading) return <Spinner />;
  return session ? <Navigate to="/app" replace /> : <Landing />;
}

export function App() {
  return (
    <Suspense fallback={<Spinner />}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/welcome" element={<RequireAuth><Onboarding /></RequireAuth>} />
        <Route path="/app/*" element={<RequireAuth><UserApp /></RequireAuth>} />
        <Route path="/merchant/qr/:qrId/print" element={<RequireAuth><PrintPoster /></RequireAuth>} />
        <Route path="/merchant/*" element={<RequireAuth><MerchantApp /></RequireAuth>} />
        <Route path="/admin/*" element={<RequireAuth><AdminApp /></RequireAuth>} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </Suspense>
  );
}
