import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import type { Session } from '@supabase/supabase-js';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, supabase, type Roles } from '@/lib/api';

type Ctx = { session: Session | null; loading: boolean };
const SessionCtx = createContext<Ctx>({ session: null, loading: true });

export function SessionProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<Ctx>({ session: null, loading: true });
  const qc = useQueryClient();
  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setState({ session: data.session, loading: false }));
    const { data } = supabase.auth.onAuthStateChange((_e, session) => {
      setState({ session, loading: false });
      if (!session) qc.clear();
    });
    return () => data.subscription.unsubscribe();
  }, [qc]);
  return <SessionCtx.Provider value={state}>{children}</SessionCtx.Provider>;
}

export const useSession = () => useContext(SessionCtx);

/** Who am I (profile completeness, platform roles, merchant memberships). Drives routing only — every action is re-checked server-side. */
export function useRoles() {
  const { session } = useSession();
  return useQuery({ queryKey: ['roles', session?.user.id], queryFn: () => rpc<Roles>('my_roles'), enabled: !!session, staleTime: 60_000 });
}

export async function signOut() { await supabase.auth.signOut(); }
