import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { dateAr, fmt, iqd } from '@/lib/format';
import { Kpi, Spinner, useAsync } from '@/ui/kit';
import { useMerchant } from './MerchantApp';

type Member = { user_id: string; name: string | null; phone: string; role: string; branch_id: string | null; active: boolean; added_at: string };
type Billing = { month_charges_iqd: number; month_generated: number; by_campaign: { campaign: string; visits: number; amount_iqd: number }[];
  subscriptions: { plan: string; period_start: string; period_end: string; amount_iqd: number; status: string }[] };
const ROLE: Record<string, string> = { owner: 'صاحب المحل', manager: 'مدير', cashier: 'كاشير' };

/** Team (invite staff) and billing — owner only. */
export function Account() {
  const { id, home } = useMerchant();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const team = useQuery({ queryKey: ['mteam', id], queryFn: () => rpc<Member[]>('merchant_team', { merchant: id }) });
  const bill = useQuery({ queryKey: ['mbill', id], queryFn: () => rpc<Billing>('merchant_billing', { merchant: id }) });
  const [f, setF] = useState({ phone: '', role: 'cashier', branch: '' });
  const invite = (e: React.FormEvent) => {
    e.preventDefault();
    const digits = f.phone.replace(/\D/g, '').replace(/^0/, '964').replace(/^7/, '9647');
    run(async () => { await rpc('merchant_add_staff', { merchant: id, phone: digits, role: f.role, branch: f.branch || null }); await qc.invalidateQueries({ queryKey: ['mteam', id] }); setF({ ...f, phone: '' }); },
      'إذا الرقم مسجّل بـ AMOUNI توصله دعوة يقبلها من حسابه');
  };
  return (
    <>
      <div className="main-h"><h1>الفريق والفواتير</h1></div>
      <div className="grid2">
        <div className="card">
          <h3>الفريق</h3>
          {team.isLoading ? <Spinner /> : <div className="list">{team.data?.map((m) => (
            <div className="it" key={m.user_id}><div className="grow"><b>{m.name ?? '—'}</b><div className="small muted num" dir="ltr" style={{ textAlign: 'end' }}>{m.phone}</div></div>
              <span className="chip">{ROLE[m.role]}{m.branch_id ? ` · ${home.branches.find((b) => b.id === m.branch_id)?.name ?? ''}` : ''}</span>
              {!m.active && <span className="chip amber">دعوة معلّقة</span>}</div>
          ))}</div>}
          <form className="stack" style={{ marginTop: 12, borderTop: '1px solid var(--line)', paddingTop: 12 }} onSubmit={invite}>
            <b>ادعُ موظف</b>
            <input className="in num" dir="ltr" placeholder="07XXXXXXXXX" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
            <div className="row">
              <select className="in" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}><option value="cashier">كاشير</option><option value="manager">مدير</option></select>
              <select className="in" value={f.branch} onChange={(e) => setF({ ...f, branch: e.target.value })}><option value="">كل الفروع</option>{home.branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select>
            </div>
            <button className="btn primary" disabled={busy || f.phone.replace(/\D/g, '').length < 10}>أرسل الدعوة</button>
          </form>
        </div>
        <div className="stack">
          {bill.data ? <>
            <div className="grid2"><Kpi hl v={iqd(bill.data.month_charges_iqd)} l="مستحق هالشهر (حملات)" /><Kpi v={fmt(bill.data.month_generated)} l="زبون جديد مدفوع هالشهر" /></div>
            <div className="card"><h3>حسب الحملة</h3>
              {bill.data.by_campaign.length ? <table className="tbl" style={{ marginTop: 6 }}><tbody>{bill.data.by_campaign.map((c) => <tr key={c.campaign}><td>{c.campaign}</td><td className="num">{c.visits} زبون</td><td className="num">{iqd(c.amount_iqd)}</td></tr>)}</tbody></table>
                : <p className="muted small" style={{ marginTop: 6 }}>ماكو رسوم حملات هالشهر.</p>}</div>
            <div className="card"><h3>الاشتراك</h3>
              {bill.data.subscriptions.length ? <table className="tbl" style={{ marginTop: 6 }}><tbody>{bill.data.subscriptions.map((s, i) => <tr key={i}><td>{s.plan}</td><td>{dateAr(s.period_start)} – {dateAr(s.period_end)}</td><td className="num">{iqd(s.amount_iqd)}</td><td><span className={`chip ${s.status === 'paid' ? 'ok' : 'amber'}`}>{s.status === 'paid' ? 'مدفوع' : 'مستحق'}</span></td></tr>)}</tbody></table>
                : <p className="muted small" style={{ marginTop: 6 }}>باقة {home.merchant.plan}. فريق AMOUNI يتواصل وياك بخصوص الاشتراك.</p>}</div>
          </> : <Spinner />}
        </div>
      </div>
    </>
  );
}
