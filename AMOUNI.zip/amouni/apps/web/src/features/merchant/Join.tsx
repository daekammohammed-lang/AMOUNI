import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, supabase } from '@/lib/api';
import { useGeo } from '@/lib/hooks';
import { CATEGORY_AR } from '@/lib/format';
import { AmouniMap } from '@/ui/Map';
import { useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';

/** Merchant registration: business, first branch and its exact location (the geofence centre). */
export function Join() {
  const { fix } = useGeo();
  const nav = useNavigate();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const [f, setF] = useState({ name: '', category: 'coffee', branch: 'الفرع الرئيسي', address: '', city: '' });
  const [pos, setPos] = useState<{ lat: number; lng: number } | null>(null);
  const cities = useQuery({ queryKey: ['cities'], queryFn: async () => (await supabase.from('cities').select('id,name_ar')).data ?? [] });
  const at = pos ?? fix;

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const r = await run(() => rpc<{ merchant_id: string }>('merchant_apply', {
      name: f.name.trim(), category: f.category, city: f.city || cities.data?.[0]?.id, branch_name: f.branch.trim(),
      lat: at.lat, lng: at.lng, address: f.address.trim() || null, district: null }), 'وصل طلبك ✓');
    if (r) {
      try { localStorage.setItem('amouni-merchant', r.merchant_id); } catch { /* ignore */ }
      await qc.invalidateQueries({ queryKey: ['roles'] });
      nav('/merchant', { replace: true });
    }
  };

  return (
    <div style={{ maxWidth: 980, margin: '0 auto', padding: '24px 16px 60px' }}>
      <div className="row" style={{ marginBottom: 16 }}><img src="/logo-mark.webp" width={34} alt="" /><b style={{ fontFamily: 'var(--f-display)', letterSpacing: '.12em' }}>AMOUNI للمحلات</b></div>
      <h1>سجّل محلك وخلّي الزبائن يجونك</h1>
      <p className="muted" style={{ margin: '6px 0 20px', maxWidth: '60ch' }}>تدفع على زيارات حقيقية مثبتة بالباركود والموقع، وتشوف كل زبون جديد جابه AMOUNI. التسجيل مجاني، وفريقنا يراجع الطلب خلال يوم.</p>
      <form className="grid2" onSubmit={submit}>
        <div className="stack">
          <label className="field">اسم المحل<input className="in" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="مثلاً: كافيه النخيل" /></label>
          <label className="field">النوع<select className="in" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}>{Object.entries(CATEGORY_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
          <label className="field">المدينة<select className="in" value={f.city} onChange={(e) => setF({ ...f, city: e.target.value })}>{(cities.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.name_ar}</option>)}</select></label>
          <label className="field">اسم الفرع<input className="in" value={f.branch} onChange={(e) => setF({ ...f, branch: e.target.value })} /></label>
          <label className="field">العنوان<input className="in" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} placeholder="الحي، أقرب نقطة دالة" /></label>
          <button className="btn primary lg" disabled={busy || f.name.trim().length < 2}>أرسل الطلب</button>
        </div>
        <div className="stack">
          <div className="field">موقع المحل بالضبط <span className="small muted">اضغط على الخريطة. هذا مركز «سياج» التحقق من الحضور.</span></div>
          <div className="mapbox" style={{ height: 360 }}>
            <AmouniMap center={at} points={[{ id: 'shop', lat: at.lat, lng: at.lng, category: f.category }]} onPick={setPos} zoom={16} />
          </div>
          <button type="button" className="btn sm" onClick={() => setPos({ lat: fix.lat, lng: fix.lng })}><Icon name="pin" /> أنا داخل المحل هسه — استخدم موقعي</button>
          <span className="small muted num" dir="ltr">{at.lat.toFixed(5)}, {at.lng.toFixed(5)}</span>
        </div>
      </form>
    </div>
  );
}
