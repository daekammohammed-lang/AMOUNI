import { useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { QrImage } from '@/ui/qr';
import { Spinner } from '@/ui/kit';

type Printable = { qr_id: string; url: string; short_code: string; label: string; status: string };

/** A4 poster: gold frame, QR (error correction Q, quiet zone 4), short code under it. Opens the print dialog. */
export default function PrintPoster() {
  const { qrId } = useParams();
  const q = useQuery({ queryKey: ['print', qrId], queryFn: () => rpc<Printable>('qr_print', { qr: qrId }) });
  useEffect(() => { if (q.data) { const t = setTimeout(() => window.print(), 600); return () => clearTimeout(t); } }, [q.data]);
  if (!q.data) return <Spinner />;
  return (
    <div style={{ background: '#fff', minHeight: '100vh', padding: 16 }}>
      <div className="no-print center" style={{ marginBottom: 12 }}><button className="btn primary" onClick={() => window.print()}>اطبع البوستر</button></div>
      <div className="poster">
        <img className="logo" src="/logo-full.webp" alt="AMOUNI" />
        <h1>امسح… ولكيتها!</h1>
        <p style={{ fontSize: 18 }}>افتح تطبيق AMOUNI وامسح الباركود واربح نقاط وجوائز</p>
        <div className="qr"><QrImage value={q.data.url} size={453} /></div>
        <div className="code">{q.data.short_code}</div>
        <p style={{ fontSize: 14, color: '#6F6B8E' }}>ما تشتغل الكاميرا؟ اكتب الكود فوق بالتطبيق · {q.data.label}</p>
      </div>
    </div>
  );
}
