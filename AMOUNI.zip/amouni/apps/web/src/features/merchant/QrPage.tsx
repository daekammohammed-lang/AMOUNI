import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { ago, dateAr, fmt } from '@/lib/format';
import { QrImage } from '@/ui/qr';
import { Empty, Sheet, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

export type QrRow = { id: string; branch_id: string; branch: string; label: string; status: string; short_code: string; rotation: string;
  scans: number; created_at: string; grace_until: string | null; next_rotation_at: string | null; disabled_reason: string | null; url: string | null };

const ST: Record<string, [string, string]> = { active: ['فعّال', 'ok'], grace: ['فترة سماح', 'amber'], disabled: ['متوقف', 'warn'] };

export function QrPage() {
  const { id, home } = useMerchant();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['mqr', id], queryFn: () => rpc<QrRow[]>('merchant_qr_list', { merchant: id }) });
  const [creating, setCreating] = useState(false);
  const [f, setF] = useState({ branch: home.branches[0]?.id ?? '', label: 'الكاشير', rotation: 'monthly' });
  const [rotating, setRotating] = useState<QrRow | null>(null);
  const refresh = () => qc.invalidateQueries({ queryKey: ['mqr', id] });

  const create = (e: React.FormEvent) => { e.preventDefault(); run(async () => { await rpc('qr_create', { branch: f.branch, label: f.label, rotation: f.rotation }); await refresh(); setCreating(false); }, 'انضاف باركود جديد'); };
  const rotate = (reason: 'manual' | 'leak') => rotating && run(async () => { await rpc('qr_rotate', { qr: rotating.id, reason }); await refresh(); setRotating(null); },
    reason === 'leak' ? 'وقّفنا القديم فوراً وطلعنا جديد' : 'طلعنا باركود جديد. القديم يشتغل 24 ساعة');

  return (
    <>
      <div className="main-h"><div><h1>الباركود</h1><p className="muted">اطبعه وعلّقه بمكان ظاهر داخل المحل. كل فرع ممكن يكون إله أكثر من باركود (الكاشير، المدخل، الطاولات).</p></div>
        <button className="btn primary" onClick={() => setCreating(true)}><Icon name="plus" /> باركود جديد</button></div>
      {q.isLoading ? <Spinner /> : !q.data?.length ? <Empty title="ما عندك باركود بعد" icon="qr" /> : (
        <div className="grid3">
          {q.data.map((r) => (
            <div className="card" key={r.id} style={{ opacity: r.status === 'disabled' ? 0.6 : 1 }}>
              <div className="row between"><b>{r.label}</b><span className={`chip ${ST[r.status][1]}`}>{ST[r.status][0]}</span></div>
              <div className="small muted">{r.branch}</div>
              {r.url && <div style={{ margin: '12px auto', border: '6px solid var(--gold-fill)', borderRadius: 14, padding: 4, width: 170, background: '#fff' }}><QrImage value={r.url} size={150} /></div>}
              <div className="center num" style={{ letterSpacing: '.1em', direction: 'ltr' }}>{r.short_code}</div>
              <dl className="kv small" style={{ marginTop: 8 }}>
                <dt>المسحات</dt><dd className="num">{fmt(r.scans)}</dd>
                <dt>التجديد</dt><dd>{r.rotation === 'monthly' ? 'شهري' : r.rotation === 'weekly' ? 'أسبوعي' : 'ثابت'}{r.next_rotation_at ? ` · ${dateAr(r.next_rotation_at)}` : ''}</dd>
                {r.grace_until && <><dt>يتوقف</dt><dd>{ago(r.grace_until).replace('قبل', 'بعد')}</dd></>}
                {r.disabled_reason && <><dt>السبب</dt><dd>{r.disabled_reason === 'leak_auto' ? 'انتشرت صورته (تلقائي)' : r.disabled_reason}</dd></>}
              </dl>
              {r.status !== 'disabled' && <div className="row" style={{ marginTop: 12 }}>
                <a className="btn sm grow" href={`/merchant/qr/${r.id}/print`} target="_blank" rel="noreferrer"><Icon name="print" /> اطبع</a>
                {r.status === 'active' && <button className="btn sm" onClick={() => setRotating(r)}><Icon name="refresh" /> جدّد</button>}
              </div>}
            </div>
          ))}
        </div>
      )}
      <Sheet open={creating} onClose={() => setCreating(false)} center>
        <form className="stack" onSubmit={create}>
          <h2>باركود جديد</h2>
          <label className="field">الفرع<select className="in" value={f.branch} onChange={(e) => setF({ ...f, branch: e.target.value })}>{home.branches.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}</select></label>
          <label className="field">وين راح تعلّقه؟<input className="in" value={f.label} onChange={(e) => setF({ ...f, label: e.target.value })} placeholder="الكاشير، المدخل، طاولة 4…" /></label>
          <label className="field">يتجدد تلقائياً<select className="in" value={f.rotation} onChange={(e) => setF({ ...f, rotation: e.target.value })}><option value="monthly">كل شهر</option><option value="weekly">كل أسبوع</option><option value="fixed">ثابت</option></select></label>
          <button className="btn primary block" disabled={busy}>أنشئ</button>
        </form>
      </Sheet>
      <Sheet open={!!rotating} onClose={() => setRotating(null)} center>
        <div className="stack">
          <h2>تجديد «{rotating?.label}»</h2>
          <p className="muted">نطلع باركود جديد لنفس المكان. اختار السبب:</p>
          <button className="btn block" disabled={busy} onClick={() => rotate('manual')}>تجديد عادي — القديم يشتغل 24 ساعة لحد ما تطبع الجديد</button>
          <button className="btn danger block" disabled={busy} onClick={() => rotate('leak')}>انتشرت صورته — وقّف القديم هسه</button>
        </div>
      </Sheet>
    </>
  );
}
