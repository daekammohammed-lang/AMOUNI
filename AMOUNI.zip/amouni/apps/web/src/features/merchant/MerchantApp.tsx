import { createContext, useContext, useEffect, useState } from 'react';
import { Link, Navigate, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { useRoles } from '@/app/session';
import { Spinner } from '@/ui/kit';
import { Icon, type IconName } from '@/ui/icons';
import { Join } from './Join';
import { Dashboard } from './Dashboard';
import { Branches } from './Branches';
import { QrPage } from './QrPage';
import { Cashier } from './Cashier';
import { Campaigns } from './Campaigns';
import { Rewards } from './Rewards';
import { Account } from './Account';

export type Branch = { id: string; name: string; address: string | null; status: string; lat: number; lng: number; geofence_m: number;
  cashier_mode: boolean; capacity: number | null; hint_ar: string | null; live_spots: number; qr_active: number };
export type MerchantHome = {
  merchant: { id: string; name: string; category: string; status: string; plan: string; reject_reason: string | null; created_at: string };
  role: 'owner' | 'manager' | 'cashier'; branch_scope: string | null;
  settings: { avg_ticket_iqd: number | null; cpv_iqd: number | null } | null; branches: Branch[];
};

const Ctx = createContext<{ id: string; home: MerchantHome } | null>(null);
export function useMerchant() { const c = useContext(Ctx); if (!c) throw new Error('no merchant'); return c; }

const NAV: [string, IconName, string, ('owner' | 'manager' | 'cashier')[]][] = [
  ['', 'chart', 'النتائج', ['owner', 'manager']],
  ['campaigns', 'bolt', 'الحملات', ['owner', 'manager']],
  ['qr', 'qr', 'الباركود', ['owner', 'manager']],
  ['cashier', 'shield', 'وضع الكاشير', ['owner', 'manager', 'cashier']],
  ['branches', 'store', 'الفروع', ['owner', 'manager']],
  ['rewards', 'gift', 'الجوائز', ['owner', 'manager']],
  ['account', 'settings', 'الفريق والفواتير', ['owner']],
];

export default function MerchantApp() {
  const roles = useRoles();
  const loc = useLocation();
  const mine = roles.data?.merchants.filter((m) => m.active) ?? [];
  const [id, setId] = useState<string | null>(() => { try { return localStorage.getItem('amouni-merchant'); } catch { return null; } });
  useEffect(() => { if (mine.length && (!id || !mine.some((m) => m.merchant_id === id))) setId(mine[0].merchant_id); }, [mine, id]);
  useEffect(() => { try { if (id) localStorage.setItem('amouni-merchant', id); } catch { /* ignore */ } }, [id]);
  const home = useQuery({ queryKey: ['merchant', id], queryFn: () => rpc<MerchantHome>('merchant_home', { merchant: id }), enabled: !!id });

  if (loc.pathname.startsWith('/merchant/join')) return <Join />;
  if (roles.isLoading) return <Spinner />;
  if (!mine.length) return <Navigate to="/merchant/join" replace />;
  if (!home.data) return <Spinner />;
  const h = home.data;
  const nav = NAV.filter((n) => n[3].includes(h.role));

  return (
    <Ctx.Provider value={{ id: id!, home: h }}>
      <div className="console">
        <aside className="side">
          <div className="brand"><img src="/logo-mark.webp" alt="" />AMOUNI <span className="chip" style={{ background: 'rgba(255,255,255,.12)', color: '#fff', letterSpacing: 0 }}>للمحلات</span></div>
          {mine.length > 1 && (
            <select className="in" style={{ background: 'rgba(255,255,255,.08)', color: '#fff', borderColor: 'transparent', marginBottom: 8, minHeight: 40 }} value={id!} onChange={(e) => setId(e.target.value)}>
              {mine.map((m) => <option key={m.merchant_id} value={m.merchant_id} style={{ color: '#000' }}>{m.name}</option>)}
            </select>
          )}
          {nav.map(([to, icon, label]) => <NavLink key={to} to={`/merchant/${to}`} end={to === ''}><Icon name={icon} />{label}</NavLink>)}
          <Link to="/app" style={{ marginTop: 8 }}><Icon name="home" />تطبيق المستخدم</Link>
          <div className="foot">{h.merchant.name}<br />{h.role === 'owner' ? 'صاحب المحل' : h.role === 'manager' ? 'مدير' : 'كاشير'} · باقة {h.merchant.plan}</div>
        </aside>
        <main className="main">
          {h.merchant.status === 'pending' && (
            <div className="card gold row" style={{ marginBottom: 16 }}><Icon name="clock" /><div className="grow"><b>طلبك قيد المراجعة</b><div className="small muted">فريق AMOUNI يتأكد من المحل ويضيف أول فرصة. تكدر هسه تجهّز الباركود والفروع والجوائز.</div></div></div>
          )}
          {h.merchant.status === 'rejected' && <div className="card row" style={{ marginBottom: 16, borderColor: 'var(--warn)' }}><Icon name="x" /><div className="grow"><b>ما انقبل الطلب</b><div className="small muted">{h.merchant.reject_reason}</div></div></div>}
          <Routes>
            {h.role === 'cashier' ? <Route path="*" element={<Cashier />} /> : <>
              <Route index element={<Dashboard />} />
              <Route path="campaigns" element={<Campaigns />} />
              <Route path="qr" element={<QrPage />} />
              <Route path="cashier" element={<Cashier />} />
              <Route path="branches" element={<Branches />} />
              <Route path="rewards" element={<Rewards />} />
              <Route path="account" element={<Account />} />
            </>}
          </Routes>
        </main>
      </div>
    </Ctx.Provider>
  );
}
