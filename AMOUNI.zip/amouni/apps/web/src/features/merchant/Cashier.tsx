import { useCallback, useEffect, useState } from 'react';
import { rpc } from '@/lib/api';
import { useInterval } from '@/lib/hooks';
import { QrImage, Scanner } from '@/ui/qr';
import { Sheet, useToast } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

type Token = { url: string; expires_in: number };

/** Runs on the shop's tablet/phone: rotating screen QR (Drops + step-up) and reward redemption. */
export function Cashier() {
  const { home } = useMerchant();
  const toast = useToast();
  const branches = home.branches;
  const [branch, setBranch] = useState(branches[0]?.id ?? '');
  const b = branches.find((x) => x.id === branch);
  const [tok, setTok] = useState<Token | null>(null);
  const [err, setErr] = useState('');
  const [code, setCode] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState<{ title_ar: string; customer: string } | null>(null);
  const [scanning, setScanning] = useState(false);
  const [full, setFull] = useState(false);

  const load = useCallback(() => {
    if (!branch || !b?.cashier_mode) return;
    rpc<Token>('cashier_token', { branch }).then((t) => { setTok(t); setErr(''); }).catch((e) => setErr(e.message));
  }, [branch, b?.cashier_mode]);
  useEffect(load, [load]);
  useInterval(load, b?.cashier_mode ? 5000 : null);

  const redeem = async (input: string) => {
    setBusy(true); setScanning(false);
    try { const r = await rpc<{ title_ar: string; customer: string }>('merchant_redeem', { branch_id: branch, input }); setDone(r); setCode(''); navigator.vibrate?.(60); }
    catch (e) { toast((e as Error).message); }
    finally { setBusy(false); }
  };

  return (
    <>
      <div className="main-h"><div><h1>وضع الكاشير</h1><p className="muted">حطّه على تابلت أو موبايل بالكاونتر.</p></div>
        {branches.length > 1 && <select className="in" style={{ maxWidth: 240 }} value={branch} onChange={(e) => setBranch(e.target.value)}>{branches.map((x) => <option key={x.id} value={x.id}>{x.name}</option>)}</select>}</div>
      <div className="grid2">
        <div className="card center" style={full ? { position: 'fixed', inset: 0, zIndex: 90, borderRadius: 0, display: 'grid', placeItems: 'center' } : undefined}>
          {!b?.cashier_mode ? <div className="empty"><b>وضع الكاشير متوقف لهذا الفرع</b>شغّله من صفحة الفروع.</div>
          : err ? <p className="err">{err}</p>
          : tok ? <div>
              <div className="eyebrow">شاشة AMOUNI · {b.name}</div>
              <div style={{ border: '8px solid var(--gold-fill)', borderRadius: 20, padding: 6, background: '#fff', margin: '12px auto', width: 'fit-content' }}><QrImage value={tok.url} size={full ? 420 : 260} /></div>
              <b style={{ fontFamily: 'var(--f-display)', fontSize: 20 }}>امسح… ولكيتها!</b>
              <div className="small muted">يتبدل تلقائياً كل 30 ثانية — الصورة ما تنفع</div>
              <button className="btn sm" style={{ marginTop: 10 }} onClick={() => setFull(!full)}>{full ? 'تصغير' : 'ملء الشاشة'}</button>
            </div> : <div className="spinner" />}
        </div>
        <div className="card">
          <h3>استبدال جائزة زبون</h3>
          <p className="small muted" style={{ margin: '4px 0 12px' }}>الزبون يفتح الجائزة بحقيبته ويراويك كود من 6 أرقام أو باركود يتغيّر كل دقيقة.</p>
          <form className="stack" onSubmit={(e) => { e.preventDefault(); if (code.length === 6) redeem(code); }}>
            <input className="in code num" inputMode="numeric" maxLength={6} placeholder="••••••" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} aria-label="كود الزبون" />
            <button className="btn gold block lg" disabled={busy || code.length !== 6}>تأكيد الاستبدال</button>
          </form>
          <button className="btn block" style={{ marginTop: 10 }} onClick={() => setScanning(true)}><Icon name="camera" /> امسح باركود الزبون</button>
        </div>
      </div>
      <Sheet open={scanning} onClose={() => setScanning(false)} center><Scanner onResult={redeem} busy={busy} title="امسح باركود الجائزة من موبايل الزبون" /></Sheet>
      <Sheet open={!!done} onClose={() => setDone(null)} center>
        {done && <div className="found center"><div className="burst"><Icon name="check" size={60} /></div><h1 style={{ fontSize: 30 }}>{done.title_ar}</h1><p className="muted">سلّمها لـ {done.customer || 'الزبون'} ✓</p><button className="btn primary block" style={{ marginTop: 16 }} onClick={() => setDone(null)}>تم</button></div>}
      </Sheet>
    </>
  );
}
