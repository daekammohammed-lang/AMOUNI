import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { fmt, iqd } from '@/lib/format';
import { Empty, Sheet, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

type Reward = { id: string; title_ar: string; value_iqd: number; cost_points: number | null; stock: number; validity_days: number; terms_ar: string | null; active: boolean; redeemed: number; in_bags: number };
const empty = { id: null as string | null, title: '', value: 3000, stock: 50, validity: 14, terms: '' };

export function Rewards() {
  const { id } = useMerchant();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['mrewards', id], queryFn: () => rpc<Reward[]>('merchant_rewards', { merchant: id }) });
  const [f, setF] = useState<typeof empty | null>(null);
  const save = (e: React.FormEvent) => {
    e.preventDefault(); if (!f) return;
    run(async () => {
      await rpc('merchant_reward_upsert', { merchant: id, title: f.title, value_iqd: f.value, stock: f.stock, validity_days: f.validity, terms: f.terms || null, reward: f.id });
      await qc.invalidateQueries({ queryKey: ['mrewards', id] }); setF(null);
    }, 'انحفظت. AMOUNI يحدد سعرها بالنقاط ويفعّلها');
  };
  return (
    <>
      <div className="main-h"><div><h1>الجوائز</h1><p className="muted">الجوائز اللي يستبدلها الزبائن عندك. إنت تحدد الجائزة والكمية، وAMOUNI تحدد سعرها بالنقاط.</p></div>
        <button className="btn primary" onClick={() => setF({ ...empty })}><Icon name="plus" /> جائزة جديدة</button></div>
      {q.isLoading ? <Spinner /> : !q.data?.length ? <Empty title="ماكو جوائز بعد" icon="gift" /> : (
        <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>الجائزة</th><th>القيمة</th><th>السعر بالنقاط</th><th>المتبقي</th><th>بالحقائب</th><th>استُبدلت</th><th>الحالة</th><th /></tr></thead>
          <tbody>{q.data.map((r) => (
            <tr key={r.id}><td><b>{r.title_ar}</b></td><td className="num">{iqd(r.value_iqd)}</td><td className="num">{r.cost_points ? fmt(r.cost_points) : 'فورية فقط'}</td>
              <td className="num">{fmt(r.stock)}</td><td className="num">{r.in_bags}</td><td className="num">{r.redeemed}</td>
              <td><span className={`chip ${r.active ? 'ok' : 'amber'}`}>{r.active ? 'فعّالة' : 'بانتظار التسعير'}</span></td>
              <td><button className="btn sm" onClick={() => setF({ id: r.id, title: r.title_ar, value: r.value_iqd, stock: r.stock, validity: r.validity_days, terms: r.terms_ar ?? '' })}>تعديل</button></td></tr>
          ))}</tbody></table></div>
      )}
      <Sheet open={!!f} onClose={() => setF(null)} center>
        {f && <form className="stack" onSubmit={save}>
          <h2>{f.id ? 'تعديل الجائزة' : 'جائزة جديدة'}</h2>
          <label className="field">الجائزة<input className="in" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} placeholder="مثلاً: قهوة مجانية" /></label>
          <div className="row">
            <label className="field grow">قيمتها التقريبية (د.ع)<input className="in num" type="number" min={0} value={f.value} onChange={(e) => setF({ ...f, value: Number(e.target.value) })} /></label>
            <label className="field grow">الكمية<input className="in num" type="number" min={0} value={f.stock} onChange={(e) => setF({ ...f, stock: Number(e.target.value) })} /></label>
          </div>
          <label className="field">صالحة كم يوم بعد ما ياخذها الزبون<input className="in num" type="number" min={1} max={365} value={f.validity} onChange={(e) => setF({ ...f, validity: Number(e.target.value) })} /></label>
          <label className="field">الشروط (اختياري)<textarea className="in" value={f.terms} onChange={(e) => setF({ ...f, terms: e.target.value })} /></label>
          <button className="btn primary block" disabled={busy}>احفظ</button>
        </form>}
      </Sheet>
    </>
  );
}
