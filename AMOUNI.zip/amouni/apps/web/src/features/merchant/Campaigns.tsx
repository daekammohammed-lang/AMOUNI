import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { CAMPAIGN_STATUS_AR, dateAr, fmt, iqd } from '@/lib/format';
import { Bar, Empty, Sheet, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

type Campaign = { id: string; name: string; goal_type: string; goal_visits: number; audience: string; bonus_points: number; cpv_iqd: number;
  budget_iqd: number; spent_iqd: number; generated_visits: number; status: string; starts_at: string | null; ends_at: string | null;
  schedule: { days?: number[]; from?: string; to?: string; days_count?: number }; cost_per_visit_iqd: number | null };

const GOALS: Record<string, string> = { new_visits: 'زبائن جدد', quiet_hours: 'ملي الأوقات الهادئة', win_back: 'رجّع الزبائن الغايبين', new_branch: 'افتتاح فرع' };
const STATUS = CAMPAIGN_STATUS_AR;
const DAYS = ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'];

export function Campaigns() {
  const { id, home } = useMerchant();
  const [params] = useSearchParams();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const list = useQuery({ queryKey: ['mcamp', id], queryFn: () => rpc<Campaign[]>('merchant_campaigns', { merchant: id }) });
  const cpv = home.settings?.cpv_iqd ?? 1500;
  const quiet = params.get('quiet');
  const blank = () => ({
    name: quiet ? 'ساعات الهدوء' : 'زبائن جدد', goal_type: quiet ? 'quiet_hours' : 'new_visits', goal_visits: 100, audience: 'new',
    bonus_points: 150, days_count: quiet ? 3 : 7, days: [0, 1, 2, 3, 4, 5, 6], from: quiet ? `${String(quiet).padStart(2, '0')}:00` : '', to: quiet ? `${String(Number(quiet) + 2).padStart(2, '0')}:00` : '',
    radius_km: 2,
  });
  const [open, setOpen] = useState(!!quiet);
  const [step, setStep] = useState(1);
  const [w, setW] = useState(blank);
  const [est, setEst] = useState<{ low: number; high: number; audience: number } | null>(null);
  useEffect(() => {
    if (!open) return;
    const t = setTimeout(() => rpc<{ low: number; high: number; audience: number }>('campaign_estimate', { merchant: id, radius_km: w.radius_km, days: w.days_count, bonus: w.bonus_points }).then(setEst).catch(() => {}), 300);
    return () => clearTimeout(t);
  }, [open, w.radius_km, w.days_count, w.bonus_points, id]);
  const budget = w.goal_visits * cpv;

  const submit = () => run(async () => {
    const schedule: Record<string, unknown> = { days_count: w.days_count };
    if (w.days.length < 7) schedule.days = w.days;
    if (w.from && w.to) { schedule.from = w.from; schedule.to = w.to; }
    const cid = await rpc<string>('campaign_save', { merchant: id, draft: { name: w.name, goal_type: w.goal_type, goal_visits: w.goal_visits, audience: w.audience,
      radius_km: w.radius_km, schedule, bonus_points: w.bonus_points, budget_iqd: budget }, campaign: null });
    await rpc('campaign_submit', { campaign: cid });
    await qc.invalidateQueries({ queryKey: ['mcamp', id] });
    setOpen(false); setStep(1); setW(blank());
  }, 'وصلت الحملة لفريق AMOUNI للموافقة');
  const pause = (c: Campaign) => run(async () => { await rpc('campaign_pause', { campaign: c.id, pause: c.status === 'running' }); await qc.invalidateQueries({ queryKey: ['mcamp', id] }); });

  return (
    <>
      <div className="main-h"><div><h1>الحملات</h1><p className="muted">قول شنو تريد، وAMOUNI يحوّله لنقاط إضافية تجيب الناس. تدفع بس على كل زبون جديد يجي فعلاً.</p></div>
        <button className="btn primary" onClick={() => setOpen(true)}><Icon name="plus" /> حملة جديدة</button></div>
      {list.isLoading ? <Spinner /> : !list.data?.length ? <Empty title="ما سويت حملة بعد" icon="bolt">أول حملة تكدر تبديها بـ 100 زبون جديد.</Empty> : (
        <div className="grid2">{list.data.map((c) => (
          <div className="card" key={c.id}>
            <div className="row between"><h3>{c.name}</h3><span className={`chip ${STATUS[c.status]?.[1]}`}>{STATUS[c.status]?.[0]}</span></div>
            <p className="small muted">{GOALS[c.goal_type]} · +{c.bonus_points} نقطة {c.audience === 'new' ? 'للجدد' : c.audience === 'lapsed' ? 'للغايبين' : 'للكل'}{c.schedule.from ? ` · ${c.schedule.from}–${c.schedule.to}` : ''}</p>
            <div className="row small" style={{ marginTop: 12 }}><span className="grow"><Bar pct={(c.generated_visits / c.goal_visits) * 100} /></span><b className="num">{c.generated_visits}/{c.goal_visits}</b></div>
            <dl className="kv small" style={{ marginTop: 10 }}>
              <dt>صرفت</dt><dd className="num">{iqd(c.spent_iqd)} من {iqd(c.budget_iqd)}</dd>
              <dt>كلفة الزبون</dt><dd className="num">{c.cost_per_visit_iqd ? iqd(c.cost_per_visit_iqd) : iqd(c.cpv_iqd) + ' (متفق عليها)'}</dd>
              {c.starts_at && <><dt>الفترة</dt><dd>{dateAr(c.starts_at)} – {c.ends_at ? dateAr(c.ends_at) : '…'}</dd></>}
            </dl>
            {['running', 'paused'].includes(c.status) && <button className="btn sm" style={{ marginTop: 10 }} disabled={busy} onClick={() => pause(c)}>{c.status === 'running' ? 'إيقاف مؤقت' : 'تشغيل'}</button>}
          </div>
        ))}</div>
      )}

      <Sheet open={open} onClose={() => setOpen(false)} center>
        <div className="stack">
          <div className="row between"><h2>حملة جديدة</h2><span className="small muted num">{step}/4</span></div>
          <Bar pct={step * 25} />
          {step === 1 && <>
            <label className="field">شنو هدفك؟<select className="in" value={w.goal_type} onChange={(e) => setW({ ...w, goal_type: e.target.value })}>{Object.entries(GOALS).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
            <label className="field">كم زبون تريد؟<input className="in num" type="number" min={10} max={5000} value={w.goal_visits} onChange={(e) => setW({ ...w, goal_visits: Number(e.target.value) })} /></label>
            <label className="field">اسم الحملة<input className="in" value={w.name} onChange={(e) => setW({ ...w, name: e.target.value })} /></label>
          </>}
          {step === 2 && <>
            <label className="field">منو تستهدف؟<div className="seg">{[['new', 'زبائن جدد'], ['lapsed', 'الغايبين'], ['all', 'الكل']].map(([k, v]) => <button type="button" key={k} className={w.audience === k ? 'on' : ''} onClick={() => setW({ ...w, audience: k })}>{v}</button>)}</div></label>
            <label className="field">مدة الحملة (أيام)<input className="in num" type="number" min={1} max={60} value={w.days_count} onChange={(e) => setW({ ...w, days_count: Number(e.target.value) })} /></label>
            <div className="field">الأيام<div className="row">{DAYS.map((d, i) => <button type="button" key={i} className={`chip ${w.days.includes(i) ? 'on' : ''}`} onClick={() => setW({ ...w, days: w.days.includes(i) ? w.days.filter((x) => x !== i) : [...w.days, i] })}>{d}</button>)}</div></div>
            <div className="row"><label className="field grow">من<input className="in" type="time" value={w.from} onChange={(e) => setW({ ...w, from: e.target.value })} /></label><label className="field grow">إلى<input className="in" type="time" value={w.to} onChange={(e) => setW({ ...w, to: e.target.value })} /></label></div>
            <p className="small muted">اترك الوقت فارغ إذا تريدها طول ساعات الدوام.</p>
          </>}
          {step === 3 && <>
            <label className="field">نقاط إضافية لكل زيارة: <b className="num">+{w.bonus_points}</b><input type="range" min={50} max={300} step={10} value={w.bonus_points} onChange={(e) => setW({ ...w, bonus_points: Number(e.target.value) })} /></label>
            <label className="field">نطاق الوصول (كم)<input className="in num" type="number" min={0.5} max={25} step={0.5} value={w.radius_km} onChange={(e) => setW({ ...w, radius_km: Number(e.target.value) })} /></label>
            <div className="card tint flat small">النقاط تدفعها AMOUNI للزبون. إنت تدفع <b className="num">{iqd(cpv)}</b> بس على كل زبون جديد يوصل فعلاً.</div>
          </>}
          {step === 4 && <>
            <div className="card flat"><dl className="kv">
              <dt>الهدف</dt><dd>{GOALS[w.goal_type]} · <span className="num">{w.goal_visits}</span></dd>
              <dt>الجمهور</dt><dd>{w.audience === 'new' ? 'زبائن جدد' : w.audience === 'lapsed' ? 'الغايبين' : 'الكل'}</dd>
              <dt>الوقت</dt><dd>{w.days_count} يوم{w.from ? ` · ${w.from}–${w.to}` : ''}</dd>
              <dt>المكافأة</dt><dd className="num">+{w.bonus_points} نقطة</dd>
              <dt>الحد الأعلى للكلفة</dt><dd className="num">{iqd(budget)}</dd>
            </dl></div>
            {est && <div className="card gold center"><div className="eyebrow">التقدير</div><b className="num" style={{ fontSize: 26, fontFamily: 'var(--f-display)' }}>{fmt(est.low)}–{fmt(est.high)} زيارة</b><div className="small muted">من حوالي {fmt(est.audience)} مستخدم نشط قريب</div></div>}
          </>}
          <div className="row">
            {step > 1 && <button className="btn" onClick={() => setStep(step - 1)}>رجوع</button>}
            <span className="grow" />
            {step < 4 ? <button className="btn primary" onClick={() => setStep(step + 1)}>التالي</button>
                      : <button className="btn gold" disabled={busy} onClick={submit}>أرسل للموافقة</button>}
          </div>
        </div>
      </Sheet>
    </>
  );
}
