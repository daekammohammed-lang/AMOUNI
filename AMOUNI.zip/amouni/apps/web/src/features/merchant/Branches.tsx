import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, supabase } from '@/lib/api';
import { AmouniMap } from '@/ui/Map';
import { Sheet, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

export function Branches() {
  const { id, home } = useMerchant();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ name: '', address: '', geofence: 60 });
  const first = home.branches[0];
  const [pos, setPos] = useState<{ lat: number; lng: number }>({ lat: first?.lat ?? 33.4262, lng: first?.lng ?? 43.3001 });
  const cities = useQuery({ queryKey: ['cities'], queryFn: async () => (await supabase.from('cities').select('id,name_ar')).data ?? [] });
  const refresh = () => qc.invalidateQueries({ queryKey: ['merchant', id] });

  const toggleCashier = (b: { id: string; cashier_mode: boolean }) =>
    run(async () => { await rpc('branch_set_cashier_mode', { branch: b.id, on: !b.cashier_mode }); await refresh(); }, !b.cashier_mode ? 'شغّلنا وضع الكاشير' : 'وقّفنا وضع الكاشير');
  const add = (e: React.FormEvent) => {
    e.preventDefault();
    run(async () => {
      await rpc('merchant_add_branch', { merchant: id, name: f.name, city: cities.data?.[0]?.id, lat: pos.lat, lng: pos.lng, address: f.address || null, district: null, geofence_m: f.geofence, hours: {} });
      await refresh(); setAdding(false);
    }, 'انضاف الفرع');
  };

  return (
    <>
      <div className="main-h"><div><h1>الفروع</h1><p className="muted">كل فرع إله موقع وسياج تحقق وباركود خاص.</p></div>
        {home.role === 'owner' && <button className="btn primary" onClick={() => setAdding(true)}><Icon name="plus" /> فرع جديد</button>}</div>
      <div className="grid2">
        {home.branches.map((b) => (
          <div className="card" key={b.id}>
            <div className="row between"><h3>{b.name}</h3><span className={`chip ${b.status === 'active' ? 'ok' : 'amber'}`}>{b.status === 'active' ? 'فعّال' : b.status}</span></div>
            <p className="small muted">{b.address ?? '—'}</p>
            <dl className="kv" style={{ marginTop: 10 }}>
              <dt>السياج</dt><dd className="num">{b.geofence_m} م</dd>
              <dt>فرص شغّالة</dt><dd className="num">{b.live_spots}</dd>
              <dt>باركود فعّال</dt><dd className="num">{b.qr_active}</dd>
            </dl>
            <div className="row between" style={{ marginTop: 12, borderTop: '1px solid var(--line)', paddingTop: 12 }}>
              <div><b>وضع الكاشير</b><div className="small muted">شاشة بباركود يتغيّر كل 30 ثانية + تأكيد المسحات المشكوك بيها</div></div>
              <button className={`toggle ${b.cashier_mode ? 'on' : ''}`} aria-label="وضع الكاشير" disabled={busy} onClick={() => toggleCashier(b)} />
            </div>
          </div>
        ))}
      </div>
      <Sheet open={adding} onClose={() => setAdding(false)} center>
        <form className="stack" onSubmit={add}>
          <h2>فرع جديد</h2>
          <label className="field">اسم الفرع<input className="in" required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
          <label className="field">العنوان<input className="in" value={f.address} onChange={(e) => setF({ ...f, address: e.target.value })} /></label>
          <label className="field">نصف قطر السياج (متر)<input className="in num" type="number" min={15} max={500} value={f.geofence} onChange={(e) => setF({ ...f, geofence: Number(e.target.value) })} /></label>
          <div className="mapbox" style={{ height: 240 }}><AmouniMap center={pos} points={[{ id: 'b', lat: pos.lat, lng: pos.lng, category: home.merchant.category }]} onPick={setPos} zoom={15} /></div>
          <span className="small muted">اضغط على الخريطة لتحديد مكان الفرع بالضبط.</span>
          <button className="btn primary block" disabled={busy}>أضف الفرع</button>
        </form>
      </Sheet>
    </>
  );
}
