import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { ago, fmt, iqd } from '@/lib/format';
import { Kpi, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { useMerchant } from './MerchantApp';

export type Stats = {
  generated_visits: number; verified_visits: number; returning_visits: number; scans: number; rejected_scans: number; redemptions: number;
  campaign_cost_iqd: number; cost_per_generated_visit_iqd: number | null; estimated_revenue_iqd: number | null; return_rate_30d: number;
  by_day: { day: string; verified: number; generated: number }[]; quiet_hours: number[];
};
type Visit = { at: string; generated: boolean; branch: string; customer: string; campaign: string | null };
type Tip = { id: string; kind: string; payload: { tip_ar?: string; amount?: number; hours?: number; branch?: string }; status: string; at: string };

export function Dashboard() {
  const { id, home } = useMerchant();
  const [days, setDays] = useState(7);
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const stats = useQuery({ queryKey: ['mstats', id, days], queryFn: () => rpc<Stats>('merchant_stats', { merchant: id, days }), refetchInterval: 60_000 });
  const visits = useQuery({ queryKey: ['mvisits', id], queryFn: () => rpc<Visit[]>('merchant_recent_visits', { merchant: id, limit: 8 }), refetchInterval: 60_000 });
  const tips = useQuery({ queryKey: ['mtips', id], queryFn: () => rpc<Tip[]>('merchant_tips', { merchant: id }) });
  const [ticket, setTicket] = useState('');
  const s = stats.data;
  if (!s) return <Spinner />;
  const roi = s.estimated_revenue_iqd && s.campaign_cost_iqd ? s.estimated_revenue_iqd / s.campaign_cost_iqd : null;
  const max = Math.max(1, ...s.by_day.map((d) => d.verified));
  const quiet = s.quiet_hours.length ? s.quiet_hours[0] : null;

  return (
    <>
      <div className="main-h">
        <div><div className="eyebrow">{home.merchant.name}</div><h1>شنو جابلك AMOUNI؟</h1></div>
        <div className="seg" style={{ minWidth: 220 }}>{[7, 30].map((d) => <button key={d} className={days === d ? 'on' : ''} onClick={() => setDays(d)}>آخر {d} يوم</button>)}</div>
      </div>

      <div className="grid4">
        <Kpi hl v={fmt(s.generated_visits)} l="زبون جديد جابه AMOUNI" />
        <Kpi v={fmt(s.verified_visits)} l="زيارة موثقة (جدد + راجعين)" />
        <Kpi v={fmt(s.scans)} l={`مسح للباركود${s.rejected_scans ? ` · ${s.rejected_scans} مرفوض` : ''}`} />
        <Kpi v={fmt(s.redemptions)} l="جائزة استبدلوها عندك" />
      </div>

      <div className="grid3" style={{ marginTop: 14 }}>
        <div className="card"><div className="eyebrow">صرفت على الحملات</div><div className="num" style={{ fontSize: 24, fontFamily: 'var(--f-display)', marginTop: 4 }}>{iqd(s.campaign_cost_iqd)}</div>
          <div className="small muted">{s.cost_per_generated_visit_iqd ? `${iqd(s.cost_per_generated_visit_iqd)} لكل زبون جديد` : 'بدون حملات مدفوعة بهالفترة'}</div></div>
        <div className="card"><div className="eyebrow">دخل تقديري من الزبائن الجدد</div>
          {s.estimated_revenue_iqd !== null ? <><div className="num" style={{ fontSize: 24, fontFamily: 'var(--f-display)', marginTop: 4, color: 'var(--ok)' }}>{iqd(s.estimated_revenue_iqd)}</div>
            <div className="small muted">{roi ? `كل دينار صرفته رجع ${roi.toFixed(1)} تقريباً` : 'على أساس متوسط فاتورتك'}</div></>
          : <form className="row" style={{ marginTop: 8 }} onSubmit={(e) => { e.preventDefault(); run(async () => { await rpc('merchant_set_settings', { merchant: id, avg_ticket_iqd: Number(ticket) }); qc.invalidateQueries({ queryKey: ['mstats'] }); }, 'انحفظ'); }}>
              <input className="in num" inputMode="numeric" placeholder="متوسط الفاتورة د.ع" value={ticket} onChange={(e) => setTicket(e.target.value.replace(/\D/g, ''))} /><button className="btn sm primary" disabled={busy || !ticket}>احفظ</button></form>}
        </div>
        <div className="card"><div className="eyebrow">رجعوا خلال 30 يوم</div><div className="num" style={{ fontSize: 24, fontFamily: 'var(--f-display)', marginTop: 4 }}>{fmt(s.return_rate_30d)}</div><div className="small muted">من الزبائن الجدد اللي جابهم AMOUNI</div></div>
      </div>

      <div className="grid2" style={{ marginTop: 14 }}>
        <div className="card">
          <div className="row between"><h3>الزيارات يومياً</h3><span className="small muted"><span className="chip primary" style={{ padding: '0 6px' }}>■</span> جدد</span></div>
          {s.by_day.length ? <div className="bars">{s.by_day.map((d) => (
            <div className="b" key={d.day} title={`${d.day}: ${d.verified} زيارة، ${d.generated} جدد`}>
              <span className="num">{d.verified}</span>
              <i style={{ height: `${(d.verified / max) * 100}%` }}><i className="g" style={{ height: `${d.verified ? (d.generated / d.verified) * 100 : 0}%`, position: 'absolute', bottom: 0, left: 0, right: 0, borderRadius: 7 }} /></i>
              <span>{d.day.slice(5)}</span>
            </div>))}</div> : <p className="muted" style={{ padding: '30px 0' }}>ماكو زيارات بهالفترة بعد.</p>}
        </div>
        <div className="card">
          <h3>آخر الزيارات</h3>
          <div className="list" style={{ marginTop: 6 }}>{(visits.data ?? []).map((v, i) => (
            <div className="it" key={i}><span className={`chip ${v.generated ? 'primary' : ''}`}>{v.generated ? 'جديد' : 'راجع'}</span><div className="grow">{v.customer}<div className="small muted">{v.branch}{v.campaign ? ` · ${v.campaign}` : ''}</div></div><span className="small muted">{ago(v.at)}</span></div>
          ))}{!visits.data?.length && <p className="muted small" style={{ padding: '20px 0' }}>أول زيارة راح تظهر هنا مباشرة.</p>}</div>
        </div>
      </div>

      {(quiet !== null || !!tips.data?.length) && (
        <div className="stack" style={{ marginTop: 14 }}>
          {quiet !== null && (
            <div className="card tint row"><Icon name="bolt" size={26} /><div className="grow"><b>حركتك أقل من المعتاد حوالي الساعة {quiet}:00</b><div className="small muted">حملة قصيرة بنقاط إضافية للزبائن الجدد بهالوقت تملي المحل.</div></div>
              <Link className="btn primary sm" to={`/merchant/campaigns?quiet=${quiet}`}>جهّز حملة</Link></div>
          )}
          {tips.data?.map((t) => (
            <div className="card row" key={t.id}><Icon name="cpu" size={24} /><div className="grow"><div className="eyebrow">اقتراح AMOUNI</div>
              <div>{t.kind === 'traffic_balance' ? `المحل هادئ هسه، ${t.status === 'applied' ? 'فعّلنا' : 'نقترح'} +${t.payload.amount} نقطة لمدة ${t.payload.hours} ساعة على ${t.payload.branch}` : t.payload.tip_ar}</div></div>
              <span className={`chip ${t.status === 'applied' ? 'ok' : ''}`}>{t.status === 'applied' ? 'مفعّل' : 'اقتراح'}</span></div>
          ))}
        </div>
      )}
    </>
  );
}
