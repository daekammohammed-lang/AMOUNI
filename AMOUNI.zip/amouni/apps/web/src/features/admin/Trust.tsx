import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { ago, fmt } from '@/lib/format';
import { Empty, Spinner, useAsync } from '@/ui/kit';

type Item = { id: string; decision: string; trust_score: number; points: number; created_at: string; phone: string; display_name: string | null;
  account_created: string; account_trust: number; branch: string; merchant: string; distance_m: number | null; accuracy_m: number | null;
  signals: { signal: string; points: number; evidence: Record<string, unknown> }[] | null; user_rejections: number };

const SIG_AR: Record<string, string> = {
  location_edge: 'على حافة السياج', gps_accuracy: 'دقة GPS ضعيفة', no_session: 'مسح بدون لقطة', no_trail: 'ماكو مسار حركة', arrival_too_fast: 'وصل أسرع من الممكن',
  impossible_travel: 'انتقال مستحيل', velocity: 'زيارات كثيرة بوقت قصير', shared_device: 'جهاز مشترك', new_account_high_value: 'حساب جديد وفرصة غالية',
  qr_leak_suspect: 'الباركود منتشر', collusion: 'تكرار بنفس التاجر', low_account_trust: 'ثقة الحساب واطئة', vpn_datacenter: 'VPN / سيرفر',
  mock_location: 'موقع مزيّف', device_integrity_fail: 'سلامة الجهاز فشلت',
};

export function Trust() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['a-trust'], queryFn: () => rpc<Item[]>('admin_review_queue', { limit: 100 }), refetchInterval: 30_000 });
  const [reasons, setReasons] = useState<Record<string, string>>({});
  const decide = (it: Item, approve: boolean) => run(async () => {
    await rpc('admin_resolve_scan', { scan: it.id, approve, reason: reasons[it.id] || (approve ? 'checked and verified' : 'fraud signals confirmed') });
    await qc.invalidateQueries({ queryKey: ['a-trust'] });
  }, approve ? 'انثبتت النقاط' : 'انرفض المسح');

  return (
    <>
      <div className="main-h"><div><h1>طابور المراجعة</h1><p className="muted">مسحات معلّقة أو تحتاج قرار بشري. ما في حظر تلقائي من إشارة وحدة — القرار إلك ويتسجّل بالتدقيق.</p></div></div>
      {q.isLoading ? <Spinner /> : !q.data?.length ? <Empty title="الطابور فارغ" icon="shield">كل المسحات تمام.</Empty> : (
        <div className="grid2">{q.data.map((it) => (
          <div className="card" key={it.id}>
            <div className="row between"><div><b>{it.display_name ?? '—'}</b> <span className="small muted num" dir="ltr">{it.phone}</span><div className="small muted">{it.merchant} · {it.branch} · {ago(it.created_at)}</div></div>
              <span className={`chip ${it.trust_score >= 41 ? 'amber' : 'warn'}`}>Trust {it.trust_score}</span></div>
            <div className="wrap-row" style={{ marginTop: 10 }}>{(it.signals ?? []).map((s) => <span className="chip" key={s.signal}>{SIG_AR[s.signal] ?? s.signal} +{s.points}</span>)}</div>
            <dl className="kv small" style={{ marginTop: 10 }}>
              <dt>القرار المؤقت</dt><dd>{it.decision === 'held' ? 'معلّق 24 ساعة' : 'مراجعة'}</dd>
              <dt>النقاط</dt><dd className="num">{fmt(it.points)}</dd>
              <dt>المسافة / الدقة</dt><dd className="num">{it.distance_m ?? '—'} م / {it.accuracy_m ? Math.round(it.accuracy_m) : '—'} م</dd>
              <dt>عمر الحساب</dt><dd>{ago(it.account_created)} · ثقة {it.account_trust}</dd>
              <dt>رفض سابق</dt><dd className="num">{it.user_rejections}</dd>
            </dl>
            <input className="in" style={{ marginTop: 10 }} placeholder="سبب القرار (يُسجّل)" value={reasons[it.id] ?? ''} onChange={(e) => setReasons({ ...reasons, [it.id]: e.target.value })} />
            <div className="row" style={{ marginTop: 10 }}><button className="btn primary grow" disabled={busy} onClick={() => decide(it, true)}>ثبّت النقاط</button><button className="btn danger" disabled={busy} onClick={() => decide(it, false)}>رفض</button></div>
          </div>
        ))}</div>
      )}
    </>
  );
}
