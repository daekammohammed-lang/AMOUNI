import { useState } from 'react';
import { useInfiniteQuery, useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { ago } from '@/lib/format';
import { Kpi, Sheet, Spinner, useAsync } from '@/ui/kit';

type Audit = { id: number; at: string; actor: string; action: string; entity: string; entity_id: string; before: unknown; after: unknown; reason: string | null };
type Health = { db_size_mb: number; pending_held: number; pending_review: number; oldest_pending_minutes: number | null; scans_last_hour: number;
  rejections_last_hour: number; qr_disabled_24h: number; active_hunts: number; jobs: { job: string; last_run: string | null; status: string | null }[]; checked_at: string };
type Cfg = { key: string; value: unknown; description: string; updated_at: string };

export function System({ superAdmin }: { superAdmin: boolean }) {
  const [tab, setTab] = useState<'audit' | 'health' | 'config'>('audit');
  return (
    <>
      <div className="main-h"><h1>التدقيق والنظام</h1>
        <div className="seg">{([['audit', 'سجل التدقيق'], ['health', 'صحة النظام'], ...(superAdmin ? [['config', 'الإعدادات']] : [])] as [typeof tab, string][]).map(([k, v]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{v}</button>)}</div></div>
      {tab === 'audit' ? <AuditLog /> : tab === 'health' ? <HealthView /> : <Config />}
    </>
  );
}

function AuditLog() {
  const q = useInfiniteQuery({
    queryKey: ['a-audit'], initialPageParam: null as number | null,
    queryFn: ({ pageParam }) => rpc<Audit[]>('admin_audit', { before: pageParam, limit: 50 }),
    getNextPageParam: (last) => (last.length === 50 ? last[last.length - 1].id : null),
  });
  const rows = q.data?.pages.flat() ?? [];
  if (q.isLoading) return <Spinner />;
  return (
    <div className="card tbl-wrap">
      <p className="small muted" style={{ marginBottom: 8 }}>السجل ما ينعدل ولا ينحذف، حتى من مدير قاعدة البيانات.</p>
      <table className="tbl"><thead><tr><th>الوقت</th><th>منو</th><th>شنو</th><th>على</th><th>السبب</th><th>التفاصيل</th></tr></thead>
        <tbody>{rows.map((a) => (
          <tr key={a.id}><td className="small">{ago(a.at)}</td><td>{a.actor}</td><td><code>{a.action}</code></td><td className="small">{a.entity}</td><td className="small">{a.reason ?? ''}</td>
            <td className="small muted" style={{ maxWidth: 320, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }} dir="ltr">{a.after ? JSON.stringify(a.after) : ''}</td></tr>
        ))}</tbody></table>
      {q.hasNextPage && <button className="btn block" style={{ marginTop: 10 }} onClick={() => q.fetchNextPage()}>أقدم</button>}
    </div>
  );
}

function HealthView() {
  const h = useQuery({ queryKey: ['a-health'], queryFn: () => rpc<Health>('admin_health'), refetchInterval: 20_000 });
  if (!h.data) return <Spinner />;
  const x = h.data;
  return (
    <>
      <div className="grid4">
        <Kpi v={x.scans_last_hour} l="مسح بآخر ساعة" /><Kpi v={x.rejections_last_hour} l="مرفوض بآخر ساعة" />
        <Kpi v={x.pending_held + x.pending_review} l={`معلّق ${x.pending_held} · مراجعة ${x.pending_review}`} /><Kpi v={x.oldest_pending_minutes ?? '—'} l="أقدم طلب معلّق (دقيقة)" />
      </div>
      <div className="grid4" style={{ marginTop: 12 }}>
        <Kpi v={x.active_hunts} l="لقطات شغّالة" /><Kpi v={x.qr_disabled_24h} l="باركود توقف تلقائياً (24 س)" /><Kpi v={`${x.db_size_mb} MB`} l="حجم قاعدة البيانات" /><Kpi v={ago(x.checked_at)} l="آخر فحص" />
      </div>
      <div className="card" style={{ marginTop: 12 }}><h3>المهام المجدولة</h3>
        {x.jobs.length ? <table className="tbl"><tbody>{x.jobs.map((j) => <tr key={j.job}><td><code>{j.job}</code></td><td>{j.last_run ? ago(j.last_run) : '—'}</td><td><span className={`chip ${j.status === 'succeeded' ? 'ok' : 'amber'}`}>{j.status ?? '—'}</span></td></tr>)}</tbody></table>
          : <p className="small muted">pg_cron مو مفعّل بهالبيئة. فعّله من Supabase → Extensions حتى تشتغل المهام تلقائياً.</p>}</div>
    </>
  );
}

function Config() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['a-config'], queryFn: () => rpc<Cfg[]>('admin_config') });
  const [edit, setEdit] = useState<Cfg | null>(null);
  const [val, setVal] = useState(''); const [reason, setReason] = useState('');
  const save = () => edit && run(async () => {
    await rpc('admin_set_config', { key: edit.key, value: JSON.parse(val), reason }); await qc.invalidateQueries({ queryKey: ['a-config'] }); setEdit(null);
  }, 'انحفظ وانسجل بالتدقيق');
  if (q.isLoading) return <Spinner />;
  return (
    <>
      <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>المفتاح</th><th>القيمة</th><th>الوصف</th><th /></tr></thead>
        <tbody>{q.data?.map((c) => <tr key={c.key}><td><code>{c.key}</code></td><td className="num" dir="ltr">{JSON.stringify(c.value)}</td><td className="small muted">{c.description}</td>
          <td><button className="btn sm" onClick={() => { setEdit(c); setVal(JSON.stringify(c.value)); setReason(''); }}>تعديل</button></td></tr>)}</tbody></table></div>
      <Sheet open={!!edit} onClose={() => setEdit(null)} center>
        {edit && <div className="stack"><h2><code>{edit.key}</code></h2><p className="small muted">{edit.description}</p>
          <input className="in num" dir="ltr" value={val} onChange={(e) => setVal(e.target.value)} />
          <input className="in" placeholder="السبب" value={reason} onChange={(e) => setReason(e.target.value)} />
          <button className="btn primary" disabled={busy || reason.length < 3} onClick={save}>احفظ</button></div>}
      </Sheet>
    </>
  );
}
