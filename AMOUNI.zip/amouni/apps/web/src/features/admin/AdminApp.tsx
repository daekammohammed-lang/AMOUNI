import { Link, Navigate, NavLink, Route, Routes } from 'react-router-dom';
import { useRoles } from '@/app/session';
import { Spinner } from '@/ui/kit';
import { Icon, type IconName } from '@/ui/icons';
import { Economy, Overview } from './Overview';
import { Users } from './Users';
import { Merchants } from './Merchants';
import { AdminCampaigns } from './AdminCampaigns';
import { Trust } from './Trust';
import { Catalog } from './Catalog';
import { AiCenter } from './AiCenter';
import { System } from './System';

// Which platform roles see which section (the server enforces the same rules on every call).
const NAV: [string, IconName, string, string[]][] = [
  ['', 'chart', 'نظرة عامة', ['ops', 'finance', 'fraud_analyst']],
  ['trust', 'shield', 'الثقة والاحتيال', ['fraud_analyst', 'ops']],
  ['merchants', 'store', 'التجار', ['ops', 'finance']],
  ['campaigns', 'bolt', 'الحملات', ['ops', 'finance']],
  ['catalog', 'gift', 'الفرص والجوائز والمهام', ['ops']],
  ['users', 'users', 'المستخدمين', ['ops', 'fraud_analyst', 'support', 'finance']],
  ['economy', 'coin', 'اقتصاد النقاط', ['finance', 'ops']],
  ['ai', 'cpu', 'اقتراحات AI', ['ops']],
  ['system', 'settings', 'التدقيق والنظام', ['ops', 'finance', 'fraud_analyst']],
];

export default function AdminApp() {
  const roles = useRoles();
  if (roles.isLoading) return <Spinner />;
  const mine = roles.data?.platform_roles ?? [];
  if (!mine.length) return <Navigate to="/app" replace />;
  const can = (need: string[]) => mine.includes('super_admin') || need.some((r) => mine.includes(r));
  const nav = NAV.filter((n) => can(n[3]));

  return (
    <div className="console">
      <aside className="side">
        <div className="brand"><img src="/logo-mark.webp" alt="" />AMOUNI <span className="chip" style={{ background: 'rgba(224,174,69,.25)', color: '#F6D58C', letterSpacing: 0 }}>مركز القيادة</span></div>
        {nav.map(([to, icon, label]) => <NavLink key={to} to={`/admin/${to}`} end={to === ''}><Icon name={icon} />{label}</NavLink>)}
        <Link to="/app" style={{ marginTop: 8 }}><Icon name="home" />تطبيق المستخدم</Link>
        <div className="foot">{roles.data?.display_name}<br />{mine.join(' · ')}</div>
      </aside>
      <main className="main">
        <Routes>
          <Route index element={<Overview />} />
          <Route path="trust" element={<Trust />} />
          <Route path="merchants" element={<Merchants />} />
          <Route path="campaigns" element={<AdminCampaigns />} />
          <Route path="catalog" element={<Catalog />} />
          <Route path="users" element={<Users canAdjust={can(['finance'])} />} />
          <Route path="economy" element={<Economy />} />
          <Route path="ai" element={<AiCenter />} />
          <Route path="system" element={<System superAdmin={mine.includes('super_admin')} />} />
        </Routes>
      </main>
    </div>
  );
}
