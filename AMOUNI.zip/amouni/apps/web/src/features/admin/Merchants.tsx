import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { CATEGORY_AR, dateAr } from '@/lib/format';
import { Sheet, Spinner, useAsync } from '@/ui/kit';

type M = { id: string; display_name: string; category: string; status: string; plan: string; created_at: string; owner: string | null;
  branches: number; visits_30d: number; generated_30d: number; reject_reason: string | null; branch_list: { id: string; name: string }[] | null };
const ST: Record<string, [string, string]> = { pending: ['بانتظار الموافقة', 'amber'], active: ['فعّال', 'ok'], suspended: ['موقوف', 'warn'], rejected: ['مرفوض', 'warn'] };

export function Merchants() {
  const [filter, setFilter] = useState<string | null>(null);
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const list = useQuery({ queryKey: ['a-merchants', filter], queryFn: () => rpc<M[]>('admin_merchants', { status: filter }) });
  const [sel, setSel] = useState<M | null>(null);
  const [f, setF] = useState({ reason: '', plan: 'basic', title: '', points: 60 });
  const decide = (approve: boolean) => sel && run(async () => {
    await rpc('admin_merchant_decide', { merchant: sel.id, approve, reason: f.reason || (approve ? 'verified' : 'rejected'), plan: f.plan });
    if (approve && f.title && sel.branch_list?.[0]) {
      await rpc('admin_spot_create', { branch: sel.branch_list[0].id, title: f.title, kind: 'normal', base_points: f.points, qty: null, instant_reward: null,
        requires_dynamic: false, mystery_radius_m: null, starts: new Date().toISOString(), ends: null, cap_points: 500 });
    }
    await qc.invalidateQueries({ queryKey: ['a-merchants'] }); setSel(null);
  }, approve ? 'التاجر صار فعّال' : 'انرفض الطلب');

  return (
    <>
      <div className="main-h"><h1>التجار</h1>
        <div className="seg">{[[null, 'الكل'], ['pending', 'بانتظار'], ['active', 'فعّال'], ['rejected', 'مرفوض']].map(([k, v]) => <button key={v} className={filter === k ? 'on' : ''} onClick={() => setFilter(k)}>{v}</button>)}</div></div>
      {list.isLoading ? <Spinner /> : (
        <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>المحل</th><th>النوع</th><th>الحالة</th><th>الباقة</th><th>فروع</th><th>زيارات 30 يوم</th><th>منهم جدد</th><th>التسجيل</th><th /></tr></thead>
          <tbody>{list.data?.map((m) => (
            <tr key={m.id}><td><b>{m.display_name}</b><div className="small muted">{m.owner}</div></td><td>{CATEGORY_AR[m.category]}</td>
              <td><span className={`chip ${ST[m.status][1]}`}>{ST[m.status][0]}</span></td><td>{m.plan}</td><td className="num">{m.branches}</td>
              <td className="num">{m.visits_30d}</td><td className="num">{m.generated_30d}</td><td>{dateAr(m.created_at)}</td>
              <td>{m.status === 'pending' && <button className="btn sm primary" onClick={() => { setSel(m); setF({ reason: '', plan: 'basic', title: `لقطة ${m.display_name}`, points: 60 }); }}>مراجعة</button>}</td></tr>
          ))}</tbody></table></div>
      )}
      <Sheet open={!!sel} onClose={() => setSel(null)} center>
        {sel && <div className="stack">
          <h2>{sel.display_name}</h2>
          <p className="muted small">{CATEGORY_AR[sel.category]} · {sel.branch_list?.map((b) => b.name).join('، ')}</p>
          <label className="field">الباقة<select className="in" value={f.plan} onChange={(e) => setF({ ...f, plan: e.target.value })}>{['free', 'basic', 'silver', 'gold'].map((p) => <option key={p}>{p}</option>)}</select></label>
          <div className="card flat stack" style={{ gap: 8 }}>
            <b>أول فرصة (اختياري)</b>
            <input className="in" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
            <label className="field">نقاط الأساس (تحددها AMOUNI)<input className="in num" type="number" min={10} max={500} value={f.points} onChange={(e) => setF({ ...f, points: Number(e.target.value) })} /></label>
          </div>
          <label className="field">ملاحظة / سبب<input className="in" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} /></label>
          <div className="row"><button className="btn primary grow" disabled={busy} onClick={() => decide(true)}>قبول وتفعيل</button><button className="btn danger" disabled={busy || f.reason.length < 3} onClick={() => decide(false)}>رفض</button></div>
        </div>}
      </Sheet>
    </>
  );
}
