import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { ago } from '@/lib/format';
import { Empty, Spinner, useAsync, useToast } from '@/ui/kit';
import { Icon } from '@/ui/icons';

type Rec = { id: string; kind: string; subject_type: string; subject_id: string; payload: Record<string, string | number>; reasons: string[];
  status: string; rule_check: { ok: boolean; daily_used?: number; daily_cap?: number; note?: string } | null; at: string };

export function AiCenter() {
  const [status, setStatus] = useState('proposed');
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const toast = useToast();
  const q = useQuery({ queryKey: ['a-ai', status], queryFn: () => rpc<Rec[]>('admin_ai_list', { status }) });
  const refresh = () => qc.invalidateQueries({ queryKey: ['a-ai'] });
  const decide = (r: Rec, apply: boolean) => run(async () => {
    const chk = await rpc<{ ok: boolean }>('admin_ai_decide', { id: r.id, apply }); await refresh();
    return chk;
  }).then((chk) => { if (chk && apply) toast(chk.ok ? 'تطبق الاقتراح بعد فحص القواعد' : 'محرك القواعد رفض الاقتراح (الحد اليومي أو الفرصة مو شغّالة)'); });
  const scan = () => run(async () => { const n = await rpc<number>('admin_ai_run'); await refresh(); return n; }).then((n) => { if (n !== undefined) toast(`طلعت ${n} اقتراحات جديدة`); });

  return (
    <>
      <div className="main-h"><div><h1>اقتراحات AI</h1><p className="muted">الذكاء الاصطناعي يقترح فقط: توزيع الزحمة على الأماكن الهادئة ونصائح للحملات. كل اقتراح يمر على محرك قواعد بحدود ثابتة (سقف يومي، الفرصة شغّالة، التاجر فعّال) قبل ما يتطبق، وما يوزّع نقاط بنفسه أبداً.</p></div>
        <button className="btn primary" disabled={busy} onClick={scan}><Icon name="cpu" /> حلّل هسه</button></div>
      <div className="seg" style={{ maxWidth: 420, marginBottom: 14 }}>{[['proposed', 'مقترحة'], ['applied', 'مطبقة'], ['rejected', 'مرفوضة']].map(([k, v]) => <button key={k} className={status === k ? 'on' : ''} onClick={() => setStatus(k)}>{v}</button>)}</div>
      {q.isLoading ? <Spinner /> : !q.data?.length ? <Empty title="ماكو اقتراحات" icon="cpu" /> : (
        <div className="grid2">{q.data.map((r) => (
          <div className="card" key={r.id}>
            <div className="row between"><span className="chip primary">{r.kind === 'traffic_balance' ? 'توزيع الزحمة' : 'نصيحة حملة'}</span><span className="small muted">{ago(r.at)}</span></div>
            <p style={{ marginTop: 10 }}>{r.kind === 'traffic_balance'
              ? <><b>{r.payload.branch}</b> أهدأ من العادة هسه ({r.payload.now} زيارة مقابل {r.payload.usual_per_hour} بالعادة). الاقتراح: +{r.payload.amount} نقطة لمدة {r.payload.hours} ساعة.</>
              : <><b>{r.payload.campaign}</b>: {r.payload.tip_ar}</>}</p>
            {r.rule_check && <p className="small muted" style={{ marginTop: 6 }}>فحص القواعد: {r.rule_check.ok ? 'نجح' : 'فشل'}{r.rule_check.daily_cap ? ` · المستخدم اليوم ${r.rule_check.daily_used}/${r.rule_check.daily_cap}` : ''}</p>}
            {r.status === 'proposed' && <div className="row" style={{ marginTop: 10 }}><button className="btn primary sm grow" disabled={busy} onClick={() => decide(r, true)}>طبّق (بعد فحص القواعد)</button><button className="btn sm" disabled={busy} onClick={() => decide(r, false)}>تجاهل</button></div>}
          </div>
        ))}</div>
      )}
    </>
  );
}
