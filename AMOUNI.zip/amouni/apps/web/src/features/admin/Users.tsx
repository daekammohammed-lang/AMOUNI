import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { dateAr, fmt } from '@/lib/format';
import { Sheet, Spinner, useAsync } from '@/ui/kit';

type U = { id: string; display_name: string | null; phone: string; status: string; account_trust: number; xp: number; created_at: string; points: number | null; visits: number; flagged: number; roles: string[] | null };

export function Users({ canAdjust }: { canAdjust: boolean }) {
  const [q, setQ] = useState('');
  const [term, setTerm] = useState('');
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const list = useQuery({ queryKey: ['a-users', term], queryFn: () => rpc<U[]>('admin_users', { q: term, limit: 100 }) });
  const [sel, setSel] = useState<U | null>(null);
  const [reason, setReason] = useState('');
  const [amount, setAmount] = useState('');
  const refresh = () => qc.invalidateQueries({ queryKey: ['a-users'] });

  const setStatus = (status: string) => sel && run(async () => { await rpc('admin_user_status', { user: sel.id, status, reason }); await refresh(); setSel(null); }, 'انحفظ وسجّلناه بالتدقيق');
  const adjust = () => sel && run(async () => { await rpc('admin_adjust_points', { user: sel.id, amount: Number(amount), reason }); await refresh(); setSel(null); }, 'انضاف تعديل بالسجل');

  return (
    <>
      <div className="main-h"><h1>المستخدمين</h1>
        <form className="row" onSubmit={(e) => { e.preventDefault(); setTerm(q); }}><input className="in" placeholder="رقم أو اسم" value={q} onChange={(e) => setQ(e.target.value)} /><button className="btn primary">بحث</button></form></div>
      {list.isLoading ? <Spinner /> : (
        <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>الاسم</th><th>الرقم</th><th>الحالة</th><th>نقاط</th><th>زيارات</th><th>مشكوك</th><th>منذ</th><th /></tr></thead>
          <tbody>{list.data?.map((u) => (
            <tr key={u.id}><td><b>{u.display_name ?? '—'}</b>{u.roles?.length ? <div className="small muted">{u.roles.join('، ')}</div> : null}</td>
              <td className="num" dir="ltr">{u.phone}</td>
              <td><span className={`chip ${u.status === 'active' ? 'ok' : 'warn'}`}>{u.status}</span></td>
              <td className="num">{fmt(u.points)}</td><td className="num">{u.visits}</td><td className="num">{u.flagged || ''}</td><td>{dateAr(u.created_at)}</td>
              <td><button className="btn sm" onClick={() => { setSel(u); setReason(''); setAmount(''); }}>إجراء</button></td></tr>
          ))}</tbody></table></div>
      )}
      <Sheet open={!!sel} onClose={() => setSel(null)} center>
        {sel && <div className="stack">
          <h2>{sel.display_name ?? sel.phone}</h2>
          <label className="field">السبب (يُسجّل بالتدقيق)<input className="in" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="مثلاً: 4 حسابات على نفس الجهاز" /></label>
          <div className="row">
            {sel.status !== 'active' && <button className="btn grow" disabled={busy || reason.length < 3} onClick={() => setStatus('active')}>تفعيل</button>}
            {sel.status !== 'limited' && <button className="btn grow" disabled={busy || reason.length < 3} onClick={() => setStatus('limited')}>تقييد</button>}
            {sel.status !== 'banned' && <button className="btn danger grow" disabled={busy || reason.length < 3} onClick={() => setStatus('banned')}>حظر</button>}
          </div>
          {canAdjust && <div className="row"><input className="in num" placeholder="+/- نقاط" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^\d-]/g, ''))} />
            <button className="btn gold" disabled={busy || !Number(amount) || reason.length < 3} onClick={adjust}>تعديل النقاط</button></div>}
          <p className="small muted">كل تعديل يصير قيد بسجل النقاط ومموّل من حساب AMOUNI التسويقي، وما ينحذف.</p>
        </div>}
      </Sheet>
    </>
  );
}
