import { useQuery } from '@tanstack/react-query';
import { rpc, supabase } from '@/lib/api';
import { fmt, iqd } from '@/lib/format';
import { Kpi, Spinner } from '@/ui/kit';
import { Icon } from '@/ui/icons';

type Analytics = { dau: number; wau: number; mau: number; new_users: number; scans: number; verified_visits: number; verified_rate: number | null;
  fraud_rate: number | null; redemption_rate: number | null; avg_visits_per_user: number | null; returning_users_7d: number; active_merchants: number;
  points_issued: number; points_redeemed: number; revenue_iqd: number; series: { day: string; scans: number; visits: number }[] };
type Economy = { outstanding_points: number; store_value_points: number; coverage_ratio: number | null; coverage_min: number; alert: boolean;
  issued_today: number; spent_today: number; marketing_issued_total: number };
type Pulse = { scans_last_hour: number; reject_rate_today: number | null; pending_review: number;
  branches: { id: string; name: string; merchant: string; capacity: number | null; visits_24h: number; visits_1h: number }[] };
const pct = (v: number | null | undefined) => (v === null || v === undefined ? '—' : `${Math.round(v * 100)}%`);

export function useCity() {
  return useQuery({ queryKey: ['cities'], queryFn: async () => (await supabase.from('cities').select('id,name_ar')).data ?? [] });
}

export function Overview() {
  const cities = useCity();
  const city = cities.data?.[0]?.id;
  const a = useQuery({ queryKey: ['a-analytics'], queryFn: () => rpc<Analytics>('admin_analytics', { days: 30 }), refetchInterval: 60_000 });
  const p = useQuery({ queryKey: ['a-pulse', city], queryFn: () => rpc<Pulse>('admin_city_pulse', { city }), enabled: !!city, refetchInterval: 30_000 });
  const e = useQuery({ queryKey: ['a-econ'], queryFn: () => rpc<Economy>('admin_economy'), refetchInterval: 60_000 });
  if (!a.data) return <Spinner />;
  const d = a.data;
  const max = Math.max(1, ...d.series.map((x) => x.scans));
  return (
    <>
      <div className="main-h"><div><div className="eyebrow">City Pulse · {cities.data?.[0]?.name_ar}</div><h1>شنو صاير بالمدينة</h1></div>
        {e.data?.alert && <span className="chip warn"><Icon name="shield" size={14} /> نسبة تغطية الجوائز تحت الحد</span>}</div>
      <div className="grid4">
        <Kpi hl v={fmt(p.data?.scans_last_hour)} l="مسح بآخر ساعة" />
        <Kpi v={pct(p.data?.reject_rate_today)} l="نسبة الرفض اليوم" />
        <Kpi v={fmt(p.data?.pending_review)} l="بانتظار المراجعة" />
        <Kpi v={e.data?.coverage_ratio ? `${e.data.coverage_ratio}×` : '—'} l={`تغطية الجوائز (الحد ${e.data?.coverage_min}×)`} />
      </div>
      <div className="grid4" style={{ marginTop: 12 }}>
        <Kpi v={fmt(d.dau)} l={`مستخدم يومي · ${fmt(d.wau)} أسبوعي · ${fmt(d.mau)} شهري`} />
        <Kpi v={fmt(d.verified_visits)} l={`زيارة موثقة (30 يوم) · ${pct(d.verified_rate)} من المسحات`} />
        <Kpi v={fmt(d.returning_users_7d)} l="رجعوا لمكان ثاني خلال أسبوع" />
        <Kpi v={iqd(d.revenue_iqd)} l={`إيراد الحملات · ${fmt(d.active_merchants)} تاجر نشط`} />
      </div>
      <div className="grid2" style={{ marginTop: 14 }}>
        <div className="card"><h3>المسحات والزيارات يومياً</h3>
          <div className="bars">{d.series.slice(-21).map((x) => (
            <div className="b" key={x.day} title={`${x.day}: ${x.scans} مسح، ${x.visits} زيارة`}><i style={{ height: `${(x.scans / max) * 100}%` }}><i className="g" style={{ height: `${x.scans ? (x.visits / x.scans) * 100 : 0}%`, position: 'absolute', bottom: 0, left: 0, right: 0, borderRadius: 7 }} /></i><span>{x.day.slice(8)}</span></div>
          ))}</div></div>
        <div className="card"><h3>الحركة بآخر 24 ساعة</h3>
          <div className="list">{(p.data?.branches ?? []).slice(0, 8).map((b) => {
            const busy = b.capacity && b.visits_1h > b.capacity * 0.8;
            return <div className="it" key={b.id}><div className="grow"><b>{b.merchant}</b><div className="small muted">{b.name}</div></div>
              <span className="num">{b.visits_24h}</span>{busy ? <span className="chip warn">زحمة</span> : b.visits_24h === 0 ? <span className="chip">هادئ</span> : null}</div>;
          })}</div></div>
      </div>
      <div className="grid4" style={{ marginTop: 12 }}>
        <Kpi v={pct(d.fraud_rate)} l="مسحات مشكوك بيها" />
        <Kpi v={pct(d.redemption_rate)} l="نسبة استبدال الجوائز" />
        <Kpi v={d.avg_visits_per_user ?? '—'} l="زيارة لكل مستخدم" />
        <Kpi v={fmt(d.new_users)} l="مستخدم جديد (30 يوم)" />
      </div>
    </>
  );
}

export function Economy() {
  const e = useQuery({ queryKey: ['a-econ'], queryFn: () => rpc<Economy>('admin_economy') });
  const a = useQuery({ queryKey: ['a-analytics'], queryFn: () => rpc<Analytics>('admin_analytics', { days: 30 }) });
  if (!e.data) return <Spinner />;
  const x = e.data;
  return (
    <>
      <div className="main-h"><div><h1>اقتصاد النقاط</h1><p className="muted">كل نقطة عند الناس لازم تقابلها جوائز حقيقية بالمتجر. النقاط تطلع من محافظ تمويل وما تنطبع من فراغ.</p></div></div>
      <div className={`card ${x.alert ? '' : 'tint'}`} style={x.alert ? { borderColor: 'var(--warn)' } : undefined}>
        <div className="row between"><div><div className="eyebrow">نسبة التغطية</div><b className="num" style={{ fontSize: 40, fontFamily: 'var(--f-display)' }}>{x.coverage_ratio ?? '—'}×</b></div>
          <span className={`chip ${x.alert ? 'warn' : 'ok'}`}>{x.alert ? `تحت الحد ${x.coverage_min}× — أضف جوائز أو خفّض النقاط الإضافية` : `سليمة (الحد ${x.coverage_min}×)`}</span></div>
        <p className="small muted">قيمة جوائز المتجر المتوفرة ({fmt(x.store_value_points)} نقطة) ÷ النقاط عند المستخدمين ({fmt(x.outstanding_points)}).</p>
      </div>
      <div className="grid4" style={{ marginTop: 12 }}>
        <Kpi v={fmt(x.outstanding_points)} l="نقاط عند المستخدمين (متاحة + معلّقة)" />
        <Kpi v={fmt(x.issued_today)} l="انصرفت للمستخدمين اليوم" />
        <Kpi v={fmt(x.spent_today)} l="انصرفت بالمتجر اليوم" />
        <Kpi v={fmt(x.marketing_issued_total)} l="مجموع ما موّلته AMOUNI" />
      </div>
      {a.data && <div className="grid2" style={{ marginTop: 12 }}>
        <Kpi v={fmt(a.data.points_issued)} l="نقاط انصرفت (30 يوم)" />
        <Kpi v={fmt(a.data.points_redeemed)} l="نقاط انصرفت بالمتجر (30 يوم)" />
      </div>}
    </>
  );
}
