import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { AUDIENCE_AR, CAMPAIGN_STATUS_AR, fmt, iqd } from '@/lib/format';
import { Empty, Spinner, useAsync } from '@/ui/kit';

type C = { id: string; name: string; merchant: string; goal_type: string; goal_visits: number; audience: string; bonus_points: number; cpv_iqd: number;
  budget_iqd: number; spent_iqd: number; generated_visits: number; status: string; schedule: { from?: string; to?: string; days_count?: number } };

export function AdminCampaigns() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const list = useQuery({ queryKey: ['a-campaigns'], queryFn: () => rpc<C[]>('admin_campaigns', {}) });
  const decide = (c: C, approve: boolean) => run(async () => {
    await rpc('admin_campaign_decide', { campaign: c.id, approve, reason: approve ? 'meets policy' : 'needs changes' });
    await qc.invalidateQueries({ queryKey: ['a-campaigns'] });
  }, approve ? `تمويل ${fmt(c.bonus_points * c.goal_visits)} نقطة وتشغيل الحملة` : 'انرفضت');
  const pause = (c: C) => run(async () => { await rpc('campaign_pause', { campaign: c.id, pause: c.status === 'running' }); await qc.invalidateQueries({ queryKey: ['a-campaigns'] }); });
  if (list.isLoading) return <Spinner />;
  return (
    <>
      <div className="main-h"><div><h1>الحملات</h1><p className="muted">الموافقة تموّل محفظة نقاط الحملة (نقاط × هدف) وتضيف النقاط الإضافية على فرص التاجر. الباقي يرجع لـ AMOUNI لما تخلص.</p></div></div>
      {!list.data?.length ? <Empty title="ماكو حملات" /> : (
        <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>الحملة</th><th>التاجر</th><th>الهدف</th><th>نقاط</th><th>الجمهور</th><th>الوقت</th><th>الميزانية</th><th>النتيجة</th><th /></tr></thead>
          <tbody>{list.data.map((c) => (
            <tr key={c.id}><td><b>{c.name}</b><div><span className={`chip ${CAMPAIGN_STATUS_AR[c.status]?.[1] ?? ''}`}>{CAMPAIGN_STATUS_AR[c.status]?.[0] ?? c.status}</span></div></td><td>{c.merchant}</td><td className="num">{c.goal_visits}</td><td className="num">+{c.bonus_points}</td>
              <td>{AUDIENCE_AR[c.audience] ?? c.audience}</td><td className="small">{c.schedule.days_count ?? 7} يوم{c.schedule.from ? ` · ${c.schedule.from}–${c.schedule.to}` : ''}</td>
              <td className="num">{iqd(c.budget_iqd)}<div className="small muted">{iqd(c.cpv_iqd)}/زيارة</div></td><td className="num">{c.generated_visits} · {iqd(c.spent_iqd)}</td>
              <td>{c.status === 'pending_approval' ? <div className="row"><button className="btn sm primary" disabled={busy} onClick={() => decide(c, true)}>موافقة</button><button className="btn sm danger" disabled={busy} onClick={() => decide(c, false)}>رفض</button></div>
                : ['running', 'paused'].includes(c.status) ? <button className="btn sm" disabled={busy} onClick={() => pause(c)}>{c.status === 'running' ? 'إيقاف' : 'تشغيل'}</button> : null}</td></tr>
          ))}</tbody></table></div>
      )}
    </>
  );
}
