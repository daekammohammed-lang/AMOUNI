import { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { dateAr, fmt, iqd } from '@/lib/format';
import { Sheet, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';

type Reward = { id: string; title_ar: string; value_iqd: number; cost_points: number | null; stock: number; active: boolean; merchant: string; suggested_points: number; redeemed: number };
type Spot = { id: string; title_ar: string; kind: string; base_points: number; cap_points: number; qty_total: number | null; qty_left: number | null; status: string; ends_at: string | null; branch: string; merchant: string; visits: number };
type Mission = { id: string; code: string; kind: string; title_ar: string; reward_points: number; active: boolean; claims_7d: number };
type Merchant = { id: string; display_name: string; status: string; branch_list: { id: string; name: string }[] | null };

const KIND_AR: Record<string, string> = { normal: 'عادية', golden_drop: 'Golden Drop', first_finder: 'First Finder', mystery: 'مخفية' };

export function Catalog() {
  const [tab, setTab] = useState<'spots' | 'rewards' | 'missions'>('spots');
  return (
    <>
      <div className="main-h"><h1>الفرص والجوائز والمهام</h1>
        <div className="seg">{([['spots', 'الفرص'], ['rewards', 'الجوائز'], ['missions', 'المهام']] as const).map(([k, v]) => <button key={k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{v}</button>)}</div></div>
      {tab === 'spots' ? <Spots /> : tab === 'rewards' ? <Rewards /> : <Missions />}
    </>
  );
}

function Spots() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['a-spots'], queryFn: () => rpc<Spot[]>('admin_spots') });
  const m = useQuery({ queryKey: ['a-merchants', 'active'], queryFn: () => rpc<Merchant[]>('admin_merchants', { status: 'active' }) });
  const rewards = useQuery({ queryKey: ['a-rewards'], queryFn: () => rpc<Reward[]>('admin_rewards') });
  const [open, setOpen] = useState(false);
  const [f, setF] = useState({ branch: '', title: '', kind: 'normal', points: 80, qty: '', reward: '', radius: 150, hours: 6, cap: 500 });
  const branches = (m.data ?? []).flatMap((x) => (x.branch_list ?? []).map((b) => ({ ...b, merchant: x.display_name })));
  const create = (e: React.FormEvent) => {
    e.preventDefault();
    const drop = f.kind === 'golden_drop' || f.kind === 'first_finder';
    run(async () => {
      await rpc('admin_spot_create', { branch: f.branch || branches[0]?.id, title: f.title, kind: f.kind, base_points: f.points,
        qty: f.qty ? Number(f.qty) : null, instant_reward: f.reward || null, requires_dynamic: f.kind === 'golden_drop',
        mystery_radius_m: f.kind === 'mystery' ? f.radius : null, starts: new Date().toISOString(),
        ends: drop ? new Date(Date.now() + f.hours * 3600_000).toISOString() : null, cap_points: drop ? Math.max(f.cap, f.points) : 500 });
      await qc.invalidateQueries({ queryKey: ['a-spots'] }); setOpen(false);
    }, 'انضافت الفرصة وصارت شغّالة');
  };
  const setStatus = (s: Spot, status: string) => run(async () => { await rpc('admin_spot_status', { spot: s.id, status, reason: 'ops' }); await qc.invalidateQueries({ queryKey: ['a-spots'] }); });
  if (q.isLoading) return <Spinner />;
  return (
    <>
      <div className="row" style={{ justifyContent: 'flex-end', marginBottom: 10 }}><button className="btn primary" onClick={() => setOpen(true)}><Icon name="plus" /> فرصة جديدة</button></div>
      <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>الفرصة</th><th>المحل</th><th>النوع</th><th>نقاط الأساس</th><th>الكمية</th><th>زيارات</th><th>الحالة</th><th /></tr></thead>
        <tbody>{q.data?.map((s) => (
          <tr key={s.id}><td><b>{s.title_ar}</b>{s.ends_at && <div className="small muted">ينتهي {dateAr(s.ends_at)}</div>}</td><td>{s.merchant}<div className="small muted">{s.branch}</div></td>
            <td>{KIND_AR[s.kind]}</td><td className="num">{s.base_points}</td><td className="num">{s.qty_total ? `${s.qty_left}/${s.qty_total}` : '—'}</td><td className="num">{s.visits}</td>
            <td><span className={`chip ${s.status === 'live' ? 'ok' : 'amber'}`}>{s.status}</span></td>
            <td>{s.status === 'live' ? <button className="btn sm" disabled={busy} onClick={() => setStatus(s, 'paused')}>إيقاف</button> : s.status === 'paused' ? <button className="btn sm" disabled={busy} onClick={() => setStatus(s, 'live')}>تشغيل</button> : null}</td></tr>
        ))}</tbody></table></div>
      <Sheet open={open} onClose={() => setOpen(false)} center>
        <form className="stack" onSubmit={create}>
          <h2>فرصة جديدة</h2>
          <label className="field">الفرع<select className="in" value={f.branch} onChange={(e) => setF({ ...f, branch: e.target.value })}>{branches.map((b) => <option key={b.id} value={b.id}>{b.merchant} — {b.name}</option>)}</select></label>
          <label className="field">العنوان<input className="in" required value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} /></label>
          <label className="field">النوع<select className="in" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>{Object.entries(KIND_AR).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></label>
          <div className="row"><label className="field grow">نقاط الأساس<input className="in num" type="number" min={0} max={5000} value={f.points} onChange={(e) => setF({ ...f, points: Number(e.target.value) })} /></label>
            {(f.kind === 'golden_drop' || f.kind === 'first_finder') && <label className="field grow">عدد الفائزين<input className="in num" type="number" min={1} value={f.qty} onChange={(e) => setF({ ...f, qty: e.target.value })} /></label>}</div>
          {(f.kind === 'golden_drop' || f.kind === 'first_finder') && <div className="row"><label className="field grow">المدة (ساعات)<input className="in num" type="number" min={1} max={72} value={f.hours} onChange={(e) => setF({ ...f, hours: Number(e.target.value) })} /></label>
            <label className="field grow">الحد الأعلى للنقاط<input className="in num" type="number" value={f.cap} onChange={(e) => setF({ ...f, cap: Number(e.target.value) })} /></label></div>}
          {f.kind === 'mystery' && <label className="field">نصف قطر الدائرة (م)<input className="in num" type="number" min={50} max={1000} value={f.radius} onChange={(e) => setF({ ...f, radius: Number(e.target.value) })} /></label>}
          <label className="field">جائزة فورية (اختياري)<select className="in" value={f.reward} onChange={(e) => setF({ ...f, reward: e.target.value })}><option value="">بدون</option>{(rewards.data ?? []).map((r) => <option key={r.id} value={r.id}>{r.merchant} — {r.title_ar}</option>)}</select></label>
          {f.kind === 'golden_drop' && <p className="small muted">Golden Drop ينمسح من شاشة الكاشير بس (الفرع لازم وضع الكاشير شغّال)، ويحتاج حساب عمره 48 ساعة ودقة GPS ≤ 50 م.</p>}
          <button className="btn primary block" disabled={busy}>أنشئ وشغّل</button>
        </form>
      </Sheet>
    </>
  );
}

function Rewards() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['a-rewards'], queryFn: () => rpc<Reward[]>('admin_rewards') });
  const [price, setPrice] = useState<Record<string, string>>({});
  const save = (r: Reward, active: boolean) => run(async () => {
    const p = price[r.id] !== undefined ? (price[r.id] ? Number(price[r.id]) : null) : r.cost_points;
    await rpc('admin_reward_price', { reward: r.id, cost_points: p, active }); await qc.invalidateQueries({ queryKey: ['a-rewards'] });
  }, 'انحفظ');
  if (q.isLoading) return <Spinner />;
  return (
    <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>الجائزة</th><th>المحل</th><th>القيمة</th><th>مقترح</th><th>السعر بالنقاط</th><th>المخزون</th><th>استُبدلت</th><th /></tr></thead>
      <tbody>{q.data?.map((r) => (
        <tr key={r.id}><td><b>{r.title_ar}</b></td><td>{r.merchant}</td><td className="num">{iqd(r.value_iqd)}</td><td className="num muted">{fmt(r.suggested_points)}</td>
          <td><input className="in num" style={{ minHeight: 36, width: 110 }} placeholder="فورية فقط" value={price[r.id] ?? (r.cost_points ?? '')} onChange={(e) => setPrice({ ...price, [r.id]: e.target.value.replace(/\D/g, '') })} /></td>
          <td className="num">{fmt(r.stock)}</td><td className="num">{r.redeemed}</td>
          <td className="row"><button className="btn sm" disabled={busy} onClick={() => save(r, r.active)}>احفظ</button><button className={`btn sm ${r.active ? 'danger' : 'primary'}`} disabled={busy} onClick={() => save(r, !r.active)}>{r.active ? 'إيقاف' : 'تفعيل'}</button></td></tr>
      ))}</tbody></table></div>
  );
}

function Missions() {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['a-missions'], queryFn: () => rpc<Mission[]>('admin_missions') });
  const [pts, setPts] = useState<Record<string, string>>({});
  const save = (m: Mission, active: boolean) => run(async () => { await rpc('admin_mission_update', { mission: m.id, active, reward_points: Number(pts[m.id] ?? m.reward_points) }); await qc.invalidateQueries({ queryKey: ['a-missions'] }); }, 'انحفظ');
  if (q.isLoading) return <Spinner />;
  return (
    <div className="card tbl-wrap"><table className="tbl"><thead><tr><th>المهمة</th><th>النوع</th><th>المكافأة</th><th>استلموها (7 أيام)</th><th /></tr></thead>
      <tbody>{q.data?.map((m) => (
        <tr key={m.id}><td><b>{m.title_ar}</b><div className="small muted">{m.code}</div></td><td>{m.kind === 'daily' ? 'يومية' : 'أسبوعية'}</td>
          <td><input className="in num" style={{ minHeight: 36, width: 100 }} value={pts[m.id] ?? m.reward_points} onChange={(e) => setPts({ ...pts, [m.id]: e.target.value.replace(/\D/g, '') })} /></td>
          <td className="num">{m.claims_7d}</td>
          <td className="row"><button className="btn sm" disabled={busy} onClick={() => save(m, m.active)}>احفظ</button><button className={`btn sm ${m.active ? 'danger' : 'primary'}`} disabled={busy} onClick={() => save(m, !m.active)}>{m.active ? 'إيقاف' : 'تفعيل'}</button></td></tr>
      ))}</tbody></table></div>
  );
}
