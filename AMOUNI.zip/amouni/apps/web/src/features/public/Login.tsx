import { useEffect, useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/api';
import { iraqPhone } from '@/lib/format';
import { useSession } from '@/app/session';
import { useInterval } from '@/lib/hooks';

const DEV_INBOX = import.meta.env.VITE_DEV_OTP_INBOX === 'true';

export function Login() {
  const { session } = useSession();
  const [params] = useSearchParams();
  const next = params.get('next') || '/app';
  const nav = useNavigate();
  const [phone, setPhone] = useState('');
  const [sent, setSent] = useState<string | null>(null);
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [devCode, setDevCode] = useState('');
  const [resendIn, setResendIn] = useState(0);

  useInterval(() => setResendIn((s) => Math.max(0, s - 1)), resendIn > 0 ? 1000 : null);
  useEffect(() => {
    if (!DEV_INBOX || !sent) return;
    const t = setTimeout(() => fetch(`/functions/v1/auth-sms-hook?phone=${sent.replace(/\D/g, '')}`).then((r) => r.json()).then((j) => j.code && setDevCode(j.code)).catch(() => {}), 700);
    return () => clearTimeout(t);
  }, [sent, resendIn]);

  if (session) return <Navigate to={next} replace />;

  const send = async (e?: React.FormEvent) => {
    e?.preventDefault(); setErr('');
    const p = iraqPhone(phone);
    if (!p) return setErr('اكتب رقم موبايل عراقي صحيح، مثل 07701234567');
    setBusy(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: p });
    setBusy(false);
    if (error) return setErr(error.status === 429 ? 'طلبت كود قبل شوية. انتظر دقيقة.' : 'ما كدرنا نرسل الكود. تأكد من الرقم وجرّب مرة ثانية.');
    setSent(p); setResendIn(60); setDevCode('');
  };
  const verify = async (e: React.FormEvent) => {
    e.preventDefault(); setErr('');
    if (!/^\d{6}$/.test(code)) return setErr('الكود 6 أرقام');
    setBusy(true);
    const { error } = await supabase.auth.verifyOtp({ phone: sent!, token: code, type: 'sms' });
    setBusy(false);
    if (error) return setErr('الكود غلط أو انتهى. اطلب كود جديد.');
    nav(next, { replace: true });
  };

  return (
    <div className="app" style={{ paddingBottom: 0 }}>
      <div className="page" style={{ paddingTop: 40 }}>
        <Link to="/" className="row" style={{ justifyContent: 'center' }}><img src="/logo-full.webp" alt="AMOUNI" width={120} /></Link>
        <h1 className="center" style={{ marginTop: 18 }}>{sent ? 'اكتب الكود' : 'أهلاً بيك'}</h1>
        <p className="center muted" style={{ margin: '6px auto 22px', maxWidth: '32ch' }}>
          {sent ? <>دزّينا كود من 6 أرقام على <span className="num" dir="ltr">{sent}</span> بالواتساب أو رسالة.</> : 'سجّل برقم موبايلك. نفس الخطوة للدخول ولحساب جديد.'}
        </p>
        {!sent ? (
          <form className="stack" onSubmit={send}>
            <label className="field">رقم الموبايل
              <input className="in num" dir="ltr" inputMode="tel" autoComplete="tel" placeholder="07XX XXX XXXX" value={phone} onChange={(e) => setPhone(e.target.value)} autoFocus />
            </label>
            {err && <div className="err">{err}</div>}
            <button className="btn primary block lg" disabled={busy}>{busy ? 'نرسل…' : 'أرسل الكود'}</button>
            <p className="small muted center">بالتسجيل توافق إن موقعك يُستخدم بس وقت اللقطة والمسح.</p>
          </form>
        ) : (
          <form className="stack" onSubmit={verify}>
            <input className="in code num" inputMode="numeric" autoComplete="one-time-code" maxLength={6} placeholder="••••••" value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ''))} autoFocus aria-label="الكود" />
            {DEV_INBOX && devCode && (
              <button type="button" className="card tint small" onClick={() => setCode(devCode)} style={{ textAlign: 'center' }}>
                بيئة التطوير: الكود <b className="num">{devCode}</b> — اضغط لتعبئته
              </button>
            )}
            {err && <div className="err">{err}</div>}
            <button className="btn primary block lg" disabled={busy}>{busy ? 'نتأكد…' : 'دخول'}</button>
            <div className="row between small">
              <button type="button" className="link" onClick={() => { setSent(null); setCode(''); }}>غيّر الرقم</button>
              <button type="button" className="link" disabled={resendIn > 0} onClick={() => send()}>{resendIn ? `إعادة الإرسال بعد ${resendIn}` : 'أرسل كود جديد'}</button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
