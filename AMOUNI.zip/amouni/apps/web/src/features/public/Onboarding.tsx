import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, supabase } from '@/lib/api';
import { useRoles } from '@/app/session';
import { Icon, type IconName } from '@/ui/icons';
import { useAsync } from '@/ui/kit';

const SLIDES: [IconName, string, string][] = [
  ['map', 'اكتشف فرص حولك', 'كل فرصة بمحل حقيقي بمدينتك، وتعرف نقاطها قبل ما تتحرك.'],
  ['qr', 'روح وامسح الباركود', 'باركود AMOUNI الذهبي داخل المحل. نتأكد من حضورك بالموقع وقت المسح بس.'],
  ['gift', 'اربح واستبدل', 'النقاط تصير جوائز حقيقية. كل يوم مهمة جديدة، وكل حي تكتشفه يتلوّن بخريطتك.'],
];

export function Onboarding() {
  const roles = useRoles();
  const nav = useNavigate();
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  const done = roles.data?.profile_complete;
  const [step, setStep] = useState(done ? 1 : 0);
  const [name, setName] = useState('');
  const [city, setCity] = useState('');
  const [invite, setInvite] = useState('');
  const cities = useQuery({ queryKey: ['cities'], queryFn: async () => {
    const { data } = await supabase.from('cities').select('id,name_ar').order('name_ar');
    return data ?? [];
  } });

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    const ok = await run(() => rpc('complete_profile', { name: name.trim(), city: city || cities.data?.[0]?.id, invite_code: invite.trim() || null }));
    if (ok !== undefined) { await qc.invalidateQueries({ queryKey: ['roles'] }); setStep(1); }
  };
  const finish = () => {
    navigator.geolocation?.getCurrentPosition(() => nav('/app', { replace: true }), () => nav('/app', { replace: true }), { timeout: 8000 });
  };

  return (
    <div className="app" style={{ paddingBottom: 0 }}>
      <div className="page" style={{ paddingTop: 36 }}>
        {step === 0 ? (
          <form className="stack" onSubmit={save}>
            <img src="/logo-mark.webp" alt="" width={64} style={{ margin: '0 auto' }} />
            <h1 className="center">خلّينا نتعرّف</h1>
            <label className="field">اسمك<input className="in" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثلاً: حسن علي" maxLength={40} required autoFocus /></label>
            <label className="field">مدينتك
              <select className="in" value={city} onChange={(e) => setCity(e.target.value)}>
                {(cities.data ?? []).map((c) => <option key={c.id} value={c.id}>{c.name_ar}</option>)}
              </select>
            </label>
            <label className="field">كود دعوة من صديق (اختياري)<input className="in num" dir="ltr" value={invite} onChange={(e) => setInvite(e.target.value.toUpperCase())} placeholder="AM-XXXX-XX" /></label>
            <button className="btn primary block lg" disabled={busy || name.trim().length < 2}>التالي</button>
          </form>
        ) : step <= SLIDES.length ? (
          <div className="stack center" style={{ minHeight: '70vh', justifyContent: 'center' }}>
            <div className="cat lg c-mystery" style={{ margin: '0 auto', width: 96, height: 96, borderRadius: 30 }}><Icon name={SLIDES[step - 1][0]} size={44} /></div>
            <h1>{SLIDES[step - 1][1]}</h1>
            <p className="muted" style={{ maxWidth: '32ch', margin: '0 auto' }}>{SLIDES[step - 1][2]}</p>
            <div className="row" style={{ justifyContent: 'center', gap: 6, margin: '10px 0' }}>
              {SLIDES.map((_, i) => <i key={i} style={{ width: i === step - 1 ? 22 : 7, height: 7, borderRadius: 7, background: i === step - 1 ? 'var(--primary)' : 'var(--line)' }} />)}
            </div>
            <button className="btn primary block lg" onClick={() => setStep(step + 1)}>{step < SLIDES.length ? 'التالي' : 'يلا نبدي'}</button>
            <button className="btn ghost" onClick={() => setStep(SLIDES.length + 1)}>تخطّي</button>
          </div>
        ) : (
          <div className="stack center" style={{ minHeight: '70vh', justifyContent: 'center' }}>
            <div className="cat lg c-fitness" style={{ margin: '0 auto', width: 96, height: 96, borderRadius: 30 }}><Icon name="pin" size={44} /></div>
            <h1>نحتاج موقعك… بس وقت اللقطة</h1>
            <p className="muted" style={{ maxWidth: '34ch', margin: '0 auto' }}>حتى نراويك الفرص القريبة ونتأكد إنك داخل المحل وقت المسح. ما نتتبعك بالخلفية أبداً.</p>
            <button className="btn primary block lg" onClick={finish}>اسمح بالموقع</button>
            <button className="btn ghost" onClick={() => nav('/app', { replace: true })}>بعدين</button>
          </div>
        )}
      </div>
    </div>
  );
}
