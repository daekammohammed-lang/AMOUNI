import { Link } from 'react-router-dom';
import { Icon } from '@/ui/icons';

const steps = [
  ['اكتشف', 'فرص حولك بمحلات مدينتك: قهوة، أكل، ألعاب، وDrops بجوائز.'],
  ['روح', 'كل فرصة تعرف نقاطها قبل ما تتحرك، والرقم ينحجزلك 45 دقيقة.'],
  ['امسح', 'باركود AMOUNI الذهبي داخل المحل. نتأكد إنك هناك فعلاً.'],
  ['اربح', 'نقاط وجوائز حقيقية تستبدلها بالمحلات بكود يتغيّر كل دقيقة.'],
];

export function Landing() {
  return (
    <div className="landing">
      <div className="inner">
        <nav>
          <div className="row"><img src="/logo-mark.webp" alt="" width={36} /><b style={{ fontFamily: 'var(--f-display)', letterSpacing: '.14em' }}>AMOUNI</b></div>
          <div className="row">
            <Link to="/login?next=/merchant" className="btn ghost sm" style={{ color: '#fff' }}>للمحلات</Link>
            <Link to="/login" className="btn gold sm">دخول</Link>
          </div>
        </nav>

        <section className="hero-l">
          <div>
            <span className="chip" style={{ background: 'rgba(255,255,255,.12)', color: '#fff' }}>الرمادي · قريباً بكل العراق</span>
            <h1 style={{ marginTop: 14 }}>شنو أكو اليوم؟<br />اطلع، اكتشف، واربح.</h1>
            <p className="lead">AMOUNI يحوّل مدينتك للعبة حقيقية: تلكى فرص بالمحلات القريبة، تروح، تمسح الباركود، وتاخذ نقاط وجوائز. والمحلات تشوف زبائن جدد بأرقام حقيقية.</p>
            <div className="row" style={{ flexWrap: 'wrap' }}>
              <Link to="/login" className="btn gold lg">ابدأ الاستكشاف</Link>
              <Link to="/login?next=/merchant/join" className="btn lg" style={{ background: 'rgba(255,255,255,.1)', color: '#fff', borderColor: 'rgba(255,255,255,.2)' }}>سجّل محلك</Link>
            </div>
          </div>
          <div className="phone" aria-hidden="true">
            <div className="scr">
              <div className="eyebrow">عندي لك 3 فرص اليوم</div>
              {[['مول الرمادي سنتر', 'Golden Drop · باقي 7', '+600', true], ['مطعم بيت الكص', 'لقطة الغداء · 550 م', '+280', false], ['كافيه الفرات', 'إسبريسو مجاني · 240 م', '+160', false]].map(([a, b, c, g]) => (
                <div key={a as string} className={`spot ${g ? 'gold' : ''}`} style={{ marginTop: 10, padding: 10 }}>
                  <span className={`cat ${g ? 'c-gold' : 'c-food'}`} style={{ width: 42, height: 42 }}><Icon name={g ? 'star' : 'pin'} /></span>
                  <span className="grow"><b style={{ fontSize: 14 }}>{a}</b><span className="small muted">{b}</span></span>
                  <span className="pts">{c}</span>
                </div>
              ))}
              <div className="card dark" style={{ marginTop: 12, textAlign: 'center' }}>
                <div className="small muted">YOU FOUND IT</div><b style={{ fontFamily: 'var(--f-display)', fontSize: 22 }}>لكيتها! +280</b>
              </div>
            </div>
          </div>
        </section>

        <section className="steps">
          {steps.map(([t, d], i) => (
            <div className="step" key={t}><span className="n">{i + 1}</span><b>{t}</b><p>{d}</p></div>
          ))}
        </section>

        <section className="biz">
          <div className="card">
            <Icon name="chart" size={28} />
            <h2 style={{ margin: '10px 0 6px', color: '#fff' }}>للمحلات: ادفع على زبائن حقيقيين</h2>
            <p>كل زيارة تنثبت بالباركود والموقع. تشوف كم زبون جديد جابه AMOUNI، كم رجع، وكلفة كل زيارة.</p>
          </div>
          <div className="card">
            <Icon name="shield" size={28} />
            <h2 style={{ margin: '10px 0 6px', color: '#fff' }}>ما ينفع الغش</h2>
            <p>صورة الباركود من البيت ما تنفع: نتحقق من الحضور، الوقت، والجهاز، والمسح المشكوك بيه يتراجع يدوياً.</p>
          </div>
        </section>
        <p className="small" style={{ color: '#9D98D6', marginTop: 40 }}>© AMOUNI · الموقع يُستخدم بس وقت اللقطة والمسح.</p>
      </div>
    </div>
  );
}
