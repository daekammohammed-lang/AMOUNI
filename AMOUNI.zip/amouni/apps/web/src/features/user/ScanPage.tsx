import { useCallback, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { edge, type ScanResponse } from '@/lib/api';
import { currentFix, deviceFingerprint, newKey, useNow } from '@/lib/hooks';
import { fmt, left } from '@/lib/format';
import { Scanner } from '@/ui/qr';
import { Lines, useToast } from '@/ui/kit';
import { Icon, type IconName } from '@/ui/icons';
import { TopBar, useActiveHunt } from './UserApp';

type Attempt = { payload: string; key: string };

const TIPS: Record<string, [IconName, string]> = {
  TOO_FAR: ['pin', 'المسح لازم يصير من داخل المكان. إذا أنت داخل، فعّل «الموقع الدقيق» وجرّب مرة ثانية.'],
  NO_LOCATION: ['pin', 'نحتاج موقعك لحظة المسح بس. فعّله من إعدادات المتصفح.'],
  QR_EXPIRED: ['refresh', 'المحل غيّر الباركود. دوّر على البوستر الجديد.'],
  QR_UNKNOWN: ['qr', 'تأكد إنه باركود AMOUNI بالإطار الذهبي.'],
  DYNAMIC_STALE: ['refresh', 'باركود الشاشة يتغيّر كل 30 ثانية. امسحه مباشرة من الشاشة.'],
  DYNAMIC_REQUIRED: ['star', 'هاي الفرصة تنمسح من شاشة الكاشير بس. اطلب من الموظف يفتحها.'],
  ALREADY_FOUND: ['check', 'لكيت هاي الفرصة قبل. أكو غيرها تنتظرك.'],
  PLACE_COOLDOWN: ['clock', 'نفس المكان ينحسب مرة بالأسبوع حتى تكتشف أماكن جديدة.'],
  DAILY_LIMIT: ['clock', 'وصلت حدّ اليوم. باچر يوم جديد.'],
  SOLD_OUT: ['gift', 'خلصت الكمية. شوف الفرص القريبة الثانية.'],
  SPOT_CLOSED: ['clock', 'هاي الفرصة مو شغّالة هسه.'],
  REVIEW: ['shield', 'ما تحتاج تسوي شي. نبلغك بالإشعارات أول ما نتأكد.'],
  REJECTED: ['shield', 'إذا تعتقد صار خطأ، تواصل ويانا من حسابك.'],
  ACCOUNT_LIMITED: ['shield', 'حسابك تحت المراجعة. تواصل ويانا.'],
  REPLAY: ['refresh', 'ابدأ اللقطة من جديد.'],
  RATE_LIMITED: ['clock', 'انتظر دقيقة وجرّب.'],
};

export function ScanPage() {
  const hunt = useActiveHunt();
  const qc = useQueryClient();
  const toast = useToast();
  const nav = useNavigate();
  const now = useNow(1000);
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<ScanResponse | null>(null);
  const [mode, setMode] = useState<'scan' | 'stepup'>('scan');
  const [scanKey, setScanKey] = useState(0);
  const last = useRef<Attempt | null>(null);

  const finish = useCallback((r: ScanResponse) => {
    setRes(r);
    if (['OK', 'HELD', 'STEP_UP', 'REVIEW'].includes(r.code)) {
      ['profile', 'hunt', 'picks', 'map', 'missions', 'bag', 'discovery'].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
    }
  }, [qc]);

  const submit = useCallback(async (a: Attempt) => {
    setBusy(true); last.current = a;
    try {
      const fix = await currentFix();
      const h = hunt.data;
      const nonce = h ? sessionStorage.getItem(`amouni-nonce-${h.hunt_id}`) ?? undefined : undefined;
      const r = await edge('scan', {
        payload: a.payload, lat: fix?.lat ?? null, lng: fix?.lng ?? null, accuracy: fix ? Math.round(fix.accuracy) : null,
        nonce, device_fp: deviceFingerprint(), platform: 'web',
      }, a.key);
      finish(r);
    } catch (e) {
      toast((e as Error).message);           // network: the same idempotency key is reused on retry
    } finally { setBusy(false); }
  }, [hunt.data, finish, toast]);

  const onScan = useCallback((text: string) => {
    if (busy) return;
    if (mode === 'stepup' && res?.scan_id) {
      setBusy(true);
      (async () => {
        const fix = await currentFix();
        try { finish(await edge('step-up', { scan_id: res.scan_id, payload: text, lat: fix?.lat ?? null, lng: fix?.lng ?? null, accuracy: fix ? Math.round(fix.accuracy) : null })); setMode('scan'); }
        catch (e) { toast((e as Error).message); }
        finally { setBusy(false); }
      })();
      return;
    }
    submit({ payload: text, key: newKey() });
  }, [busy, mode, res, submit, finish, toast]);

  const again = () => { setRes(null); setMode('scan'); setScanKey((k) => k + 1); };

  // ---------- views ----------
  if (res && mode === 'scan' && res.code !== 'STEP_UP') {
    const win = res.code === 'OK' || res.code === 'HELD';
    if (win) return (
      <>
        <TopBar title="النتيجة" />
        <div className="page found">
          <div className="burst"><img src="/logo-mark.webp" alt="" /></div>
          <div className="eyebrow" style={{ color: 'var(--primary)' }}>YOU FOUND IT</div>
          <h1>لكيتها!</h1>
          <p className="muted" style={{ marginBottom: 14 }}>{res.code === 'OK' ? <>+<b className="num" style={{ color: 'var(--gold)' }}>{fmt(res.points)}</b> نقطة انضافت لرصيدك</> : <>+<b className="num">{fmt(res.points)}</b> نقطة قيد التثبيت</>}</p>
          {res.code === 'HELD' && <div className="card gold flat small" style={{ textAlign: 'start' }}><b>النقاط تتثبت خلال 24 ساعة.</b> ما تحتاج تسوي شي، ونبلغك أول ما تتثبت.</div>}
          {res.lines && <div className="card" style={{ marginTop: 12, textAlign: 'start' }}><Lines lines={res.lines} total={res.points} /></div>}
          {res.reward && <div className="card row" style={{ marginTop: 12, textAlign: 'start' }}><Icon name="gift" size={26} /><div className="grow"><b>{res.reward.title_ar}</b><div className="small muted">انضافت لحقيبتك — استبدلها بالمحل</div></div></div>}
          {res.rank && <div className="card dark" style={{ marginTop: 12 }}><div className="small muted">Golden Drop</div><b style={{ fontFamily: 'var(--f-display)', fontSize: 22 }}>الفائز رقم {res.rank}</b></div>}
          <div className="stack" style={{ marginTop: 18 }}>
            <button className="btn gold block" onClick={() => navigator.share?.({ text: `لكيتها! ${res.spot?.title_ar ?? ''} · AMOUNI — شنو أكو اليوم؟` }).catch(() => {})}><Icon name="share" /> شارك</button>
            <Link className="btn primary block" to="/app">لقطة جديدة</Link>
            {res.reward && <Link className="btn ghost block" to="/app/bag">حقيبتي</Link>}
          </div>
        </div>
      </>
    );
    const [icon, tip] = TIPS[res.code] ?? ['x', ''];
    return (
      <>
        <TopBar title="النتيجة" />
        <div className="page center" style={{ paddingTop: 30 }}>
          <div className={`cat lg ${res.code === 'REVIEW' ? 'c-mystery' : 'c-food'}`} style={{ margin: '0 auto' }}><Icon name={icon} size={36} /></div>
          <h1 style={{ marginTop: 14, fontSize: 24 }}>{res.message}</h1>
          {tip && <p className="muted" style={{ marginTop: 8, maxWidth: '34ch', marginInline: 'auto' }}>{tip}</p>}
          <div className="stack" style={{ marginTop: 22 }}>
            {['TOO_FAR', 'NO_LOCATION', 'DYNAMIC_STALE', 'QR_UNKNOWN'].includes(res.code) && <button className="btn primary block" onClick={again}>جرّب مرة ثانية</button>}
            {['ALREADY_FOUND', 'SOLD_OUT', 'PLACE_COOLDOWN', 'SPOT_CLOSED', 'QR_EXPIRED'].includes(res.code) && <Link className="btn primary block" to="/app">شوف فرص ثانية</Link>}
            <button className="btn ghost block" onClick={() => nav('/app')}>الرئيسية</button>
          </div>
        </div>
      </>
    );
  }

  if (res?.code === 'STEP_UP' && mode === 'scan') return (
    <>
      <TopBar title="خطوة أخيرة" />
      <div className="page center" style={{ paddingTop: 24 }}>
        <div className="cat lg c-gold" style={{ margin: '0 auto' }}><Icon name="shield" size={36} /></div>
        <h1 style={{ marginTop: 14, fontSize: 24 }}>خطوة أخيرة وتنثبت</h1>
        <p className="muted" style={{ maxWidth: '34ch', margin: '8px auto' }}>اطلب من الكاشير يفتح «شاشة AMOUNI» وامسح الباركود اللي عليها. +<b className="num">{fmt(res.points)}</b> نقطة تنتظرك.</p>
        {res.step_up_until && <p className="chip amber num" style={{ margin: '6px auto' }}>باقي {left(res.step_up_until, now)}</p>}
        <div className="stack" style={{ marginTop: 18 }}>
          <button className="btn gold block lg" onClick={() => { setMode('stepup'); setScanKey((k) => k + 1); }}>امسح شاشة الكاشير</button>
          <button className="btn ghost block" onClick={() => nav('/app')}>بعدين (يروح للمراجعة)</button>
        </div>
      </div>
    </>
  );

  return (
    <>
      <TopBar back title={mode === 'stepup' ? 'شاشة الكاشير' : 'امسح'} />
      <div className="page" style={{ paddingTop: 14 }}>
        {hunt.data && mode === 'scan' && (
          <div className="card tint flat row small" style={{ marginBottom: 12 }}>
            <Icon name="clock" /><span className="grow">لقطة شغّالة: <b>{hunt.data.merchant ?? hunt.data.title_ar}</b> · +{fmt(hunt.data.quote.total)} محجوزة</span>
          </div>
        )}
        <Scanner key={scanKey} onResult={onScan} busy={busy} title={mode === 'stepup' ? 'وجّه الكاميرا على شاشة الكاشير' : undefined} />
        {last.current && !busy && !res && (
          <button className="btn block" style={{ marginTop: 10 }} onClick={() => submit(last.current!)}>إعادة المحاولة</button>
        )}
      </div>
    </>
  );
}
