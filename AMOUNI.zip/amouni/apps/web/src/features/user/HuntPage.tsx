import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { distanceM, useGeo, useInterval, useNow } from '@/lib/hooks';
import { dist, fmt, left } from '@/lib/format';
import { Empty, Lines, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { TopBar, useActiveHunt } from './UserApp';

const LOCK_MS = 45 * 60_000;

export function HuntPage() {
  const hunt = useActiveHunt();
  const { fix } = useGeo();
  const now = useNow(1000);
  const nav = useNavigate();
  const qc = useQueryClient();
  const { run, busy } = useAsync();
  const [arrived, setArrived] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const h = hunt.data;

  // Movement trail: one fix every 20 s while the hunt screen is open (only during an active hunt).
  useInterval(() => {
    if (!h || fix.approximate) return;
    rpc<{ arrived: boolean }>('hunt_ping', { hunt_id: h.hunt_id, lat: fix.lat, lng: fix.lng, accuracy: Math.round(fix.accuracy) })
      .then((r) => r.arrived && setArrived(true)).catch(() => {});
  }, h ? 20_000 : null);

  if (hunt.isLoading) return <><TopBar back title="اللقطة" /><Spinner /></>;
  if (!h) return <><TopBar back title="اللقطة" /><Empty title="ماكو لقطة شغّالة" icon="flag"><p>اختار فرصة من الرئيسية وابدأ.</p><Link className="btn primary" style={{ marginTop: 12 }} to="/app">الرئيسية</Link></Empty></>;

  const remaining = new Date(h.expires_at).getTime() - now;
  const d = distanceM(fix, h);
  const inside = arrived || !!h.arrived_at || d <= (h.circle_m ?? 80);
  const getHint = () => run(async () => {
    const r = await rpc<{ available: boolean; hint_ar?: string }>('hunt_hint', { hunt_id: h.hunt_id });
    setHint(r.available ? (r.hint_ar ?? 'دوّر قرب الكاشير') : 'التلميح ينفتح لما توصل للمكان');
  });
  const cancel = () => run(async () => { await rpc('cancel_hunt', { hunt_id: h.hunt_id }); await qc.invalidateQueries({ queryKey: ['hunt'] }); nav('/app'); }, 'انلغت اللقطة');

  return (
    <>
      <TopBar back title="لقطة شغّالة" />
      <div className="page">
        <div className="center" style={{ marginTop: 16 }}>
          <div className="eyebrow">{h.kind === 'mystery' ? 'فرصة مخفية' : h.title_ar}</div>
          <h1 style={{ marginTop: 4 }}>{h.merchant ?? 'دوّر داخل الدائرة'}</h1>
        </div>
        <div className="ring" style={{ ['--p' as string]: Math.max(0, (remaining / LOCK_MS) * 100) }}>
          <div><div className="big num">{left(h.expires_at, now)}</div><div className="small muted">النقاط محجوزة</div><b className="num" style={{ color: 'var(--gold)' }}>+{fmt(h.quote.total)}</b></div>
        </div>

        <div className={`card ${inside ? 'tint' : ''}`}>
          <div className="row">
            <Icon name={inside ? 'check' : 'walk'} size={26} />
            <div className="grow">
              <b style={{ fontFamily: 'var(--f-display)' }}>{inside ? 'وصلت! دوّر على باركود AMOUNI الذهبي' : `باقيلك ${dist(d)}`}</b>
              <div className="small muted">{fix.approximate ? 'فعّل الموقع حتى نحسب المسافة بدقة' : inside ? 'عادةً يكون بمكان ظاهر داخل المحل' : `حوالي ${Math.max(1, Math.round(d / 80))} دقيقة مشي`}</div>
            </div>
          </div>
          {inside && (hint ? <p className="card gold flat small" style={{ marginTop: 10 }}><b>تلميح:</b> {hint}</p>
                            : <button className="btn sm" style={{ marginTop: 10 }} onClick={getHint} disabled={busy}>اعطيني تلميح</button>)}
        </div>

        <div className="card flat" style={{ marginTop: 12 }}><Lines lines={h.quote.lines} total={h.quote.total} /></div>

        <div className="stack" style={{ marginTop: 16 }}>
          <button className="btn gold block lg" onClick={() => nav('/app/scan')}><Icon name="qr" /> امسح الباركود</button>
          <a className="btn block" href={`https://www.google.com/maps/dir/?api=1&destination=${h.lat},${h.lng}`} target="_blank" rel="noreferrer"><Icon name="map" /> الاتجاهات</a>
          <button className="btn ghost block" onClick={cancel} disabled={busy}>إلغاء اللقطة</button>
        </div>
      </div>
    </>
  );
}
