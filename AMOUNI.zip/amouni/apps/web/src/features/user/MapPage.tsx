import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { rpc, type SpotCard } from '@/lib/api';
import { useGeo } from '@/lib/hooks';
import { CATEGORY_AR } from '@/lib/format';
import { AmouniMap } from '@/ui/Map';
import { SpotRow } from '@/ui/kit';
import { TopBar } from './UserApp';

export function MapPage() {
  const { fix, ready } = useGeo();
  const nav = useNavigate();
  const [cat, setCat] = useState<string | null>(null);
  const [sel, setSel] = useState<string | null>(null);
  const key = `${fix.lat.toFixed(2)},${fix.lng.toFixed(2)}`;
  const q = useQuery({ queryKey: ['map', key, 10, cat], queryFn: () => rpc<SpotCard[]>('discover_map', { lat: fix.lat, lng: fix.lng, radius_km: 10, category: cat }), enabled: ready });
  const spots = q.data ?? [];
  const points = useMemo(() => spots.map((s) => ({ id: s.spot_id, lat: s.lat, lng: s.lng, kind: s.kind, category: s.category, circle_m: s.circle_m, label: s.merchant ?? s.title_ar })), [spots]);
  const ordered = sel ? [...spots.filter((s) => s.spot_id === sel), ...spots.filter((s) => s.spot_id !== sel)] : spots;

  return (
    <>
      <TopBar title="الخريطة" />
      <div className="mapbox map-full" style={{ borderRadius: 0, border: 0 }}>
        <AmouniMap center={fix} me={fix.approximate ? null : fix} points={points} onSelect={setSel} zoom={13.5} />
        <div className="map-top chips">
          <button className={`chip ${!cat ? 'on' : ''}`} onClick={() => setCat(null)}>الكل</button>
          {Object.entries(CATEGORY_AR).slice(0, 9).map(([k, v]) => <button key={k} className={`chip ${cat === k ? 'on' : ''}`} onClick={() => setCat(k)}>{v}</button>)}
        </div>
        <div className="map-cards">
          {ordered.slice(0, 12).map((s) => <SpotRow key={s.spot_id} s={s} onClick={() => nav(`/app/spot/${s.spot_id}`)} />)}
        </div>
      </div>
    </>
  );
}
