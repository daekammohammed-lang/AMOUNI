import { Link, useNavigate } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { errorText, rpc } from '@/lib/api';
import { applyTheme } from '@/lib/hooks';
import { ago, dateAr, fmt } from '@/lib/format';
import { signOut, useRoles } from '@/app/session';
import { Bar, Empty, Spinner, useAsync, useToast } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { TopBar, useProfile } from './UserApp';

const SEGMENT_AR: Record<string, string> = { new: 'مستكشف جديد', explorer: 'رحّال المدينة', foodie: 'ذوّاق', reward_hunter: 'صياد جوائز', regular: 'لاقط' };

export function Profile() {
  const p = useProfile();
  const roles = useRoles();
  const toast = useToast();
  const nav = useNavigate();
  if (!p.data) return <><TopBar title="حسابي" /><Spinner /></>;
  const d = p.data;
  const share = () => {
    const t = `جرّب AMOUNI ويايه: اكتشف أماكن الرمادي واربح جوائز. سجّل بكود الدعوة ${d.invite_code}`;
    if (navigator.share) navigator.share({ text: t }).catch(() => {}); else navigator.clipboard?.writeText(t).then(() => toast('انسخ الكود'));
  };
  const merchants = roles.data?.merchants.filter((m) => m.active) ?? [];
  const invites = roles.data?.merchants.filter((m) => !m.active) ?? [];

  return (
    <>
      <TopBar title="حسابي" />
      <div className="page">
        <div className="row" style={{ marginTop: 16 }}>
          <span className="cat lg c-mystery" style={{ borderRadius: '50%' }}><b style={{ fontSize: 28, fontFamily: 'var(--f-display)' }}>{d.display_name?.[0]}</b></span>
          <div className="grow"><h1 style={{ fontSize: 22 }}>{d.display_name}</h1><div className="muted small">{SEGMENT_AR[d.segment] ?? ''} · عضو من {dateAr(d.joined)}</div></div>
        </div>
        <div className="card" style={{ marginTop: 14 }}>
          <div className="row between"><div><div className="eyebrow">المستوى</div><b style={{ fontFamily: 'var(--f-display)', fontSize: 18 }}>{d.level.name_ar}</b></div><span className="small muted num">{fmt(d.level.xp)} XP</span></div>
          <div style={{ margin: '10px 0 6px' }}><Bar pct={d.level.pct} /></div>
          <div className="small muted">{d.level.next_at ? `باقي ${fmt(d.level.next_at - d.level.xp)} XP حتى «${d.level.next_name_ar}»` : 'وصلت أعلى مستوى'}. الـ XP للتقدّم بس، مو نقاط.</div>
        </div>
        <div className="kpis" style={{ marginTop: 12 }}>
          <div className="kpi"><div className="v num" style={{ color: 'var(--gold)' }}>{fmt(d.wallet.available)}</div><div className="l">نقطة</div></div>
          <div className="kpi"><div className="v num">{d.stats.places}</div><div className="l">مكان اكتشفته</div></div>
          <div className="kpi"><div className="v num">{d.streak.days}</div><div className="l">أيام ورا بعض</div></div>
          <div className="kpi"><div className="v num">{d.stats.redeemed}</div><div className="l">جائزة استبدلتها</div></div>
        </div>
        <div className="card tint" style={{ marginTop: 12 }}>
          <div className="eyebrow">ادعُ صديق</div>
          <b style={{ fontFamily: 'var(--f-display)' }}>شارك كودك ووسّع خريطة الاكتشاف</b>
          <div className="row" style={{ marginTop: 10 }}><span className="num grow card flat center" style={{ padding: 8, letterSpacing: '.12em', direction: 'ltr' }}>{d.invite_code}</span><button className="btn primary sm" onClick={share}><Icon name="share" /> شارك</button></div>
          {d.stats.invited > 0 && <div className="small muted" style={{ marginTop: 6 }}>دعيت <span className="num">{d.stats.invited}</span> أشخاص</div>}
        </div>

        {invites.length > 0 && <InviteCards invites={invites} />}

        <div className="sec-h"><h2>حسابي</h2></div>
        <div className="card flat list">
          <Link to="/app/history" className="it" style={{ color: 'inherit' }}><Icon name="list" /><span className="grow">سجل النقاط والمسحات</span><Icon name="chev" /></Link>
          <Link to="/app/notifications" className="it" style={{ color: 'inherit' }}><Icon name="bell" /><span className="grow">الإشعارات</span><Icon name="chev" /></Link>
          {merchants.length > 0 ? <Link to="/merchant" className="it" style={{ color: 'inherit' }}><Icon name="store" /><span className="grow">لوحة المحل</span><Icon name="chev" /></Link>
                                : <Link to="/merchant/join" className="it" style={{ color: 'inherit' }}><Icon name="store" /><span className="grow">عندك محل؟ سجّله بـ AMOUNI</span><Icon name="chev" /></Link>}
          {(roles.data?.platform_roles.length ?? 0) > 0 && <Link to="/admin" className="it" style={{ color: 'inherit' }}><Icon name="shield" /><span className="grow">مركز القيادة</span><Icon name="chev" /></Link>}
          <button className="it" style={{ background: 'none', border: 0, textAlign: 'start', width: '100%' }} onClick={() => applyTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark')}><Icon name="sun" /><span className="grow">الوضع الفاتح / الداكن</span></button>
          <button className="it" style={{ background: 'none', border: 0, textAlign: 'start', width: '100%', color: 'var(--warn)' }} onClick={async () => { await signOut(); nav('/'); }}><Icon name="out" /><span className="grow">تسجيل الخروج</span></button>
        </div>
        <p className="small muted center" style={{ marginTop: 14 }}>موقعك يُستخدم بس وقت اللقطة والمسح. ما نتتبعك بالخلفية.</p>
      </div>
    </>
  );
}

function InviteCards({ invites }: { invites: { merchant_id: string; name: string; role: string }[] }) {
  const qc = useQueryClient();
  const { busy, run } = useAsync();
  return (
    <div className="stack" style={{ marginTop: 12 }}>
      {invites.map((i) => (
        <div key={i.merchant_id} className="card gold row">
          <Icon name="store" /><div className="grow"><b>{i.name}</b><div className="small muted">دعوة للانضمام كـ {i.role === 'cashier' ? 'كاشير' : 'مدير'}</div></div>
          <button className="btn primary sm" disabled={busy} onClick={() => run(async () => { await rpc('merchant_accept_invite', { merchant: i.merchant_id }); await qc.invalidateQueries({ queryKey: ['roles'] }); }, 'انضميت للمحل')}>قبول</button>
        </div>
      ))}
    </div>
  );
}

type Scan = { id: string; code: string; points: number; created_at: string; spot: string | null; merchant: string | null };
type Wallet = { history: { kind: string; ref_type: string; reason: string | null; amount: number; at: string }[] };
const TX_AR: Record<string, string> = { earn: 'مسح', hold: 'قيد التثبيت', release: 'تثبيت', reverse: 'إلغاء', spend: 'شراء جائزة', mission: 'مهمة', adjust: 'تعديل', refund: 'استرجاع', expire: 'انتهاء' };

export function History() {
  const w = useQuery({ queryKey: ['wallet'], queryFn: () => rpc<Wallet>('my_wallet') });
  const s = useQuery({ queryKey: ['scans'], queryFn: () => rpc<Scan[]>('my_scans') });
  return (
    <>
      <TopBar back title="السجل" />
      <div className="page">
        <div className="sec-h"><h2>حركة النقاط</h2></div>
        {w.isLoading ? <Spinner /> : !w.data?.history.length ? <Empty title="ماكو حركة بعد" /> : (
          <div className="card flat list">{w.data.history.map((h, i) => (
            <div key={i} className="it"><div className="grow"><b>{TX_AR[h.kind] ?? h.kind}</b><div className="small muted">{h.reason ?? ''} · {ago(h.at)}</div></div>
              <b className="num" style={{ color: h.amount > 0 ? 'var(--ok)' : 'var(--warn)' }}>{h.amount > 0 ? '+' : ''}{fmt(h.amount)}</b></div>
          ))}</div>
        )}
        <div className="sec-h"><h2>المسحات</h2></div>
        {s.isLoading ? <Spinner /> : !s.data?.length ? <Empty title="ما مسحت بعد" /> : (
          <div className="card flat list">{s.data.map((x) => (
            <div key={x.id} className="it"><div className="grow"><b>{x.merchant ?? '—'}</b><div className="small muted">{x.spot ?? ''} · {ago(x.created_at)}</div></div>
              <span className={`chip ${x.code === 'OK' ? 'ok' : x.code === 'HELD' || x.code === 'REVIEW' || x.code === 'STEP_UP' ? 'amber' : 'warn'}`}>{x.code === 'OK' ? `+${fmt(x.points)}` : errorText(x.code).split('،')[0].split('.')[0]}</span></div>
          ))}</div>
        )}
      </div>
    </>
  );
}

type Notif = { id: string; kind: string; payload: Record<string, unknown>; at: string; read: boolean };
const N_AR: Record<string, (p: Record<string, unknown>) => string> = {
  scan_resolved: (p) => (p.approved ? 'انثبت مسحك ونقاطك صارت متاحة ✓' : 'راجعنا مسحك وما كدرنا نثبته'),
  staff_invite: () => 'وصلتك دعوة للانضمام لفريق محل — شوفها بحسابك',
  qr_leak: (p) => `باركود «${p.label ?? ''}» انتشرت صورته وتوقف. اطبع الجديد`,
};

export function Notifications() {
  const q = useQuery({ queryKey: ['notifications'], queryFn: () => rpc<{ unread: number; items: Notif[] }>('my_notifications') });
  const qc = useQueryClient();
  const readAll = async () => { await rpc('notification_read', {}); qc.invalidateQueries({ queryKey: ['notifications'] }); };
  return (
    <>
      <TopBar back title="الإشعارات" />
      <div className="page">
        {(q.data?.unread ?? 0) > 0 && <div className="row" style={{ justifyContent: 'flex-end', marginTop: 10 }}><button className="link small" onClick={readAll}>علّم الكل كمقروء</button></div>}
        {q.isLoading ? <Spinner /> : !q.data?.items.length ? <Empty title="ماكو إشعارات" icon="bell">نبلغك هنا لما يتثبت مسح أو تخلص مهمة.</Empty> : (
          <div className="card flat list" style={{ marginTop: 10 }}>{q.data.items.map((n) => (
            <div key={n.id} className="it" style={{ fontWeight: n.read ? 400 : 600 }}><Icon name="bell" /><div className="grow">{N_AR[n.kind]?.(n.payload) ?? n.kind}<div className="small muted">{ago(n.at)}</div></div>{!n.read && <span className="chip gold" style={{ padding: '0 6px' }}>جديد</span>}</div>
          ))}</div>
        )}
      </div>
    </>
  );
}
