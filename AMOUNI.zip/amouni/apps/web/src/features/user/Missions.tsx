import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc } from '@/lib/api';
import { useNow } from '@/lib/hooks';
import { fmt, left } from '@/lib/format';
import { Bar, Empty, Spinner, useAsync } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { TopBar, useProfile } from './UserApp';

type Mission = { mission_id: string; code: string; kind: string; title_ar: string; target: number; progress: number; reward_points: number; claimed: boolean; ends_at: string };

export function Missions() {
  const q = useQuery({ queryKey: ['missions'], queryFn: () => rpc<Mission[]>('my_missions') });
  const profile = useProfile();
  const qc = useQueryClient();
  const now = useNow(1000);
  const { busy, run } = useAsync();
  const claim = (m: Mission) => run(async () => {
    await rpc('claim_mission', { mission_id: m.mission_id });
    await Promise.all([qc.invalidateQueries({ queryKey: ['missions'] }), qc.invalidateQueries({ queryKey: ['profile'] })]);
  }, `+${m.reward_points} نقطة من المهمة`);
  const st = profile.data?.streak;

  return (
    <>
      <TopBar title="المهام" />
      <div className="page">
        <p className="muted" style={{ marginTop: 14 }}>المهام تنحسب بس من الزيارات الموثقة. كل مهمة تخليك تكتشف أماكن جديدة.</p>
        {q.isLoading ? <Spinner /> : !q.data?.length ? <Empty title="ماكو مهام هسه" icon="flag" /> : (
          <div className="stack" style={{ marginTop: 14 }}>
            {q.data.map((m) => {
              const done = m.progress >= m.target;
              return (
                <div key={m.mission_id} className={`card ${done && !m.claimed ? 'gold' : ''}`}>
                  <div className="row">
                    <span className="cat c-mystery"><Icon name="flag" /></span>
                    <div className="grow"><div className="eyebrow">{m.kind === 'daily' ? 'مهمة اليوم' : 'مهمة الأسبوع'}</div><b style={{ fontFamily: 'var(--f-display)', fontSize: 16 }}>{m.title_ar}</b></div>
                    <span className="chip gold num">+{fmt(m.reward_points)}</span>
                  </div>
                  <div className="row small" style={{ marginTop: 12 }}><span className="grow"><Bar pct={(m.progress / m.target) * 100} /></span><b className="num">{m.progress}/{m.target}</b></div>
                  <div className="row between small muted" style={{ marginTop: 8 }}>
                    <span>تنتهي خلال <span className="num">{left(m.ends_at, now)}</span></span>
                    {m.claimed ? <span className="chip ok">استلمتها ✓</span> : done ? <button className="btn gold sm" disabled={busy} onClick={() => claim(m)}>استلم الجائزة</button> : null}
                  </div>
                </div>
              );
            })}
          </div>
        )}
        {st && (
          <div className="card" style={{ marginTop: 14 }}>
            <div className="row between"><div><div className="eyebrow">سلسلة الأيام</div><b style={{ fontFamily: 'var(--f-display)', fontSize: 17 }}><span className="num">{st.days}</span> {st.days === 1 ? 'يوم' : 'أيام'} ورا بعض</b></div><span style={{ color: st.days ? 'var(--gold)' : 'var(--muted)' }}><Icon name="fire" size={30} /></span></div>
            <div className="row" style={{ justifyContent: 'space-between', marginTop: 12 }}>
              {['س', 'ح', 'ن', 'ث', 'ر', 'خ', 'ج'].map((d, i) => (
                <div key={i} className="center small muted"><div style={{ width: 28, height: 28, borderRadius: '50%', background: st.week[i] ? 'var(--gold-fill)' : 'var(--surface-2)', margin: '0 auto 4px' }} />{d}</div>
              ))}
            </div>
            <p className="small muted" style={{ marginTop: 8 }}>زيارة موثقة وحدة باليوم تكفي حتى ما تنكطع السلسلة.</p>
          </div>
        )}
      </div>
    </>
  );
}
