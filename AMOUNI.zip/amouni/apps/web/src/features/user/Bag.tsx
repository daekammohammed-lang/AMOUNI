import { useEffect, useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, supabase } from '@/lib/api';
import { newKey, useGeo, useInterval, useNow } from '@/lib/hooks';
import { CATEGORY_AR, dateAr, dist, fmt, left } from '@/lib/format';
import { QrImage } from '@/ui/qr';
import { Empty, Sheet, Spinner, useAsync, useToast } from '@/ui/kit';
import { CatIcon, Icon } from '@/ui/icons';
import { TopBar, useProfile } from './UserApp';

type BagItem = { id: string; status: string; source: string; expires_at: string; title_ar: string; terms_ar: string | null; merchant: string; category: string };
type StoreItem = { id: string; title_ar: string; cost: number; stock: number; validity_days: number; terms_ar: string | null; merchant: string; category: string; distance_m: number | null };
type Token = { code: string; qr: string; expires_at: string };

const STATUS: Record<string, [string, string]> = {
  available: ['متاحة', 'ok'], held: ['قيد التثبيت', 'amber'], redeemed: ['مستبدلة', 'primary'], expired: ['انتهت', 'warn'], cancelled: ['ملغاة', 'warn'],
};

function RedeemSheet({ item, onClose }: { item: BagItem | null; onClose: () => void }) {
  const [tok, setTok] = useState<Token | null>(null);
  const [done, setDone] = useState(false);
  const now = useNow(500);
  const qc = useQueryClient();
  const issue = async (id: string) => setTok(await rpc<Token>('issue_redeem_token', { bag_item_id: id }));
  useEffect(() => { setTok(null); setDone(false); if (item) issue(item.id).catch(() => {}); }, [item]);
  useEffect(() => { if (item && tok && new Date(tok.expires_at).getTime() < now && !done) issue(item.id).catch(() => {}); }, [now, tok, item, done]);
  // The cashier confirms on their device; we watch our own bag item (RLS: only our rows) for the result.
  useInterval(async () => {
    if (!item || done) return;
    const { data } = await supabase.from('bag_items').select('status').eq('id', item.id).single();
    if (data?.status === 'redeemed') { setDone(true); qc.invalidateQueries({ queryKey: ['bag'] }); navigator.vibrate?.(60); }
  }, item && !done ? 2000 : null);

  return (
    <Sheet open={!!item} onClose={onClose}>
      {item && (done ? (
        <div className="center found" style={{ padding: '20px 0' }}>
          <div className="burst"><Icon name="check" size={60} /></div>
          <h1 style={{ fontSize: 28 }}>تم الاستبدال ✓</h1><p className="muted">{item.title_ar} — {item.merchant}</p>
          <button className="btn primary block" style={{ marginTop: 18 }} onClick={onClose}>تمام</button>
        </div>
      ) : (
        <div className="center">
          <div className="eyebrow">استبدال الجائزة</div>
          <h2 style={{ marginTop: 4 }}>{item.title_ar}</h2><p className="muted">{item.merchant}</p>
          <div className="card" style={{ margin: '14px 0' }}>
            {tok ? <>
              <QrImage value={tok.qr} size={220} />
              <div className="small muted" style={{ marginTop: 6 }}>أو خلّي الموظف يكتب الكود</div>
              <div className="num" style={{ fontSize: 36, letterSpacing: '.25em', fontWeight: 600, direction: 'ltr' }}>{tok.code}</div>
              <div className="small muted">يتجدد خلال <span className="num">{left(tok.expires_at, now)}</span></div>
            </> : <Spinner />}
          </div>
          <p className="small muted">الكود يتغيّر كل دقيقة، فالسكرين شوت ما ينفع لغيرك.{item.terms_ar ? ` · ${item.terms_ar}` : ''}</p>
        </div>
      ))}
    </Sheet>
  );
}

export function Bag() {
  const [tab, setTab] = useState<'bag' | 'store'>('bag');
  const [open, setOpen] = useState<BagItem | null>(null);
  const [buy, setBuy] = useState<StoreItem | null>(null);
  const { fix } = useGeo();
  const profile = useProfile();
  const qc = useQueryClient();
  const toast = useToast();
  const { busy, run } = useAsync();
  const bag = useQuery({ queryKey: ['bag'], queryFn: () => rpc<BagItem[]>('my_bag') });
  const store = useQuery({ queryKey: ['store'], queryFn: () => rpc<StoreItem[]>('store_list', { lat: fix.lat, lng: fix.lng }), enabled: tab === 'store' });
  const balance = profile.data?.wallet.available ?? 0;

  const purchase = async () => {
    if (!buy) return;
    const r = await run(() => rpc('buy_reward', { reward_id: buy.id, idem: newKey() }));
    if (r) {
      toast('انضافت لحقيبتك'); setBuy(null); setTab('bag');
      ['bag', 'profile', 'store'].forEach((k) => qc.invalidateQueries({ queryKey: [k] }));
    }
  };

  return (
    <>
      <TopBar title="الحقيبة" />
      <div className="page">
        <div className="card dark row" style={{ marginTop: 14 }}>
          <div className="grow"><div className="small muted">رصيدك</div><b className="num" style={{ fontSize: 30, fontFamily: 'var(--f-display)', color: 'var(--gold-fill)' }}>{fmt(balance)}</b>
            {(profile.data?.wallet.held ?? 0) > 0 && <div className="small muted">+{fmt(profile.data?.wallet.held)} قيد التثبيت</div>}</div>
          <button className="btn gold" onClick={() => setTab('store')}>اصرفها</button>
        </div>
        <div className="seg" style={{ marginTop: 14 }}>
          <button className={tab === 'bag' ? 'on' : ''} onClick={() => setTab('bag')}>جوائزي</button>
          <button className={tab === 'store' ? 'on' : ''} onClick={() => setTab('store')}>متجر النقاط</button>
        </div>

        {tab === 'bag' ? (bag.isLoading ? <Spinner /> : !bag.data?.length ? <Empty title="حقيبتك فارغة" icon="gift">الجوائز اللي تربحها أو تشتريها بالنقاط تظهر هنا.</Empty> : (
          <div className="stack" style={{ marginTop: 14 }}>
            {bag.data.map((b) => (
              <div key={b.id} className="card row">
                <span className={`cat c-${b.category}`}><CatIcon cat={b.category} /></span>
                <div className="grow"><b style={{ fontFamily: 'var(--f-display)' }}>{b.title_ar}</b><div className="small muted">{b.merchant} · ينتهي {dateAr(b.expires_at)}</div>
                  <span className={`chip ${STATUS[b.status]?.[1]}`} style={{ marginTop: 6 }}>{STATUS[b.status]?.[0]}</span></div>
                {b.status === 'available' && <button className="btn primary sm" onClick={() => setOpen(b)}>استبدل</button>}
              </div>
            ))}
          </div>
        )) : (store.isLoading ? <Spinner /> : (
          <div className="stack" style={{ marginTop: 14 }}>
            <p className="small muted">أسعار الجوائز تحددها AMOUNI. النقاط ما تنشرى ولا تنحول لفلوس.</p>
            {(store.data ?? []).map((s) => (
              <button key={s.id} className="spot" onClick={() => setBuy(s)}>
                <span className={`cat c-${s.category}`}><CatIcon cat={s.category} /></span>
                <span className="grow"><b>{s.title_ar}</b><span className="small muted">{s.merchant}{s.distance_m !== null ? ` · ${dist(s.distance_m)}` : ''} · باقي {s.stock}</span></span>
                <span className="pts num" style={{ color: s.cost <= balance ? 'var(--gold)' : 'var(--muted)' }}>{fmt(s.cost)}</span>
              </button>
            ))}
          </div>
        ))}
      </div>

      <RedeemSheet item={open} onClose={() => setOpen(null)} />
      <Sheet open={!!buy} onClose={() => setBuy(null)}>
        {buy && <div className="stack">
          <div className="row"><span className={`cat c-${buy.category}`}><CatIcon cat={buy.category} /></span><div className="grow"><h2>{buy.title_ar}</h2><div className="muted small">{buy.merchant} · {CATEGORY_AR[buy.category]}</div></div></div>
          <dl className="kv"><dt>السعر</dt><dd className="num">{fmt(buy.cost)} نقطة</dd><dt>رصيدك بعدها</dt><dd className="num">{fmt(balance - buy.cost)}</dd><dt>صالحة</dt><dd>{buy.validity_days} يوم</dd>{buy.terms_ar && <><dt>الشروط</dt><dd>{buy.terms_ar}</dd></>}</dl>
          <button className="btn gold block lg" disabled={busy || buy.cost > balance} onClick={purchase}>{buy.cost > balance ? `تحتاج ${fmt(buy.cost - balance)} نقطة بعد` : 'اشترِ بالنقاط'}</button>
        </div>}
      </Sheet>
    </>
  );
}
