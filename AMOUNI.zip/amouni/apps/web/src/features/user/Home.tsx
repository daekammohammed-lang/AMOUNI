import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { rpc, type SpotCard } from '@/lib/api';
import { useGeo, useNow } from '@/lib/hooks';
import { fmt, left } from '@/lib/format';
import { Bar, Empty, SpotRow } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { TopBar, useActiveHunt, useProfile } from './UserApp';

type Mission = { mission_id: string; code: string; kind: string; title_ar: string; target: number; progress: number; reward_points: number; claimed: boolean; ends_at: string };
type Discovery = { places: number; discovered: number; districts: { id: string; name_ar: string; places: number; discovered: number }[] };

export function Home() {
  const { fix, ready } = useGeo();
  const nav = useNavigate();
  const profile = useProfile();
  const hunt = useActiveHunt();
  const now = useNow(1000);
  const key = `${fix.lat.toFixed(3)},${fix.lng.toFixed(3)}`;
  const picks = useQuery({ queryKey: ['picks', key], queryFn: () => rpc<SpotCard[]>('discover_picks', { lat: fix.lat, lng: fix.lng, limit: 3 }), enabled: ready });
  const nearby = useQuery({ queryKey: ['map', key, 3], queryFn: () => rpc<SpotCard[]>('discover_map', { lat: fix.lat, lng: fix.lng, radius_km: 3 }), enabled: ready });
  const missions = useQuery({ queryKey: ['missions'], queryFn: () => rpc<Mission[]>('my_missions') });
  const disc = useQuery({ queryKey: ['discovery', profile.data?.city_id], queryFn: () => rpc<Discovery>('my_discovery', { city: profile.data!.city_id }), enabled: !!profile.data?.city_id });

  const first = profile.data?.display_name?.split(' ')[0];
  const ready3 = (picks.data ?? []).map((p) => p.spot_id);
  const others = (nearby.data ?? []).filter((s) => !ready3.includes(s.spot_id)).slice(0, 6);
  const daily = missions.data?.find((m) => m.kind === 'daily');

  return (
    <>
      <TopBar />
      <div className="page">
        <section className="hero">
          <h1>شنو أكو اليوم؟</h1>
          <p className="sub">هلا {first ?? ''} — {fmt(nearby.data?.length)} فرص حولك{profile.data?.wallet.held ? ` · ${fmt(profile.data.wallet.held)} نقطة قيد التثبيت` : ''}</p>
        </section>

        {hunt.data && (
          <button className="card dark row" style={{ width: '100%', marginTop: 12, textAlign: 'start' }} onClick={() => nav('/app/hunt')}>
            <span className="cat c-gold"><Icon name="clock" /></span>
            <span className="grow"><b style={{ fontFamily: 'var(--f-display)' }}>لقطة شغّالة: {hunt.data.merchant ?? hunt.data.title_ar}</b>
              <span className="small muted" style={{ display: 'block' }}>+{fmt(hunt.data.quote.total)} نقطة محجوزة · باقي <span className="num">{left(hunt.data.expires_at, now)}</span></span></span>
            <Icon name="chev" />
          </button>
        )}

        <div className="sec-h"><h2>عندي لك 3 فرص اليوم</h2><Link to="/app/map">الخريطة</Link></div>
        {picks.isLoading || !ready ? <div className="stack">{[0, 1, 2].map((i) => <div key={i} className="skeleton" style={{ height: 78 }} />)}</div>
          : picks.data?.length ? <div className="stack">{picks.data.map((s) => <SpotRow key={s.spot_id} s={s} why onClick={() => nav(`/app/spot/${s.spot_id}`)} />)}</div>
          : <Empty title="ماكو فرص قريبة هسه" icon="compass">جرّب الخريطة أو ارجع بعد شوية.</Empty>}

        {daily && (
          <Link to="/app/missions" className="card row" style={{ marginTop: 18, color: 'inherit' }}>
            <span className="cat c-mystery"><Icon name="flag" /></span>
            <span className="grow">
              <span className="eyebrow">مهمة اليوم</span>
              <b style={{ display: 'block', fontFamily: 'var(--f-display)' }}>{daily.title_ar}</b>
              <span className="row small muted" style={{ marginTop: 6 }}><span className="grow"><Bar pct={(daily.progress / daily.target) * 100} /></span><span className="num">{daily.progress}/{daily.target}</span></span>
            </span>
            <span className="chip gold num">+{daily.reward_points}</span>
          </Link>
        )}

        {disc.data && (
          <div className="card" style={{ marginTop: 14 }}>
            <div className="row between"><div><div className="eyebrow">خريطة اكتشافك</div><b style={{ fontFamily: 'var(--f-display)' }}>اكتشفت <span className="num">{disc.data.discovered}</span> من <span className="num">{disc.data.places}</span> مكان</b></div><Icon name="compass" size={28} /></div>
            <div className="stack" style={{ gap: 8, marginTop: 12 }}>
              {disc.data.districts.filter((d) => d.places > 0).slice(0, 5).map((d) => (
                <div key={d.id} className="row small"><span style={{ width: 90 }}>{d.name_ar}</span><span className="grow"><Bar gold pct={(d.discovered / d.places) * 100} /></span><span className="num muted">{d.discovered}/{d.places}</span></div>
              ))}
            </div>
          </div>
        )}

        {others.length > 0 && <>
          <div className="sec-h"><h2>قريب منك</h2><Link to="/app/map">الكل</Link></div>
          <div className="stack">{others.map((s) => <SpotRow key={s.spot_id} s={s} onClick={() => nav(`/app/spot/${s.spot_id}`)} />)}</div>
        </>}
      </div>
    </>
  );
}
