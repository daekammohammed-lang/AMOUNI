import { useNavigate, useParams } from 'react-router-dom';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { rpc, type SpotCard } from '@/lib/api';
import { deviceFingerprint, useGeo } from '@/lib/hooks';
import { CATEGORY_AR, dist, fmt, reasonText } from '@/lib/format';
import { Lines, Spinner, SpotThumb, useAsync, Empty } from '@/ui/kit';
import { Icon } from '@/ui/icons';
import { TopBar, useActiveHunt } from './UserApp';

const KIND_AR: Record<string, string> = { golden_drop: 'Golden Drop', first_finder: 'First Finder', mystery: 'فرصة مخفية', normal: 'فرصة' };

export function SpotPage() {
  const { id } = useParams();
  const { fix, ready } = useGeo();
  const nav = useNavigate();
  const qc = useQueryClient();
  const hunt = useActiveHunt();
  const { busy, run } = useAsync();
  const q = useQuery({ queryKey: ['spot', id], queryFn: () => rpc<SpotCard>('get_spot', { spot_id: id, lat: fix.lat, lng: fix.lng }), enabled: ready, retry: false });
  const s = q.data;
  const hunting = hunt.data?.spot_id === id;

  const start = async () => {
    const r = await run(() => rpc<{ hunt_id: string; nonce: string }>('start_hunt', {
      spot_id: id, lat: fix.lat, lng: fix.lng, accuracy: Math.round(fix.accuracy), device_fp: deviceFingerprint(), platform: 'web' }));
    if (r) {
      sessionStorage.setItem(`amouni-nonce-${r.hunt_id}`, r.nonce);
      await qc.invalidateQueries({ queryKey: ['hunt'] });
      nav('/app/hunt');
    }
  };

  if (q.isLoading || !ready) return <><TopBar back title="الفرصة" /><Spinner /></>;
  if (!s) return <><TopBar back title="الفرصة" /><Empty title="هاي الفرصة مو متاحة هسه" icon="clock">ممكن خلصت أو انتهى وقتها.</Empty></>;
  const gold = s.kind === 'golden_drop' || s.kind === 'first_finder';

  return (
    <>
      <TopBar back title={KIND_AR[s.kind]} />
      <div className="page">
        <div className={`card ${gold ? 'gold' : ''}`} style={{ marginTop: 14, textAlign: 'center' }}>
          <div style={{ display: 'flex', justifyContent: 'center' }}><SpotThumb s={s} lg /></div>
          <div className="row" style={{ justifyContent: 'center', marginTop: 10 }}>
            <span className="chip primary">{KIND_AR[s.kind]}{s.category ? ` · ${CATEGORY_AR[s.category]}` : ''}</span>
            {s.busy && <span className="chip amber">زحمة هسه</span>}
          </div>
          <h1 style={{ marginTop: 8 }}>{s.merchant ?? 'فرصة مخفية'}</h1>
          <p className="muted">{s.merchant ? s.title_ar : `بمكان ما داخل دائرة ${s.circle_m} م. لما توصل الدائرة دوّر على الباركود.`}</p>
        </div>

        <div className="card" style={{ marginTop: 12 }}>
          <div className="row between"><span className="muted">النقاط اللي تاخذها</span><b className="num" style={{ fontSize: 30, color: 'var(--gold)', fontFamily: 'var(--f-display)' }}>+{fmt(s.points)}</b></div>
          <div style={{ marginTop: 10 }}><Lines lines={s.lines} /></div>
          {s.later.length > 0 && <p className="small muted" style={{ marginTop: 8 }}>{s.later.map((l) => `+${l.points} من ${l.from} لـ ${l.to}`).join(' · ')}</p>}
          <p className="small muted" style={{ marginTop: 8 }}>الرقم ينحجزلك {s.quote_lock_minutes ?? 45} دقيقة من تضغط «ابدأ».</p>
        </div>

        <div className="card" style={{ marginTop: 12 }}>
          <dl className="kv">
            <dt>المسافة</dt><dd className="num">{s.distance_m < 40 ? 'إنت هنا' : `${dist(s.distance_m)} · ${s.walk_min} د مشي`}</dd>
            {s.reward_ar && <><dt>جائزة فورية</dt><dd>{s.reward_ar}</dd></>}
            {s.qty_left !== null && <><dt>الكمية</dt><dd className="num">{s.qty_left} باقية من {s.qty_total}</dd></>}
            <dt>ليش أشوفها؟</dt><dd>{reasonText(s.reason)}</dd>
            <dt>القاعدة</dt><dd>مرة وحدة لكل شخص، ونفس المكان مرة بالأسبوع</dd>
          </dl>
        </div>

        <div className="stack" style={{ marginTop: 16 }}>
          {hunting ? <button className="btn primary block lg" onClick={() => nav('/app/hunt')}>كمّل اللقطة</button>
                   : <button className="btn primary block lg" onClick={start} disabled={busy}>{busy ? 'نحجز النقاط…' : 'ابدأ اللقطة'}</button>}
          <a className="btn block" href={`https://www.google.com/maps/dir/?api=1&destination=${s.lat},${s.lng}`} target="_blank" rel="noreferrer"><Icon name="map" /> الاتجاهات</a>
          <button className="btn ghost block" onClick={() => nav('/app/scan')}><Icon name="qr" /> أنا بالمحل — امسح هسه</button>
        </div>
      </div>
    </>
  );
}
