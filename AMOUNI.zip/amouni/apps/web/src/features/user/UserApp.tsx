import { lazy, Suspense } from 'react';
import { NavLink, Route, Routes, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { rpc, type ActiveHunt } from '@/lib/api';
import { fmt } from '@/lib/format';
import { Icon } from '@/ui/icons';
import { Home } from './Home';
import { SpotPage } from './SpotPage';
import { HuntPage } from './HuntPage';
import { Missions } from './Missions';
import { Spinner } from '@/ui/kit';

// Heavy screens (map engine, camera decoder, QR renderer) load on demand.
const MapPage = lazy(() => import('./MapPage').then((m) => ({ default: m.MapPage })));
const ScanPage = lazy(() => import('./ScanPage').then((m) => ({ default: m.ScanPage })));
const Bag = lazy(() => import('./Bag').then((m) => ({ default: m.Bag })));
import { Profile, History, Notifications } from './Profile';

export type ProfileData = {
  id: string; display_name: string; phone: string; city_id: string; joined: string; invite_code: string; segment: string;
  level: { name_ar: string; xp: number; next_name_ar: string | null; next_at: number | null; pct: number };
  wallet: { available: number; held: number }; streak: { days: number; week: boolean[] };
  stats: { visits: number; places: number; redeemed: number; invited: number };
};

export const useProfile = () => useQuery({ queryKey: ['profile'], queryFn: () => rpc<ProfileData>('my_profile') });
export const useActiveHunt = () => useQuery({ queryKey: ['hunt'], queryFn: () => rpc<ActiveHunt | null>('my_active_hunt'), refetchInterval: 60_000 });
export const useUnread = () => useQuery({ queryKey: ['notifications'], queryFn: () => rpc<{ unread: number; items: unknown[] }>('my_notifications'), refetchInterval: 60_000 });

export function TopBar({ title, back }: { title?: string; back?: boolean }) {
  const p = useProfile();
  const n = useUnread();
  const nav = useNavigate();
  return (
    <header className="topbar">
      {back ? <button className="iconbtn" onClick={() => nav(-1)} aria-label="رجوع"><Icon name="back" /></button>
            : <img className="mark" src="/logo-mark.webp" alt="AMOUNI" />}
      <div className="grow">
        {title ? <b style={{ fontFamily: 'var(--f-display)' }}>{title}</b>
               : <button className="loc" onClick={() => nav('/app/map')}><small>أنت هسه بـ</small><b>الرمادي</b></button>}
      </div>
      <button className="points num" onClick={() => nav('/app/bag')} aria-label="نقاطي">{fmt(p.data?.wallet.available)} نقطة</button>
      <button className="iconbtn" onClick={() => nav('/app/notifications')} aria-label="الإشعارات"><Icon name="bell" />{(n.data?.unread ?? 0) > 0 && <span className="dot" />}</button>
      <button className="iconbtn" onClick={() => nav('/app/profile')} aria-label="حسابي"><Icon name="user" /></button>
    </header>
  );
}

function BottomNav() {
  const tab = (to: string, icon: Parameters<typeof Icon>[0]['name'], label: string, end = false) => (
    <NavLink to={to} end={end}><Icon name={icon} /><span>{label}</span></NavLink>
  );
  return (
    <nav className="bottomnav" aria-label="التنقل">
      {tab('/app', 'home', 'الرئيسية', true)}
      {tab('/app/map', 'map', 'الخريطة')}
      <NavLink to="/app/scan" className="scan"><span className="fab"><Icon name="qr" /></span><em>امسح</em></NavLink>
      {tab('/app/missions', 'flag', 'المهام')}
      {tab('/app/bag', 'bag', 'الحقيبة')}
    </nav>
  );
}

export function UserApp() {
  return (
    <div className="app">
      <Suspense fallback={<Spinner />}>
      <Routes>
        <Route index element={<Home />} />
        <Route path="map" element={<MapPage />} />
        <Route path="spot/:id" element={<SpotPage />} />
        <Route path="hunt" element={<HuntPage />} />
        <Route path="scan" element={<ScanPage />} />
        <Route path="missions" element={<Missions />} />
        <Route path="bag" element={<Bag />} />
        <Route path="profile" element={<Profile />} />
        <Route path="history" element={<History />} />
        <Route path="notifications" element={<Notifications />} />
      </Routes>
      </Suspense>
      <BottomNav />
    </div>
  );
}
