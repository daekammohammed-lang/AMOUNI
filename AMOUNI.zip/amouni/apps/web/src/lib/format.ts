export const fmt = (n: number | null | undefined) => (n ?? 0).toLocaleString('en-US');
export const iqd = (n: number | null | undefined) => `${fmt(Math.round(n ?? 0))} د.ع`;

export function dist(m: number) {
  return m < 1000 ? `${Math.round(m / 10) * 10} م` : `${(m / 1000).toFixed(1)} كم`;
}

export function ago(iso: string | number) {
  const s = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 60) return 'هسه';
  if (s < 3600) return `قبل ${Math.round(s / 60)} د`;
  if (s < 86400) return `قبل ${Math.round(s / 3600)} س`;
  return `قبل ${Math.round(s / 86400)} يوم`;
}

export function left(iso: string | number, now = Date.now()) {
  const s = Math.max(0, Math.round((new Date(iso).getTime() - now) / 1000));
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(x).padStart(2, '0')}` : `${m}:${String(x).padStart(2, '0')}`;
}

export const dateAr = (iso: string) => new Date(iso).toLocaleDateString('ar-IQ-u-nu-latn', { day: 'numeric', month: 'short' });
export const timeAr = (iso: string) => new Date(iso).toLocaleTimeString('ar-IQ-u-nu-latn', { hour: 'numeric', minute: '2-digit' });

export const CAMPAIGN_STATUS_AR: Record<string, [string, string]> = {
  draft: ['مسودة', ''], pending_approval: ['بانتظار موافقة AMOUNI', 'amber'], scheduled: ['مجدولة', 'primary'], running: ['شغّالة', 'ok'],
  paused: ['متوقفة', 'amber'], completed: ['خلصت', 'primary'], cancelled: ['ملغاة', 'warn'], rejected: ['مرفوضة', 'warn'],
};
export const AUDIENCE_AR: Record<string, string> = { new: 'زبائن جدد', lapsed: 'الغايبين', all: 'الكل' };

export const CATEGORY_AR: Record<string, string> = {
  coffee: 'قهوة', food: 'مطاعم', sweets: 'حلويات', juice: 'عصائر', mall: 'مولات', fitness: 'رياضة',
  beauty: 'تجميل', fun: 'ألعاب', books: 'كتب', retail: 'تسوّق', services: 'خدمات',
};

export function reasonText(r: { code: string; meters?: number; category?: string; points?: number }) {
  switch (r.code) {
    case 'near': return (r.meters ?? 0) < 40 ? 'لأنك يمّه هسه' : `لأنه قريب منك (${dist(r.meters ?? 0)})`;
    case 'hot': return 'لأن عليه نقاط إضافية هسه';
    case 'new_category': return `لأنك ما جربت ${CATEGORY_AR[r.category ?? ''] ?? 'هالنوع'} بعد`;
    case 'you_like': return `لأنك تحب ${CATEGORY_AR[r.category ?? ''] ?? 'هالمكان'}`;
    default: return `لأن عليه ${fmt(r.points)} نقطة`;
  }
}

/** Accepts 07XXXXXXXXX / 7XXXXXXXXX / +9647… and returns E.164 (+9647XXXXXXXXX) or null. */
export function iraqPhone(input: string): string | null {
  const d = input.replace(/\D/g, '');
  const local = d.startsWith('964') ? d.slice(3) : d.startsWith('0') ? d.slice(1) : d;
  return /^7\d{9}$/.test(local) ? '+964' + local : null;
}
