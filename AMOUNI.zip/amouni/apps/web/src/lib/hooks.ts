import { useEffect, useRef, useState } from 'react';

// ---------- location ----------
export type Fix = { lat: number; lng: number; accuracy: number; at: number; approximate?: boolean };
export const CITY_CENTER: Fix = { lat: 33.4262, lng: 43.3001, accuracy: 3000, at: 0, approximate: true };   // Ramadi

/** Live position while the screen is open. Falls back to the city centre (marked approximate). */
export function useGeo(watch = true) {
  const [fix, setFix] = useState<Fix | null>(null);
  const [denied, setDenied] = useState(false);
  useEffect(() => {
    if (!watch || !('geolocation' in navigator)) { setFix(CITY_CENTER); return; }
    const id = navigator.geolocation.watchPosition(
      (p) => setFix({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, at: Date.now() }),
      (e) => { if (e.code === e.PERMISSION_DENIED) setDenied(true); setFix((f) => f ?? CITY_CENTER); },
      { enableHighAccuracy: true, maximumAge: 10_000, timeout: 15_000 },
    );
    return () => navigator.geolocation.clearWatch(id);
  }, [watch]);
  return { fix: fix ?? CITY_CENTER, ready: fix !== null, denied };
}

/** One fresh, high-accuracy fix (used at the moment of scanning). */
export function currentFix(): Promise<Fix | null> {
  return new Promise((resolve) => {
    if (!('geolocation' in navigator)) return resolve(null);
    navigator.geolocation.getCurrentPosition(
      (p) => resolve({ lat: p.coords.latitude, lng: p.coords.longitude, accuracy: p.coords.accuracy, at: Date.now() }),
      () => resolve(null), { enableHighAccuracy: true, maximumAge: 5_000, timeout: 12_000 });
  });
}

export function distanceM(a: { lat: number; lng: number }, b: { lat: number; lng: number }) {
  const R = 6371e3, r = (d: number) => (d * Math.PI) / 180;
  const x = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lng - a.lng) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(x));
}

// ---------- device & idempotency ----------
/** Stable per-install identifier (the server stores only a peppered hash of it). */
export function deviceFingerprint(): string {
  const k = 'amouni-device';
  try {
    let v = localStorage.getItem(k);
    if (!v) { v = 'web-' + crypto.randomUUID(); localStorage.setItem(k, v); }
    return v;
  } catch { return 'web-ephemeral-' + navigator.userAgent.length; }
}
export const newKey = () => crypto.randomUUID().replace(/-/g, '');

// ---------- time ----------
export function useNow(ms = 1000) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), ms); return () => clearInterval(t); }, [ms]);
  return now;
}
export function useInterval(fn: () => void, ms: number | null) {
  const ref = useRef(fn); ref.current = fn;
  useEffect(() => { if (ms === null) return; const t = setInterval(() => ref.current(), ms); return () => clearInterval(t); }, [ms]);
}

// ---------- theme ----------
export function applyTheme(t?: 'light' | 'dark') {
  const v = t ?? ((() => { try { return localStorage.getItem('amouni-theme'); } catch { return null; } })() as 'light' | 'dark' | null)
    ?? (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.documentElement.dataset.theme = v;
  try { if (t) localStorage.setItem('amouni-theme', t); } catch { /* private mode */ }
  return v;
}
