// The only way the app talks to AMOUNI's backend. Every business decision (points, trust,
// QR validity, rewards, permissions) is made server-side; this module just carries requests.
import { createClient } from '@supabase/supabase-js';
import { message as codeMessage } from '@codes';

const url = import.meta.env.VITE_SUPABASE_URL || window.location.origin;
const anonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(url, anonKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false, storageKey: 'amouni-auth' },
});

export class ApiError extends Error {
  constructor(public code: string, message: string) { super(message); }
}

const extraMessages: Record<string, string> = {
  INSUFFICIENT_POINTS: 'نقاطك ما تكفي', OUT_OF_STOCK: 'خلصت الكمية', NOT_COMPLETE: 'المهمة بعدها ما كملت',
  ALREADY_CLAIMED: 'استلمت جائزة هالمهمة', CODE_INVALID: 'الكود غلط أو انتهى', CODE_USED: 'هذا الكود استُخدم',
  ALREADY_REDEEMED: 'هاي الجائزة مستبدلة', NOT_AVAILABLE: 'هاي الجائزة مو متاحة', WRONG_BRANCH: 'هاي الجائزة مو لهذا الفرع',
  CASHIER_MODE_OFF: 'شغّل وضع الكاشير لهذا الفرع أولاً', BAD_NAME: 'اكتب اسم صحيح', BAD_INVITE: 'كود الدعوة غلط',
  TOO_MANY: 'وصلت للحد المسموح', REASON_REQUIRED: 'اكتب السبب', NOT_PENDING: 'هذا الطلب مو بانتظار قرار',
  HUNT_NOT_ACTIVE: 'اللقطة منتهية', NOT_FOUND: 'ما لكينا الطلب', MERCHANT_NOT_ACTIVE: 'المحل بعده ينتظر الموافقة',
  NOT_EDITABLE: 'ما يصير تعديل هالحملة هسه', BAD_BRANCH: 'الفرع مو صحيح', QR_DISABLED: 'هذا الباركود متوقف',
};

export function errorText(code: string): string {
  return extraMessages[code] ?? codeMessage(code);
}

function toApiError(e: { message?: string; code?: string } | null): ApiError {
  const m = e?.message ?? '';
  const code = m.match(/AMOUNI:([A-Z_]+)/)?.[1] ?? (e?.code === 'PGRST301' ? 'UNAUTHENTICATED' : m.includes('permission denied') ? 'FORBIDDEN' : 'INTERNAL');
  return new ApiError(code, errorText(code));
}

/** Calls a database RPC (PostgREST). Arguments are passed without the p_ prefix. */
export async function rpc<T = unknown>(fn: string, args: Record<string, unknown> = {}): Promise<T> {
  const params = Object.fromEntries(Object.entries(args).map(([k, v]) => ['p_' + k, v]));
  const { data, error } = await supabase.rpc(fn, params);
  if (error) throw toApiError(error);
  return data as T;
}

export type ScanResponse = {
  code: string; message: string; decision?: string; scan_id?: string; points?: number;
  lines?: QuoteLine[]; reward?: { title_ar: string } | null; rank?: number | null;
  spot?: { id: string; title_ar: string; kind: string }; step_up_until?: string | null; params?: Record<string, unknown>;
};

/** Calls an edge function (scan / step-up). Business outcomes come back as 200 with a result code. */
export async function edge<T = ScanResponse>(name: string, body: unknown, idempotencyKey?: string): Promise<T> {
  const { data: s } = await supabase.auth.getSession();
  const res = await fetch(`${url}/functions/v1/${name}`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json', apikey: anonKey, 'accept-language': 'ar',
      ...(s.session ? { authorization: `Bearer ${s.session.access_token}` } : {}),
      ...(idempotencyKey ? { 'idempotency-key': idempotencyKey } : {}),
    },
    body: JSON.stringify(body),
  }).catch(() => null);
  if (!res) throw new ApiError('OFFLINE', 'ما أكو اتصال. جرّب مرة ثانية');
  const json = await res.json().catch(() => ({ code: 'INTERNAL' }));
  if (res.status >= 400 && res.status !== 429) throw new ApiError(json.code ?? 'INTERNAL', json.message ?? errorText(json.code ?? 'INTERNAL'));
  return json as T;
}

// ---------- shared domain types ----------
export type QuoteLine = { kind: string; label_ar: string; points: number };
export type SpotCard = {
  spot_id: string; kind: 'normal' | 'golden_drop' | 'first_finder' | 'mystery'; title_ar: string; merchant: string | null;
  branch: string | null; category: string | null; lat: number; lng: number; circle_m: number | null;
  distance_m: number; walk_min: number; points: number; lines: QuoteLine[]; later: { kind: string; points: number; from?: string; to?: string }[];
  hot: boolean; qty_left: number | null; qty_total: number | null; ends_at: string | null; busy: boolean;
  reason: { code: string; meters?: number; category?: string; points?: number };
  reward_ar?: string | null; hours?: Record<string, string[][]>; quote_lock_minutes?: number;
};
export type Roles = {
  user_id: string; status: string; profile_complete: boolean; display_name: string | null; city_id: string | null;
  platform_roles: string[]; merchants: { merchant_id: string; name: string; status: string; role: string; branch_id: string | null; active: boolean }[];
};
export type ActiveHunt = { hunt_id: string; spot_id: string; expires_at: string; arrived_at: string | null; quote: { total: number; lines: QuoteLine[] };
  title_ar: string; kind: string; merchant: string | null; lat: number; lng: number; circle_m: number | null };
