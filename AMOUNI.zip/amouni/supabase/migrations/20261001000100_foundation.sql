-- =====================================================================
-- AMOUNI · 0001 · Foundation
-- Extensions, schemas, configuration, access helpers.
--
-- Security model (read docs/ARCHITECTURE.md §Security):
--   * Tables are locked. Clients never write tables directly.
--   * Every state change goes through a SECURITY DEFINER function that
--     validates the caller, runs in one transaction and writes the audit log.
--   * Secrets (QR token hashes, dynamic-QR keys, redeem codes, trust weights)
--     live in schema `private`, which is not exposed by the API.
-- =====================================================================

create extension if not exists pgcrypto with schema extensions;
create extension if not exists postgis  with schema extensions;
create extension if not exists citext   with schema extensions;

create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
grant usage on schema private to service_role;

-- ---------------------------------------------------------------------
-- Configuration: every economic or security number lives here, never
-- hard-coded in functions. Changes are audited (see 0005).
-- ---------------------------------------------------------------------
create table private.config (
  key         text primary key,
  value       jsonb not null,
  description text not null,
  updated_at  timestamptz not null default now()
);

insert into private.config (key, value, description) values
  ('points.max_per_scan',            '500',  'Hard cap of points for one scan (Drops may exceed only via spot.cap_points set by admin).'),
  ('points.daily_cap',               '1500', 'Max points a user can earn per city-local day from scans.'),
  ('points.discovery_bonus',         '100',  'Bonus for a user''s first ever verified visit to a merchant (funded by AMOUNI marketing).'),
  ('points.iqd_per_point',           '10',   'Internal value of one point in IQD. Used for pricing and coverage only, never shown to users.'),
  ('points.coverage_min',            '1.2',  'Min ratio of redeemable store value to outstanding user points. Below it: alert + boosts reduced.'),
  ('hunt.quote_lock_minutes',        '45',   'How long a quoted points value is honoured after start_hunt.'),
  ('hunt.max_city_speed_kmh',        '70',   'Fastest plausible in-city travel speed used for arrival plausibility.'),
  ('scan.place_cooldown_days',       '7',    'Same user can earn at the same branch at most once per N days.'),
  ('scan.geofence_multiplier',       '2',    'Scans beyond geofence × this (+ accuracy margin) are TOO_FAR.'),
  ('scan.accuracy_margin_max_m',     '100',  'Max GPS accuracy added to the allowed distance.'),
  ('scan.rate_per_minute',           '10',   'Max scan attempts per user per minute.'),
  ('scan.step_up_minutes',           '10',   'Time a user has to complete a step-up verification.'),
  ('scan.hold_release_hours',        '24',   'Held points auto-release after this many hours without new signals.'),
  ('qr.dynamic_window_seconds',      '30',   'Rotation period of the cashier-screen QR.'),
  ('qr.dynamic_accept_windows',      '2',    'Accepted windows for dynamic QR: current + previous.'),
  ('qr.grace_hours',                 '24',   'A rotated static QR stays valid this long unless rotated for a leak.'),
  ('qr.leak_far_km',                 '1',    'Scans of one QR from farther than this count toward leak detection.'),
  ('qr.leak_threshold',              '3',    'Distinct far users within an hour that auto-disable a QR.'),
  ('trust.valid_min',                '71',   'Trust >= this → valid (instant).'),
  ('trust.step_up_min',              '41',   'Trust in [this, valid_min) → step-up (or held when no cashier screen).'),
  ('trust.review_min',               '21',   'Trust in [this, step_up_min) → manual review. Below → rejected.'),
  ('visit.generated_view_hours',     '24',   'A visit counts as Generated only if the user started a hunt within this window.'),
  ('visit.new_customer_days',        '60',   'No verified visit at the merchant in this many days → new customer.'),
  ('redeem.token_seconds',           '60',   'Lifetime of a user redemption code / QR.'),
  ('redeem.reverse_hours',           '24',   'Admin can reverse a wrong redemption within this window.'),
  ('xp.per_visit',                   '60',   'XP granted per verified visit (progress only, never money).'),
  ('discover.radius_km',             '25',   'Default discovery radius.'),
  ('discover.busy_ratio',            '0.8',  'Visits in last hour / capacity above which a place is ranked lower.')
on conflict (key) do nothing;

create or replace function private.cfg(p_key text) returns jsonb
language sql stable security definer set search_path = '' as $$
  select value from private.config where key = p_key
$$;
create or replace function private.cfg_int(p_key text) returns int
language sql stable security definer set search_path = '' as $$
  select (value #>> '{}')::int from private.config where key = p_key
$$;
create or replace function private.cfg_num(p_key text) returns numeric
language sql stable security definer set search_path = '' as $$
  select (value #>> '{}')::numeric from private.config where key = p_key
$$;

-- ---------------------------------------------------------------------
-- Errors: functions raise `AMOUNI:<CODE>` so the API layer can map them
-- to stable result codes and localized messages.
-- ---------------------------------------------------------------------
create or replace function private.fail(p_code text, p_detail text default null) returns void
language plpgsql as $$
begin
  raise exception using errcode = 'P0001', message = 'AMOUNI:' || p_code, detail = coalesce(p_detail, '');
end $$;

-- Random identifiers that are safe to print (base62, no ambiguity issues for URLs).
create or replace function private.random_base62(p_len int) returns text
language plpgsql volatile set search_path = '' as $$
declare
  alphabet constant text := '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  bytes bytea;
  b int;
  out text := '';
begin
  -- Rejection sampling (bytes >= 248 are discarded) keeps every character equally likely.
  while length(out) < p_len loop
    bytes := extensions.gen_random_bytes(32);
    for i in 0 .. 31 loop
      b := get_byte(bytes, i);
      if b < 248 and length(out) < p_len then out := out || substr(alphabet, (b % 62) + 1, 1); end if;
    end loop;
  end loop;
  return out;
end $$;

-- Short code printed under a QR: AM-XXXX-XX without look-alike characters.
create or replace function private.random_short_code() returns text
language plpgsql volatile set search_path = '' as $$
declare
  alphabet constant text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  bytes bytea := extensions.gen_random_bytes(6);
  s text := '';
begin
  for i in 0 .. 5 loop s := s || substr(alphabet, (get_byte(bytes, i) % 32) + 1, 1); end loop;
  return 'AM-' || substr(s, 1, 4) || '-' || substr(s, 5, 2);
end $$;

create or replace function private.sha256(p text) returns bytea
language sql immutable set search_path = '' as $$
  select extensions.digest(convert_to(p, 'UTF8'), 'sha256')
$$;

-- ---------------------------------------------------------------------
-- Server secrets. On Supabase move these into Vault (vault.secrets) and
-- read them through private.secret(); never expose them to clients.
-- ---------------------------------------------------------------------
create table private.app_secrets (
  name  text primary key,
  value bytea not null,
  created_at timestamptz not null default now()
);
insert into private.app_secrets (name, value) values
  ('qr_master', extensions.gen_random_bytes(32)),
  ('device_pepper', extensions.gen_random_bytes(32))
on conflict (name) do nothing;

create or replace function private.secret(p_name text) returns bytea
language sql stable security definer set search_path = '' as $$
  select value from private.app_secrets where name = p_name
$$;

-- URL-safe base64 without padding.
create or replace function private.b64url(p bytea) returns text
language sql immutable set search_path = '' as $$
  select rtrim(translate(encode(p, 'base64'), E'+/\n', '-_'), '=')
$$;
