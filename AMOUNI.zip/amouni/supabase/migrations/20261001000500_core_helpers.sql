-- =====================================================================
-- AMOUNI · 0005 · Core helpers: time, opening hours, quotes, devices,
-- rate limits, signup.
-- =====================================================================

alter table public.scans add column response jsonb;

-- ---------- time ----------
create or replace function private.city_tz(p_branch uuid) returns text
language sql stable security definer set search_path = '' as $$
  select c.timezone from public.branches b join public.cities c on c.id = b.city_id where b.id = p_branch
$$;

-- Start of the city-local day / Saturday-based week, as timestamptz.
create or replace function private.local_day_start(p_tz text, p_at timestamptz default now()) returns timestamptz
language sql stable set search_path = '' as $$
  select (date_trunc('day', p_at at time zone p_tz)) at time zone p_tz
$$;
create or replace function private.local_week_start(p_tz text, p_at timestamptz default now()) returns timestamptz
language sql stable set search_path = '' as $$
  -- Iraq's week runs Saturday → Friday.
  select (date_trunc('day', p_at at time zone p_tz) - make_interval(days => ((extract(dow from p_at at time zone p_tz)::int + 1) % 7)))
         at time zone p_tz
$$;

-- hours: {"0":[["09:00","24:00"]], "5":[["14:00","02:00"]]}  (0 = Sunday, city-local)
-- Empty object = always open. Overnight ranges spill into the next day.
create or replace function private.in_hours(p_hours jsonb, p_tz text, p_at timestamptz default now()) returns boolean
language plpgsql stable set search_path = '' as $$
declare
  loc timestamp := p_at at time zone p_tz;
  t time := loc::time;
  dow int := extract(dow from loc)::int;
  prev int := (dow + 6) % 7;
  r jsonb; f time; e time; e_txt text;
begin
  if p_hours is null or p_hours = '{}'::jsonb then return true; end if;
  for r in select * from jsonb_array_elements(coalesce(p_hours -> dow::text, '[]'::jsonb)) loop
    f := (r ->> 0)::time; e_txt := r ->> 1;
    e := case when e_txt = '24:00' then time '23:59:59.999' else e_txt::time end;
    if f <= e and t between f and e then return true; end if;
    if f > e and t >= f then return true; end if;            -- overnight, before midnight
  end loop;
  for r in select * from jsonb_array_elements(coalesce(p_hours -> prev::text, '[]'::jsonb)) loop
    f := (r ->> 0)::time; e_txt := r ->> 1;
    if e_txt <> '24:00' then
      e := e_txt::time;
      if f > e and t < e then return true; end if;          -- overnight, after midnight
    end if;
  end loop;
  return false;
end $$;

-- Is this spot live and open right now?
create or replace function private.spot_open(p_spot uuid, p_at timestamptz default now()) returns boolean
language sql stable security definer set search_path = '' as $$
  select coalesce((
    select s.status = 'live' and s.starts_at <= p_at and (s.ends_at is null or s.ends_at > p_at)
       and b.status = 'active' and m.status = 'active'
       and private.in_hours(coalesce(s.hours_override, b.hours), c.timezone, p_at)
    from public.spots s
    join public.branches b on b.id = s.branch_id
    join public.merchants m on m.id = b.merchant_id
    join public.cities c on c.id = b.city_id
    where s.id = p_spot), false)
$$;

-- ---------- quotes ----------
-- Returns {"total":int,"lines":[{"kind","label_ar","points","wallet"}],"hot":bool,"later":[...]}.
-- Points = min(base + active boosts + discovery, cap). The quote never exceeds caps from private.config.
create or replace function private.compute_quote(p_user uuid, p_spot uuid, p_at timestamptz default now()) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  s record; b record;
  mkt uuid := private.wallet('amouni_marketing');
  lines jsonb := '[]'::jsonb; later jsonb := '[]'::jsonb;
  total int := 0; cap int; hot boolean := false;
  is_new_customer boolean; is_first_ever boolean;
  tz text; amt int; keep jsonb := '[]'::jsonb; ln jsonb; run int := 0;
begin
  select sp.*, br.merchant_id, c.timezone into s
  from public.spots sp join public.branches br on br.id = sp.branch_id join public.cities c on c.id = br.city_id
  where sp.id = p_spot;
  if s.id is null then perform private.fail('SPOT_NOT_FOUND'); end if;
  tz := s.timezone;

  is_first_ever := not exists (select 1 from public.visits v where v.user_id = p_user and v.merchant_id = s.merchant_id);
  is_new_customer := not exists (select 1 from public.visits v where v.user_id = p_user and v.merchant_id = s.merchant_id
                                 and v.verified_at > p_at - make_interval(days => private.cfg_int('visit.new_customer_days')));

  lines := lines || jsonb_build_object('kind','base','label_ar','الأساس','points', s.base_points,'wallet', mkt);

  for b in select * from public.boosts
           where spot_id = p_spot and active and starts_at <= p_at and (ends_at is null or ends_at > p_at)
           order by created_at loop
    if b.kind = 'time' then
      if private.in_hours(jsonb_build_object(
            ((extract(dow from p_at at time zone tz))::int)::text,
            jsonb_build_array(jsonb_build_array(b.rule ->> 'from', b.rule ->> 'to'))), tz, p_at)
         and (b.rule -> 'days' is null or (b.rule -> 'days') @> to_jsonb(extract(dow from p_at at time zone tz)::int)) then
        lines := lines || jsonb_build_object('kind','time','label_ar','وقت هادئ','points', b.amount,'wallet', coalesce(b.wallet_id, mkt));
        hot := true;
      else
        later := later || jsonb_build_object('kind','time','points', b.amount,'from', b.rule ->> 'from','to', b.rule ->> 'to');
      end if;
    elsif b.kind = 'new_customer' then
      if is_new_customer then
        lines := lines || jsonb_build_object('kind','new_customer','label_ar','زبون جديد للمحل','points', b.amount,'wallet', coalesce(b.wallet_id, mkt));
      end if;
    elsif b.kind = 'campaign' and (
            -- schedule: optional days + hours window (city-local)
            (b.rule -> 'days' is not null and not ((b.rule -> 'days') @> to_jsonb(extract(dow from p_at at time zone tz)::int)))
         or (b.rule ->> 'from' is not null and not private.in_hours(jsonb_build_object(
               ((extract(dow from p_at at time zone tz))::int)::text,
               jsonb_build_array(jsonb_build_array(b.rule ->> 'from', b.rule ->> 'to'))), tz, p_at))
            -- audience: new customers only / lapsed customers only
         or (b.rule ->> 'audience' = 'new' and not is_new_customer)
         or (b.rule ->> 'audience' = 'lapsed' and (is_first_ever or exists (select 1 from public.visits v where v.user_id = p_user
               and v.merchant_id = s.merchant_id and v.verified_at > p_at - interval '30 days')))) then
      later := later || jsonb_build_object('kind','campaign','points', b.amount,'from', b.rule ->> 'from','to', b.rule ->> 'to');
    elsif b.kind in ('campaign','quiet_place','new_location') then
      lines := lines || jsonb_build_object('kind', b.kind,
        'label_ar', case b.kind when 'campaign' then 'عرض المحل' when 'quiet_place' then 'مكان هادئ هسه' else 'مكان جديد على AMOUNI' end,
        'points', b.amount, 'wallet', coalesce(b.wallet_id, mkt));
      hot := true;
    end if;
  end loop;

  if is_first_ever then
    lines := lines || jsonb_build_object('kind','discovery','label_ar','اكتشاف أول لهذا المكان',
                                         'points', private.cfg_int('points.discovery_bonus'),'wallet', mkt);
  end if;

  cap := case when s.kind in ('golden_drop','first_finder') then s.cap_points
              else least(s.cap_points, private.cfg_int('points.max_per_scan')) end;

  -- Trim from the end so the itemised lines always add up to the total shown to the user.
  for ln in select * from jsonb_array_elements(lines) loop
    amt := least((ln ->> 'points')::int, cap - run);
    if amt > 0 then
      keep := keep || jsonb_set(ln, '{points}', to_jsonb(amt));
      run := run + amt;
    end if;
  end loop;

  return jsonb_build_object('total', run, 'lines', keep, 'hot', hot, 'later', later,
                            'new_customer', is_new_customer, 'first_ever', is_first_ever);
end $$;

-- Quote lines as shown to clients (funding wallets are internal).
create or replace function private.public_lines(p_lines jsonb) returns jsonb
language sql immutable set search_path = '' as $$
  select coalesce(jsonb_agg(l - 'wallet'), '[]'::jsonb) from jsonb_array_elements(coalesce(p_lines, '[]'::jsonb)) l
$$;

-- Scale a quote down to p_points (e.g. daily cap), trimming from the end.
create or replace function private.trim_lines(p_lines jsonb, p_points int) returns jsonb
language plpgsql immutable set search_path = '' as $$
declare ln jsonb; keep jsonb := '[]'::jsonb; run int := 0; amt int;
begin
  for ln in select * from jsonb_array_elements(p_lines) loop
    amt := least((ln ->> 'points')::int, p_points - run);
    if amt > 0 then keep := keep || jsonb_set(ln, '{points}', to_jsonb(amt)); run := run + amt; end if;
  end loop;
  return keep;
end $$;

-- ---------- devices ----------
create or replace function private.device_id(p_user uuid, p_fingerprint text, p_platform text default 'web') returns uuid
language plpgsql security definer set search_path = '' as $$
declare h bytea; d uuid;
begin
  if p_fingerprint is null or length(p_fingerprint) < 8 then return null; end if;
  h := extensions.hmac(convert_to(p_fingerprint, 'UTF8'), private.secret('device_pepper'), 'sha256');
  insert into public.devices (user_id, fingerprint_hash, platform)
  values (p_user, h, coalesce(p_platform, 'web'))
  on conflict (user_id, fingerprint_hash) do update set last_seen = now()
  returning id into d;
  return d;
end $$;

-- ---------- rate limits ----------
create or replace function private.rate_ok(p_key text, p_limit int, p_window_seconds int default 60) returns boolean
language plpgsql security definer set search_path = '' as $$
declare w timestamptz := to_timestamp(floor(extract(epoch from now()) / p_window_seconds) * p_window_seconds); n int;
begin
  insert into private.rate_buckets (key, window_start, hits) values (p_key, w, 1)
  on conflict (key, window_start) do update set hits = private.rate_buckets.hits + 1
  returning hits into n;
  return n <= p_limit;
end $$;

-- ---------- QR token derivation ----------
create or replace function private.qr_token(p_qr uuid) returns text
language sql stable security definer set search_path = '' as $$
  select left(private.b64url(extensions.hmac(convert_to('qr:' || p_qr::text, 'UTF8'), private.secret('qr_master'), 'sha256')), 22)
$$;
create or replace function private.qr_url(p_qr uuid) returns text
language sql stable security definer set search_path = '' as $$
  select 'https://amouni.app/q/' || private.qr_token(p_qr)
$$;

-- Dynamic (cashier screen) token for a 30-second window.
create or replace function private.dynamic_token(p_branch uuid, p_window bigint) returns text
language sql stable security definer set search_path = '' as $$
  select left(private.b64url(extensions.hmac(convert_to('dyn:' || p_window::text, 'UTF8'),
              (select dynamic_secret from private.branch_secrets where branch_id = p_branch), 'sha256')), 16)
$$;
create or replace function private.dynamic_window(p_at timestamptz default now()) returns bigint
language sql stable set search_path = '' as $$
  select floor(extract(epoch from p_at) / private.cfg_int('qr.dynamic_window_seconds'))::bigint
$$;

-- ---------- signup ----------
-- Supabase calls this when a phone number verifies its first OTP.
create or replace function private.handle_new_user() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, phone) values (new.id, coalesce(new.phone, 'pending:' || new.id::text))
  on conflict (id) do nothing;
  perform private.wallet('user_available', new.id);
  perform private.wallet('user_held', new.id);
  return new;
end $$;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function private.handle_new_user();

create or replace function private.event(p_name text, p_user uuid, p_props jsonb default '{}'::jsonb) returns void
language sql security definer set search_path = '' as $$
  insert into public.events (name, user_id, props) values (p_name, p_user, coalesce(p_props, '{}'::jsonb))
$$;
