-- =====================================================================
-- AMOUNI · 0010 · Admin command center + scheduled jobs.
-- Every admin function checks a platform role and writes audit_log.
-- =====================================================================

create or replace function private.mask_phone(p text) returns text
language sql immutable set search_path = '' as $$
  select case when length(p) > 6 then left(p, 4) || repeat('•', length(p) - 7) || right(p, 3) else '•••' end
$$;

-- ---------- trust & fraud ----------
create or replace function public.admin_review_queue(p_limit int default 50) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['fraud_analyst','ops']);
  return coalesce((select jsonb_agg(row_to_json(x) order by x.created_at) from (
    select sc.id, sc.decision, sc.trust_score, sc.points, sc.created_at, sc.step_up_until,
           private.mask_phone(p.phone) as phone, p.display_name, p.created_at as account_created, p.account_trust,
           b.name as branch, m.display_name as merchant, round(sc.distance_m) as distance_m, sc.accuracy_m,
           (select jsonb_agg(jsonb_build_object('signal', s.signal, 'points', s.points, 'evidence', s.evidence)) from public.scan_signals s where s.scan_id = sc.id) as signals,
           (select count(*) from public.scans y where y.user_id = sc.user_id and y.decision = 'rejected') as user_rejections
    from public.scans sc join public.profiles p on p.id = sc.user_id
    left join public.branches b on b.id = sc.branch_id left join public.merchants m on m.id = b.merchant_id
    where sc.decision in ('held','review')
    order by sc.created_at limit p_limit) x), '[]'::jsonb);
end $$;

create or replace function public.admin_resolve_scan(p_scan uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare actor uuid := private.require_platform(array['fraud_analyst']);
begin
  if p_reason is null or length(btrim(p_reason)) < 3 then perform private.fail('REASON_REQUIRED'); end if;
  return private.resolve_scan(p_scan, p_approve, actor, p_reason);
end $$;

create or replace function public.admin_user_status(p_user uuid, p_status text, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare actor uuid := private.require_platform(array['fraud_analyst','ops']); old text;
begin
  if p_reason is null or length(btrim(p_reason)) < 3 then perform private.fail('REASON_REQUIRED'); end if;
  select status into old from public.profiles where id = p_user;
  update public.profiles set status = p_status where id = p_user;
  perform private.audit('user_status', 'profile', p_user::text, jsonb_build_object('status', old), jsonb_build_object('status', p_status), p_reason);
end $$;

-- ---------- points ----------
create or replace function public.admin_adjust_points(p_user uuid, p_amount int, p_reason text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare actor uuid := private.require_platform(array['finance']); t uuid;
begin
  if p_amount = 0 or abs(p_amount) > 100000 then perform private.fail('BAD_AMOUNT'); end if;
  if p_reason is null or length(btrim(p_reason)) < 3 then perform private.fail('REASON_REQUIRED'); end if;
  t := private.post_tx('adjust', 'admin_adjust', gen_random_uuid()::text,
    jsonb_build_array(jsonb_build_object('wallet', private.wallet('amouni_marketing'), 'amount', -p_amount),
                      jsonb_build_object('wallet', private.wallet('user_available', p_user), 'amount', p_amount)),
    actor, p_reason);
  perform private.audit('points_adjusted', 'profile', p_user::text, null, jsonb_build_object('amount', p_amount, 'tx', t), p_reason);
  return t;
end $$;

create or replace function public.admin_set_config(p_key text, p_value jsonb, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare old jsonb;
begin
  perform private.require_platform(array['super_admin']);
  select value into old from private.config where key = p_key;
  if old is null then perform private.fail('NOT_FOUND'); end if;
  update private.config set value = p_value, updated_at = now() where key = p_key;
  perform private.audit('config_changed', 'config', p_key, old, p_value, p_reason);
end $$;

-- ---------- merchants, rewards, spots ----------
create or replace function public.admin_merchant_decide(p_merchant uuid, p_approve boolean, p_reason text, p_plan text default 'basic') returns void
language plpgsql security definer set search_path = '' as $$
declare old text;
begin
  perform private.require_platform(array['ops']);
  select status into old from public.merchants where id = p_merchant;
  update public.merchants set status = case when p_approve then 'active' else 'rejected' end,
         plan = case when p_approve then p_plan else plan end,
         reject_reason = case when p_approve then null else p_reason end
  where id = p_merchant;
  perform private.audit(case when p_approve then 'merchant_approved' else 'merchant_rejected' end, 'merchant', p_merchant::text,
                        jsonb_build_object('status', old), jsonb_build_object('plan', p_plan), p_reason);
end $$;

create or replace function public.admin_reward_price(p_reward uuid, p_cost_points int, p_active boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare old jsonb;
begin
  perform private.require_platform(array['ops','finance']);
  select jsonb_build_object('cost_points', cost_points, 'active', active) into old from public.rewards where id = p_reward;
  update public.rewards set cost_points = p_cost_points, active = p_active where id = p_reward;
  perform private.audit('reward_priced', 'reward', p_reward::text, old, jsonb_build_object('cost_points', p_cost_points, 'active', p_active));
end $$;

create or replace function public.admin_spot_create(
  p_branch uuid, p_title text, p_kind text, p_base_points int, p_qty int default null,
  p_instant_reward uuid default null, p_requires_dynamic boolean default false,
  p_mystery_radius_m int default null, p_starts timestamptz default now(), p_ends timestamptz default null,
  p_cap_points int default 500
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare sid uuid; b record; ctr extensions.geography;
begin
  perform private.require_platform(array['ops']);
  select * into b from public.branches where id = p_branch;
  if p_kind = 'mystery' then
    -- Circle centre is offset randomly (up to 60 % of the radius) so the shop is not at its middle.
    ctr := extensions.st_project(b.location, p_mystery_radius_m * (0.2 + random() * 0.4), random() * 2 * pi());
  end if;
  insert into public.spots (branch_id, title_ar, kind, base_points, cap_points, instant_reward_id, qty_total, qty_left,
                            requires_dynamic, mystery_radius_m, mystery_center, status, starts_at, ends_at)
  values (p_branch, p_title, p_kind, p_base_points, p_cap_points, p_instant_reward, p_qty, p_qty, p_requires_dynamic,
          p_mystery_radius_m, ctr, 'live', p_starts, p_ends)
  returning id into sid;
  perform private.audit('spot_created', 'spot', sid::text, null,
    jsonb_build_object('branch', p_branch, 'kind', p_kind, 'base_points', p_base_points, 'qty', p_qty));
  return sid;
end $$;

create or replace function public.admin_reverse_redemption(p_redemption uuid, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare r record;
begin
  perform private.require_platform(array['ops']);
  select * into r from public.redemptions where id = p_redemption for update;
  if r.id is null or r.reversed_at is not null then perform private.fail('NOT_FOUND'); end if;
  if r.created_at < now() - make_interval(hours => private.cfg_int('redeem.reverse_hours')) then perform private.fail('TOO_LATE'); end if;
  update public.redemptions set reversed_at = now(), reversed_by = auth.uid(), reverse_reason = p_reason where id = p_redemption;
  update public.bag_items set status = 'available' where id = r.bag_item_id;
  perform private.audit('redemption_reversed', 'redemption', p_redemption::text, null, null, p_reason);
end $$;

-- ---------- economy & pulse ----------
create or replace function public.admin_economy() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare outstanding bigint; store bigint; ratio numeric;
begin
  perform private.require_platform(array['finance','ops']);
  select o.outstanding into outstanding from private.points_liability o;
  select coalesce(sum(cost_points::bigint * stock), 0) into store from public.rewards where active and cost_points is not null;
  ratio := case when outstanding > 0 then round(store::numeric / outstanding, 2) end;
  return jsonb_build_object(
    'outstanding_points', outstanding, 'store_value_points', store, 'coverage_ratio', ratio,
    'coverage_min', private.cfg_num('points.coverage_min'),
    'alert', ratio is not null and ratio < private.cfg_num('points.coverage_min'),
    'issued_today', (select coalesce(sum(e.amount), 0) from public.ledger_entries e join public.wallets w on w.id = e.wallet_id
                     where w.kind in ('user_available','user_held') and e.amount > 0 and e.created_at >= private.local_day_start('Asia/Baghdad')),
    'spent_today', (select coalesce(sum(e.amount), 0) from public.ledger_entries e join public.wallets w on w.id = e.wallet_id
                    where w.kind = 'store_sink' and e.created_at >= private.local_day_start('Asia/Baghdad')),
    'marketing_issued_total', -(select balance from public.wallets where kind = 'amouni_marketing'));
end $$;

create or replace function public.admin_city_pulse(p_city uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','fraud_analyst','finance']);
  return jsonb_build_object(
    'scans_last_hour', (select count(*) from public.scans sc join public.branches b on b.id = sc.branch_id where b.city_id = p_city and sc.created_at > now() - interval '1 hour'),
    'reject_rate_today', (select round(avg(case when sc.decision in ('rejected','gate_reject') then 1 else 0 end)::numeric, 3)
                          from public.scans sc join public.branches b on b.id = sc.branch_id where b.city_id = p_city and sc.created_at >= private.local_day_start('Asia/Baghdad')),
    'pending_review', (select count(*) from public.scans where decision in ('held','review')),
    'branches', coalesce((select jsonb_agg(x order by x.visits_24h desc) from (
        select b.id, b.name, m.display_name as merchant, b.capacity,
               (select count(*) from public.visits v where v.branch_id = b.id and v.verified_at > now() - interval '24 hours') visits_24h,
               (select count(*) from public.visits v where v.branch_id = b.id and v.verified_at > now() - interval '1 hour') visits_1h
        from public.branches b join public.merchants m on m.id = b.merchant_id where b.city_id = p_city and b.status = 'active') x), '[]'::jsonb));
end $$;

-- ---------- scheduled jobs (service role / pg_cron) ----------
create or replace function public.job_release_held() returns int
language plpgsql security definer set search_path = '' as $$
declare sc record; n int := 0;
begin
  for sc in select s.id from public.scans s
            where s.decision = 'held' and s.created_at < now() - make_interval(hours => private.cfg_int('scan.hold_release_hours'))
              and not exists (select 1 from public.scans y where y.user_id = s.user_id and y.created_at > s.created_at
                              and y.decision in ('review','rejected'))
            for update skip locked loop
    perform private.resolve_scan(sc.id, true, null, 'auto-release after hold window');
    n := n + 1;
  end loop;
  return n;
end $$;

create or replace function public.job_housekeeping() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare a int; b int; c int; d int; e int;
begin
  update public.hunts set status = 'expired' where status = 'active' and expires_at < now(); get diagnostics a = row_count;
  -- Step-up not completed in time → human review (skipping step-up must not be a path to points).
  update public.scans set decision = 'review', result_code = 'REVIEW' where decision = 'step_up' and step_up_until < now(); get diagnostics b = row_count;
  update public.bag_items set status = 'expired' where status in ('available','held') and expires_at < now(); get diagnostics c = row_count;
  update public.spots set status = 'ended' where status = 'live' and ends_at is not null and ends_at < now(); get diagnostics d = row_count;
  delete from public.location_pings where recorded_at < now() - interval '90 days'; get diagnostics e = row_count;
  delete from private.rate_buckets where window_start < now() - interval '1 day';
  delete from private.redeem_tokens where expires_at < now() - interval '1 day';
  return jsonb_build_object('hunts_expired', a, 'step_up_to_review', b, 'bag_expired', c, 'spots_ended', d, 'pings_purged', e);
end $$;

create or replace function public.job_rotate_qr() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare q record; rotated int := 0; ended int;
begin
  for q in select id from public.qr_codes where status = 'active' and next_rotation_at < now() for update skip locked loop
    perform private.rotate_qr(q.id, 'scheduled', null); rotated := rotated + 1;
  end loop;
  update public.qr_codes set status = 'disabled', disabled_reason = 'grace_ended' where status = 'grace' and grace_until < now();
  get diagnostics ended = row_count;
  return jsonb_build_object('rotated', rotated, 'grace_ended', ended);
end $$;

create or replace function public.job_campaigns() returns int
language plpgsql security definer set search_path = '' as $$
declare c record; n int := 0;
begin
  for c in select id from public.campaigns where status in ('running','paused') and ends_at < now() loop
    perform private.close_campaign(c.id, 'completed', 'ended'); n := n + 1;
  end loop;
  return n;
end $$;

-- Schedule jobs when pg_cron is available (enable it in Supabase → Database → Extensions).
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('amouni_release_held', '*/10 * * * *', 'select public.job_release_held()');
    perform cron.schedule('amouni_housekeeping', '* * * * *',    'select public.job_housekeeping()');
    perform cron.schedule('amouni_rotate_qr',    '*/15 * * * *', 'select public.job_rotate_qr()');
    perform cron.schedule('amouni_campaigns',    '*/5 * * * *',  'select public.job_campaigns()');
  end if;
end $$;
