-- =====================================================================
-- AMOUNI · 0013 · Read models for the apps (user, merchant, admin)
-- and the AI recommendation layer (AI proposes, rules decide).
-- =====================================================================

insert into private.config (key, value, description) values
  ('xp.levels', '[{"name_ar":"مبتدئ","min":0},{"name_ar":"مستكشف","min":200},{"name_ar":"لاقط","min":600},{"name_ar":"صياد","min":1500},{"name_ar":"أسطورة المدينة","min":4000}]',
   'XP thresholds for levels (progress only).'),
  ('ai.quiet_ratio',        '0.3',  'A branch is "quiet now" when this hour''s visits are below this share of its usual hourly visits.'),
  ('ai.max_quiet_boost',    '50',   'Largest quiet-place boost the AI may propose (points).'),
  ('ai.boost_hours',        '2',    'How long an applied AI quiet-place boost lasts.'),
  ('ai.daily_boost_points', '3000', 'Max total points of AI boosts that can be applied per city day.'),
  ('ai.auto_apply',         'false','Apply AI proposals automatically when they pass the rule check (otherwise ops approve).')
on conflict (key) do nothing;

-- ---------------------------------------------------------------------
-- Identity & routing
-- ---------------------------------------------------------------------
create or replace function public.my_roles() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(false); p record;
begin
  select * into p from public.profiles where id = uid;
  return jsonb_build_object(
    'user_id', uid, 'status', p.status, 'profile_complete', p.display_name is not null,
    'display_name', p.display_name, 'city_id', p.city_id,
    'platform_roles', coalesce((select jsonb_agg(role) from public.platform_roles where user_id = uid), '[]'::jsonb),
    'merchants', coalesce((select jsonb_agg(jsonb_build_object('merchant_id', m.id, 'name', m.display_name, 'status', m.status,
                    'role', mm.role, 'branch_id', mm.branch_id, 'active', mm.active) order by mm.added_at)
                  from public.merchant_members mm join public.merchants m on m.id = mm.merchant_id where mm.user_id = uid), '[]'::jsonb));
end $$;

create or replace function private.level_of(p_xp int) returns jsonb
language plpgsql stable security definer set search_path = '' as $$
declare lv jsonb := private.cfg('xp.levels'); i int; cur jsonb; nxt jsonb;
begin
  for i in 0 .. jsonb_array_length(lv) - 1 loop
    if p_xp >= (lv -> i ->> 'min')::int then cur := lv -> i; nxt := lv -> (i + 1); end if;
  end loop;
  return jsonb_build_object('name_ar', cur ->> 'name_ar', 'xp', p_xp, 'next_name_ar', nxt ->> 'name_ar', 'next_at', (nxt ->> 'min')::int,
    'pct', case when nxt is null then 100 else round(100.0 * (p_xp - (cur ->> 'min')::int) / ((nxt ->> 'min')::int - (cur ->> 'min')::int)) end);
end $$;

-- User segment from verified behaviour (used for personalisation and by the AI layer; never for money).
create or replace function private.user_segment(p_user uuid) returns text
language sql stable security definer set search_path = '' as $$
  with v as (select m.category, count(*) n from public.visits vi join public.merchants m on m.id = vi.merchant_id
             where vi.user_id = p_user group by m.category),
       t as (select coalesce(sum(n), 0) total, count(*) cats from v)
  select case
    when (select total from t) < 2 then 'new'
    when (select cats from t) >= 4 then 'explorer'
    when exists (select 1 from v where category in ('food','sweets','coffee','juice') and n >= (select total from t) * 0.6) then 'foodie'
    when (select count(*) from public.bag_items b where b.user_id = p_user and b.source = 'store') >= 3 then 'reward_hunter'
    else 'regular' end
$$;

create or replace function public.my_profile() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(false); p record; days int := 0; d date; week jsonb := '[]'::jsonb; ws date; i int; vd date[];
begin
  select * into p from public.profiles where id = uid;
  select array_agg(distinct (verified_at at time zone 'Asia/Baghdad')::date) into vd from public.visits where user_id = uid;
  d := (now() at time zone 'Asia/Baghdad')::date;
  if not (d = any(coalesce(vd, '{}'))) then d := d - 1; end if;
  while d = any(coalesce(vd, '{}')) loop days := days + 1; d := d - 1; end loop;
  ws := (private.local_week_start('Asia/Baghdad') at time zone 'Asia/Baghdad')::date;
  for i in 0 .. 6 loop week := week || to_jsonb((ws + i) = any(coalesce(vd, '{}'))); end loop;
  return jsonb_build_object(
    'id', uid, 'display_name', p.display_name, 'phone', p.phone, 'city_id', p.city_id, 'status', p.status, 'joined', p.created_at,
    'invite_code', p.invite_code, 'level', private.level_of(p.xp), 'segment', private.user_segment(uid),
    'wallet', jsonb_build_object(
      'available', (select balance from public.wallets where kind = 'user_available' and owner_id = uid),
      'held', (select balance from public.wallets where kind = 'user_held' and owner_id = uid)),
    'streak', jsonb_build_object('days', days, 'week', week),
    'stats', jsonb_build_object(
      'visits', (select count(*) from public.visits where user_id = uid),
      'places', (select count(distinct branch_id) from public.visits where user_id = uid),
      'redeemed', (select count(*) from public.bag_items where user_id = uid and status = 'redeemed'),
      'invited', (select count(*) from public.profiles where invited_by = uid)));
end $$;

-- ---------------------------------------------------------------------
-- User read models
-- ---------------------------------------------------------------------
create or replace function public.my_bag() returns jsonb
language sql security definer set search_path = '' as $$
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', b.id, 'status', b.status, 'source', b.source, 'expires_at', b.expires_at, 'created_at', b.created_at,
      'title_ar', r.title_ar, 'terms_ar', r.terms_ar, 'merchant', m.display_name, 'category', m.category)
    order by (b.status = 'available') desc, (b.status = 'held') desc, b.expires_at), '[]'::jsonb)
  from public.bag_items b join public.rewards r on r.id = b.reward_id join public.merchants m on m.id = r.merchant_id
  where b.user_id = private.require_user(false) and b.created_at > now() - interval '120 days'
$$;

create or replace function public.store_list(p_lat float8 default null, p_lng float8 default null) returns jsonb
language sql security definer set search_path = '' as $$
  select coalesce(jsonb_agg(x order by x.cost), '[]'::jsonb) from (
    select r.id, r.title_ar, r.description_ar, r.cost_points as cost, r.stock, r.validity_days, r.terms_ar,
           m.display_name as merchant, m.category,
           (select round(min(extensions.st_distance(b.location, extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography)))
              from public.branches b where b.merchant_id = m.id and b.status = 'active' and p_lat is not null) as distance_m
    from public.rewards r join public.merchants m on m.id = r.merchant_id
    where r.active and r.cost_points is not null and r.stock > 0 and m.status = 'active') x
$$;

create or replace function public.my_scans(p_limit int default 30) returns jsonb
language sql security definer set search_path = '' as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', s.id, 'code', s.result_code, 'decision', s.decision, 'points', s.points,
      'created_at', s.created_at, 'spot', sp.title_ar, 'merchant', m.display_name) order by s.created_at desc), '[]'::jsonb)
  from (select * from public.scans where user_id = private.require_user(false) order by created_at desc limit least(p_limit, 100)) s
  left join public.spots sp on sp.id = s.spot_id left join public.branches b on b.id = s.branch_id left join public.merchants m on m.id = b.merchant_id
$$;

create or replace function public.my_notifications(p_limit int default 30) returns jsonb
language sql security definer set search_path = '' as $$
  select jsonb_build_object(
    'unread', (select count(*) from public.notifications where user_id = private.require_user(false) and opened_at is null),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'kind', kind, 'payload', payload, 'at', scheduled_for, 'read', opened_at is not null)
                       order by scheduled_for desc)
                       from (select * from public.notifications where user_id = private.require_user(false) order by scheduled_for desc limit least(p_limit, 100)) n), '[]'::jsonb))
$$;

create or replace function public.notification_read(p_id uuid default null) returns void
language sql security definer set search_path = '' as $$
  update public.notifications set opened_at = now()
  where user_id = private.require_user(false) and opened_at is null and (p_id is null or id = p_id)
$$;

-- Active hunt (to resume after closing the app).
create or replace function public.my_active_hunt() returns jsonb
language sql security definer set search_path = '' as $$
  select jsonb_build_object('hunt_id', h.id, 'spot_id', h.spot_id, 'expires_at', h.expires_at, 'arrived_at', h.arrived_at,
                            'quote', jsonb_build_object('total', q.total, 'lines', private.public_lines(q.lines)),
                            'title_ar', case when s.kind = 'mystery' then 'فرصة مخفية' else s.title_ar end, 'kind', s.kind,
                            'merchant', case when s.kind = 'mystery' then null else m.display_name end,
                            'lat', extensions.st_y(coalesce(s.mystery_center, b.location)::extensions.geometry),
                            'lng', extensions.st_x(coalesce(s.mystery_center, b.location)::extensions.geometry),
                            'circle_m', s.mystery_radius_m)
  from public.hunts h join public.point_quotes q on q.id = h.quote_id join public.spots s on s.id = h.spot_id
  join public.branches b on b.id = s.branch_id join public.merchants m on m.id = b.merchant_id
  where h.user_id = private.require_user(false) and h.status = 'active' and h.expires_at > now()
  order by h.started_at desc limit 1
$$;

create or replace function public.cancel_hunt(p_hunt_id uuid) returns void
language sql security definer set search_path = '' as $$
  update public.hunts set status = 'cancelled' where id = p_hunt_id and user_id = private.require_user(false) and status = 'active'
$$;

-- ---------------------------------------------------------------------
-- Merchant read models
-- ---------------------------------------------------------------------
create or replace function private.require_any_member(p_merchant uuid) returns text
language plpgsql stable security definer set search_path = '' as $$
declare r text;
begin
  select role into r from public.merchant_members where merchant_id = p_merchant and user_id = auth.uid() and active;
  if r is null then perform private.fail('FORBIDDEN'); end if;
  return r;
end $$;

create or replace function public.merchant_home(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare r text := private.require_any_member(p_merchant); scope uuid; m record;
begin
  select branch_id into scope from public.merchant_members where merchant_id = p_merchant and user_id = auth.uid();
  select * into m from public.merchants where id = p_merchant;
  return jsonb_build_object(
    'merchant', jsonb_build_object('id', m.id, 'name', m.display_name, 'category', m.category, 'status', m.status,
                                   'plan', m.plan, 'reject_reason', m.reject_reason, 'created_at', m.created_at),
    'role', r, 'branch_scope', scope,
    'settings', case when r in ('owner','manager') and scope is null then
       (select jsonb_build_object('avg_ticket_iqd', avg_ticket_iqd, 'cpv_iqd', cpv_iqd) from public.merchant_settings where merchant_id = p_merchant) end,
    'branches', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name, 'address', b.address, 'status', b.status,
        'lat', extensions.st_y(b.location::extensions.geometry), 'lng', extensions.st_x(b.location::extensions.geometry),
        'geofence_m', b.geofence_m, 'cashier_mode', b.cashier_mode, 'capacity', b.capacity, 'hint_ar', b.hint_ar, 'hours', b.hours,
        'live_spots', (select count(*) from public.spots s where s.branch_id = b.id and s.status = 'live'),
        'qr_active', (select count(*) from public.qr_codes q where q.branch_id = b.id and q.status = 'active')) order by b.created_at)
      from public.branches b where b.merchant_id = p_merchant and (scope is null or b.id = scope)), '[]'::jsonb));
end $$;

create or replace function public.merchant_qr_list(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', q.id, 'branch_id', q.branch_id, 'branch', b.name, 'label', q.label,
      'status', q.status, 'short_code', q.short_code::text, 'rotation', q.rotation, 'scans', q.scans_count, 'created_at', q.created_at,
      'grace_until', q.grace_until, 'next_rotation_at', q.next_rotation_at, 'disabled_reason', q.disabled_reason,
      'url', case when q.status <> 'disabled' then private.qr_url(q.id) end)
      order by (q.status = 'active') desc, q.created_at desc)
    from public.qr_codes q join public.branches b on b.id = q.branch_id
    where b.merchant_id = p_merchant and (q.status <> 'disabled' or q.created_at > now() - interval '60 days')), '[]'::jsonb);
end $$;

create or replace function public.merchant_campaigns(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name, 'goal_type', c.goal_type, 'goal_visits', c.goal_visits,
      'audience', c.audience, 'radius_km', c.radius_km, 'schedule', c.schedule, 'bonus_points', c.bonus_points, 'cpv_iqd', c.cpv_iqd,
      'budget_iqd', c.budget_iqd, 'spent_iqd', c.spent_iqd, 'generated_visits', c.generated_visits, 'status', c.status,
      'starts_at', c.starts_at, 'ends_at', c.ends_at, 'created_at', c.created_at,
      'visits', (select count(*) from public.visits v where v.campaign_id = c.id),
      'cost_per_visit_iqd', case when c.generated_visits > 0 then round(c.spent_iqd::numeric / c.generated_visits) end)
      order by c.created_at desc)
    from public.campaigns c where c.merchant_id = p_merchant), '[]'::jsonb);
end $$;

create or replace function public.merchant_rewards(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', r.id, 'title_ar', r.title_ar, 'value_iqd', r.value_iqd, 'cost_points', r.cost_points,
      'stock', r.stock, 'validity_days', r.validity_days, 'terms_ar', r.terms_ar, 'active', r.active,
      'redeemed', (select count(*) from public.bag_items b where b.reward_id = r.id and b.status = 'redeemed'),
      'in_bags', (select count(*) from public.bag_items b where b.reward_id = r.id and b.status = 'available')) order by r.created_at)
    from public.rewards r where r.merchant_id = p_merchant), '[]'::jsonb);
end $$;

create or replace function public.merchant_team(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner']);
  return coalesce((select jsonb_agg(jsonb_build_object('user_id', mm.user_id, 'name', p.display_name, 'phone', private.mask_phone(p.phone),
      'role', mm.role, 'branch_id', mm.branch_id, 'active', mm.active, 'added_at', mm.added_at) order by mm.added_at)
    from public.merchant_members mm join public.profiles p on p.id = mm.user_id where mm.merchant_id = p_merchant), '[]'::jsonb);
end $$;

create or replace function public.merchant_billing(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare m0 timestamptz := date_trunc('month', now() at time zone 'Asia/Baghdad') at time zone 'Asia/Baghdad';
begin
  perform private.require_member(p_merchant, array['owner']);
  return jsonb_build_object(
    'month_charges_iqd', (select coalesce(sum(amount_iqd), 0) from public.merchant_charges where merchant_id = p_merchant and created_at >= m0),
    'month_generated', (select count(*) from public.merchant_charges where merchant_id = p_merchant and created_at >= m0),
    'by_campaign', coalesce((select jsonb_agg(jsonb_build_object('campaign', c.name, 'visits', x.n, 'amount_iqd', x.s))
        from (select campaign_id, count(*) n, sum(amount_iqd) s from public.merchant_charges where merchant_id = p_merchant and created_at >= m0 group by campaign_id) x
        join public.campaigns c on c.id = x.campaign_id), '[]'::jsonb),
    'subscriptions', coalesce((select jsonb_agg(jsonb_build_object('plan', plan, 'period_start', period_start, 'period_end', period_end,
        'amount_iqd', amount_iqd, 'status', status) order by period_start desc) from public.subscriptions where merchant_id = p_merchant), '[]'::jsonb));
end $$;

create or replace function public.merchant_recent_visits(p_merchant uuid, p_limit int default 20) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  return coalesce((select jsonb_agg(jsonb_build_object('at', v.verified_at, 'generated', v.generated, 'branch', b.name,
      'customer', split_part(coalesce(p.display_name, 'زبون'), ' ', 1), 'campaign', c.name) order by v.verified_at desc)
    from (select * from public.visits where merchant_id = p_merchant order by verified_at desc limit least(p_limit, 100)) v
    join public.branches b on b.id = v.branch_id join public.profiles p on p.id = v.user_id left join public.campaigns c on c.id = v.campaign_id), '[]'::jsonb);
end $$;

-- AI tips addressed to a merchant (only proposals that passed the rule check).
create or replace function public.merchant_tips(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'kind', a.kind, 'payload', a.payload, 'reasons', a.reason_codes,
      'status', a.status, 'at', a.created_at) order by a.created_at desc)
    from public.ai_recommendations a
    where a.payload ->> 'merchant_id' = p_merchant::text and a.status in ('proposed','applied') and a.created_at > now() - interval '7 days'), '[]'::jsonb);
end $$;

-- ---------------------------------------------------------------------
-- Admin read models
-- ---------------------------------------------------------------------
create or replace function public.admin_users(p_q text default null, p_limit int default 50) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','fraud_analyst','support','finance']);
  return coalesce((select jsonb_agg(row_to_json(x) order by x.created_at desc) from (
    select p.id, p.display_name, private.mask_phone(p.phone) as phone, p.status, p.account_trust, p.xp, p.created_at,
           (select balance from public.wallets w where w.kind = 'user_available' and w.owner_id = p.id) as points,
           (select count(*) from public.visits v where v.user_id = p.id) as visits,
           (select count(*) from public.scans s where s.user_id = p.id and s.decision in ('rejected','review')) as flagged,
           (select jsonb_agg(role) from public.platform_roles r where r.user_id = p.id) as roles
    from public.profiles p
    where p_q is null or p_q = '' or p.phone like '%' || regexp_replace(p_q, '\D', '', 'g') || '%' or p.display_name ilike '%' || p_q || '%'
    order by p.created_at desc limit least(p_limit, 200)) x), '[]'::jsonb);
end $$;

create or replace function public.admin_merchants(p_status text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','finance']);
  return coalesce((select jsonb_agg(row_to_json(x) order by (x.status = 'pending') desc, x.created_at desc) from (
    select m.id, m.display_name, m.category, m.status, m.plan, m.created_at, m.reject_reason,
           (select display_name from public.profiles where id = m.created_by) as owner,
           (select count(*) from public.branches b where b.merchant_id = m.id) as branches,
           (select count(*) from public.visits v where v.merchant_id = m.id and v.verified_at > now() - interval '30 days') as visits_30d,
           (select count(*) filter (where generated) from public.visits v where v.merchant_id = m.id and v.verified_at > now() - interval '30 days') as generated_30d,
           (select jsonb_agg(jsonb_build_object('id', b.id, 'name', b.name)) from public.branches b where b.merchant_id = m.id) as branch_list
    from public.merchants m where p_status is null or m.status = p_status) x), '[]'::jsonb);
end $$;

create or replace function public.admin_campaigns(p_status text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','finance']);
  return coalesce((select jsonb_agg(row_to_json(x) order by (x.status = 'pending_approval') desc, x.created_at desc) from (
    select c.id, c.name, c.goal_type, c.goal_visits, c.audience, c.radius_km, c.schedule, c.bonus_points, c.cpv_iqd, c.budget_iqd,
           c.spent_iqd, c.generated_visits, c.status, c.starts_at, c.ends_at, c.created_at, m.display_name as merchant
    from public.campaigns c join public.merchants m on m.id = c.merchant_id where p_status is null or c.status = p_status) x), '[]'::jsonb);
end $$;

create or replace function public.admin_rewards() returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','finance']);
  return coalesce((select jsonb_agg(row_to_json(x) order by x.active, x.merchant) from (
    select r.id, r.title_ar, r.value_iqd, r.cost_points, r.stock, r.active, r.validity_days, m.display_name as merchant,
           round(r.value_iqd::numeric / private.cfg_num('points.iqd_per_point')) as suggested_points,
           (select count(*) from public.bag_items b where b.reward_id = r.id and b.status = 'redeemed') as redeemed
    from public.rewards r join public.merchants m on m.id = r.merchant_id) x), '[]'::jsonb);
end $$;

create or replace function public.admin_spots() returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops']);
  return coalesce((select jsonb_agg(row_to_json(x) order by x.status, x.merchant) from (
    select s.id, s.title_ar, s.kind, s.base_points, s.cap_points, s.qty_total, s.qty_left, s.status, s.starts_at, s.ends_at,
           s.requires_dynamic, b.name as branch, m.display_name as merchant,
           (select count(*) from public.visits v where v.spot_id = s.id) as visits
    from public.spots s join public.branches b on b.id = s.branch_id join public.merchants m on m.id = b.merchant_id) x), '[]'::jsonb);
end $$;

create or replace function public.admin_spot_status(p_spot uuid, p_status text, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare old text;
begin
  perform private.require_platform(array['ops']);
  if p_status not in ('live','paused','ended') then perform private.fail('BAD_STATUS'); end if;
  select status into old from public.spots where id = p_spot;
  if old is null then perform private.fail('NOT_FOUND'); end if;
  update public.spots set status = p_status where id = p_spot;
  perform private.audit('spot_status', 'spot', p_spot::text, jsonb_build_object('status', old), jsonb_build_object('status', p_status), p_reason);
end $$;

create or replace function public.admin_missions() returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'code', m.code, 'kind', m.kind, 'title_ar', m.title_ar, 'rule', m.rule,
      'reward_points', m.reward_points, 'active', m.active,
      'claims_7d', (select count(*) from public.mission_claims c where c.mission_id = m.id and c.claimed_at > now() - interval '7 days')) order by m.kind)
    from public.missions m), '[]'::jsonb);
end $$;

create or replace function public.admin_mission_update(p_mission uuid, p_active boolean, p_reward_points int) returns void
language plpgsql security definer set search_path = '' as $$
declare old jsonb;
begin
  perform private.require_platform(array['ops']);
  if p_reward_points < 1 or p_reward_points > 2000 then perform private.fail('BAD_AMOUNT'); end if;
  select jsonb_build_object('active', active, 'reward_points', reward_points) into old from public.missions where id = p_mission;
  if old is null then perform private.fail('NOT_FOUND'); end if;
  update public.missions set active = p_active, reward_points = p_reward_points where id = p_mission;
  perform private.audit('mission_updated', 'mission', p_mission::text, old, jsonb_build_object('active', p_active, 'reward_points', p_reward_points));
end $$;

create or replace function public.admin_audit(p_before bigint default null, p_limit int default 50) returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops','fraud_analyst','finance']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', a.id, 'at', a.created_at, 'actor', coalesce(p.display_name, 'النظام'),
      'action', a.action, 'entity', a.entity, 'entity_id', a.entity_id, 'before', a.before, 'after', a.after, 'reason', a.reason) order by a.id desc)
    from (select * from public.audit_log where p_before is null or id < p_before order by id desc limit least(p_limit, 200)) a
    left join public.profiles p on p.id = a.actor_id), '[]'::jsonb);
end $$;

create or replace function public.admin_config() returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['super_admin']);
  return (select jsonb_agg(jsonb_build_object('key', key, 'value', value, 'description', description, 'updated_at', updated_at) order by key) from private.config);
end $$;

create or replace function public.admin_analytics(p_days int default 30) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare since timestamptz := now() - make_interval(days => least(p_days, 180)); scans bigint; verified bigint; issued bigint; redeemed bigint; flagged bigint;
begin
  perform private.require_platform(array['ops','finance']);
  select count(*), count(*) filter (where decision in ('rejected','review')) into scans, flagged from public.scans where created_at >= since;
  select count(*) into verified from public.visits where verified_at >= since;
  select count(*), count(*) filter (where status = 'redeemed') into issued, redeemed from public.bag_items where created_at >= since;
  return jsonb_build_object(
    'dau', (select count(distinct user_id) from public.events where ts > now() - interval '1 day' and user_id is not null),
    'wau', (select count(distinct user_id) from public.events where ts > now() - interval '7 days' and user_id is not null),
    'mau', (select count(distinct user_id) from public.events where ts > now() - interval '30 days' and user_id is not null),
    'new_users', (select count(*) from public.profiles where created_at >= since),
    'scans', scans, 'verified_visits', verified,
    'verified_rate', case when scans > 0 then round(verified::numeric / scans, 3) end,
    'fraud_rate', case when scans > 0 then round(flagged::numeric / scans, 3) end,
    'redemption_rate', case when issued > 0 then round(redeemed::numeric / issued, 3) end,
    'avg_visits_per_user', (select round(avg(n), 2) from (select count(*) n from public.visits where verified_at >= since group by user_id) x),
    'returning_users_7d', (select count(*) from (select user_id from public.visits where verified_at >= since group by user_id
                           having max(verified_at) - min(verified_at) <= interval '7 days' and count(distinct branch_id) >= 2) x),
    'active_merchants', (select count(distinct merchant_id) from public.visits where verified_at >= since),
    'points_issued', (select coalesce(sum(e.amount), 0) from public.ledger_entries e join public.wallets w on w.id = e.wallet_id
                      where w.kind in ('user_available','user_held') and e.amount > 0 and e.created_at >= since),
    'points_redeemed', (select coalesce(sum(e.amount), 0) from public.ledger_entries e join public.wallets w on w.id = e.wallet_id
                        where w.kind = 'store_sink' and e.created_at >= since),
    'revenue_iqd', (select coalesce(sum(amount_iqd), 0) from public.merchant_charges where created_at >= since),
    'series', coalesce((select jsonb_agg(jsonb_build_object('day', d, 'scans', s, 'visits', v) order by d) from (
        select g::date d,
               (select count(*) from public.scans where (created_at at time zone 'Asia/Baghdad')::date = g::date) s,
               (select count(*) from public.visits where (verified_at at time zone 'Asia/Baghdad')::date = g::date) v
        from generate_series((now() at time zone 'Asia/Baghdad')::date - least(p_days, 60) + 1, (now() at time zone 'Asia/Baghdad')::date, interval '1 day') g) z), '[]'::jsonb));
end $$;

create or replace function public.admin_health() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare jobs jsonb := '[]'::jsonb;
begin
  perform private.require_platform(array['ops','super_admin']);
  if to_regclass('cron.job_run_details') is not null then
    execute $q$ select coalesce(jsonb_agg(jsonb_build_object('job', j.jobname, 'last_run', d.end_time, 'status', d.status)), '[]'::jsonb)
                from cron.job j left join lateral (select end_time, status from cron.job_run_details r where r.jobid = j.jobid order by runid desc limit 1) d on true $q$
    into jobs;
  end if;
  return jsonb_build_object(
    'db_size_mb', round(pg_database_size(current_database()) / 1048576.0),
    'pending_held', (select count(*) from public.scans where decision = 'held'),
    'pending_review', (select count(*) from public.scans where decision = 'review'),
    'oldest_pending_minutes', (select round(extract(epoch from now() - min(created_at)) / 60) from public.scans where decision in ('held','review')),
    'scans_last_hour', (select count(*) from public.scans where created_at > now() - interval '1 hour'),
    'rejections_last_hour', (select count(*) from public.scans where created_at > now() - interval '1 hour' and decision in ('rejected','gate_reject')),
    'qr_disabled_24h', (select count(*) from public.audit_log where action = 'qr_auto_disabled' and created_at > now() - interval '1 day'),
    'active_hunts', (select count(*) from public.hunts where status = 'active' and expires_at > now()),
    'jobs', jobs, 'checked_at', now());
end $$;

-- ---------------------------------------------------------------------
-- AI layer: proposals → deterministic rule check → (optional) apply.
-- The AI never moves points; an applied proposal only creates a capped,
-- time-limited boost funded by AMOUNI marketing.
-- ---------------------------------------------------------------------
create or replace function public.job_ai_suggest() returns int
language plpgsql security definer set search_path = '' as $$
declare r record; n int := 0; hour_now int := extract(hour from now() at time zone 'Asia/Baghdad')::int;
begin
  -- 1) Traffic distribution: branches that are unusually quiet right now.
  for r in
    select b.id as branch_id, b.merchant_id, b.name, s.id as spot_id,
           (select count(*)::numeric / 14 from public.visits v where v.branch_id = b.id and v.verified_at > now() - interval '14 days'
              and extract(hour from v.verified_at at time zone 'Asia/Baghdad') = hour_now) as usual,
           (select count(*) from public.visits v where v.branch_id = b.id and v.verified_at > now() - interval '1 hour') as now_n
    from public.branches b join public.merchants m on m.id = b.merchant_id
    join lateral (select id from public.spots s where s.branch_id = b.id and s.status = 'live' and s.kind = 'normal' limit 1) s on true
    where b.status = 'active' and m.status = 'active'
  loop
    continue when r.usual < 1 or r.now_n >= r.usual * private.cfg_num('ai.quiet_ratio');
    continue when exists (select 1 from public.ai_recommendations a where a.kind = 'traffic_balance' and a.subject_id = r.spot_id::text
                          and a.created_at > now() - interval '3 hours');
    insert into public.ai_recommendations (kind, subject_type, subject_id, payload, reason_codes)
    values ('traffic_balance', 'spot', r.spot_id::text,
            jsonb_build_object('merchant_id', r.merchant_id, 'branch', r.name, 'amount', private.cfg_int('ai.max_quiet_boost'),
                               'hours', private.cfg_int('ai.boost_hours'), 'usual_per_hour', round(r.usual, 1), 'now', r.now_n),
            array['quiet_now']);
    n := n + 1;
  end loop;

  -- 2) Campaign coaching: running campaigns behind pace, or mostly bringing back old customers.
  for r in
    select c.*, greatest(extract(epoch from now() - c.starts_at) / 86400, 0.5) as days_in,
           greatest(extract(epoch from c.ends_at - c.starts_at) / 86400, 1) as days_total,
           (select count(*) from public.visits v where v.campaign_id = c.id and not v.generated) as returning_n
    from public.campaigns c where c.status = 'running'
  loop
    continue when exists (select 1 from public.ai_recommendations a where a.kind = 'campaign_tip' and a.subject_id = r.id::text
                          and a.created_at > now() - interval '24 hours');
    if r.generated_visits < (r.goal_visits * r.days_in / r.days_total) * 0.5 then
      insert into public.ai_recommendations (kind, subject_type, subject_id, payload, reason_codes)
      values ('campaign_tip', 'campaign', r.id::text,
              jsonb_build_object('merchant_id', r.merchant_id, 'campaign', r.name, 'tip_ar',
                'الحملة أبطأ من المتوقع. جرّب ترفع النقاط الإضافية أو تخلي الجائزة الفورية أوضح بالبوستر.',
                'expected', round(r.goal_visits * r.days_in / r.days_total), 'actual', r.generated_visits),
              array['behind_pace']);
      n := n + 1;
    elsif r.returning_n > r.generated_visits * 2 and r.returning_n >= 5 then
      insert into public.ai_recommendations (kind, subject_type, subject_id, payload, reason_codes)
      values ('campaign_tip', 'campaign', r.id::text,
              jsonb_build_object('merchant_id', r.merchant_id, 'campaign', r.name, 'tip_ar',
                'أغلب الزيارات من زبائن يعرفونك. خلّي الجمهور «زبائن جدد» حتى تدفع بس على الجدد.'),
              array['mostly_returning']);
      n := n + 1;
    end if;
  end loop;

  if (private.cfg('ai.auto_apply') #>> '{}')::boolean then
    for r in select id from public.ai_recommendations where status = 'proposed' and kind = 'traffic_balance' loop
      perform private.ai_apply(r.id, null);
    end loop;
  end if;
  return n;
end $$;

-- Deterministic rule check + apply. Returns the check result.
create or replace function private.ai_apply(p_id uuid, p_actor uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare a record; sp record; used bigint; chk jsonb; ok boolean; amt int; hrs int;
begin
  select * into a from public.ai_recommendations where id = p_id for update;
  if a.id is null then perform private.fail('NOT_FOUND'); end if;
  if a.status <> 'proposed' then perform private.fail('NOT_PENDING'); end if;

  if a.kind = 'campaign_tip' then
    update public.ai_recommendations set status = 'applied', decided_at = now(), rule_check = '{"ok":true,"note":"tip shown to merchant"}' where id = p_id;
    return '{"ok":true}'::jsonb;
  end if;

  amt := least((a.payload ->> 'amount')::int, private.cfg_int('ai.max_quiet_boost'));
  hrs := least(coalesce((a.payload ->> 'hours')::int, 2), private.cfg_int('ai.boost_hours'));
  select s.*, m.status as mstatus into sp from public.spots s join public.branches b on b.id = s.branch_id join public.merchants m on m.id = b.merchant_id
  where s.id = a.subject_id::uuid;
  select coalesce(sum((payload ->> 'amount')::int), 0) into used from public.ai_recommendations
  where kind = 'traffic_balance' and status = 'applied' and decided_at >= private.local_day_start('Asia/Baghdad');
  ok := sp.id is not null and sp.status = 'live' and sp.mstatus = 'active' and amt > 0
        and used + amt <= private.cfg_int('ai.daily_boost_points')
        and not exists (select 1 from public.boosts bo where bo.spot_id = sp.id and bo.kind = 'quiet_place' and bo.active and bo.ends_at > now());
  chk := jsonb_build_object('ok', ok, 'amount', amt, 'hours', hrs, 'daily_used', used, 'daily_cap', private.cfg_int('ai.daily_boost_points'));
  if ok then
    insert into public.boosts (spot_id, kind, amount, rule, wallet_id, starts_at, ends_at, source)
    values (sp.id, 'quiet_place', amt, '{}'::jsonb, null, now(), now() + make_interval(hours => hrs), 'ai');
    update public.ai_recommendations set status = 'applied', decided_at = now(), rule_check = chk where id = p_id;
  else
    update public.ai_recommendations set status = 'rejected', decided_at = now(), rule_check = chk where id = p_id;
  end if;
  perform private.audit(case when ok then 'ai_applied' else 'ai_rule_rejected' end, 'ai_recommendation', p_id::text, null, chk);
  return chk;
end $$;

create or replace function public.admin_ai_list(p_status text default 'proposed') returns jsonb
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops']);
  return coalesce((select jsonb_agg(jsonb_build_object('id', id, 'kind', kind, 'subject_type', subject_type, 'subject_id', subject_id,
      'payload', payload, 'reasons', reason_codes, 'status', status, 'rule_check', rule_check, 'at', created_at) order by created_at desc)
    from (select * from public.ai_recommendations where p_status is null or status = p_status order by created_at desc limit 100) a), '[]'::jsonb);
end $$;

create or replace function public.admin_ai_decide(p_id uuid, p_apply boolean) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare actor uuid := private.require_platform(array['ops']);
begin
  if p_apply then return private.ai_apply(p_id, actor); end if;
  update public.ai_recommendations set status = 'rejected', decided_at = now(), rule_check = '{"ok":false,"note":"rejected by ops"}'
  where id = p_id and status = 'proposed';
  perform private.audit('ai_dismissed', 'ai_recommendation', p_id::text);
  return '{"ok":false}'::jsonb;
end $$;

-- Ops can trigger the suggestion job on demand (it only writes proposals).
create or replace function public.admin_ai_run() returns int
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_platform(array['ops']);
  return public.job_ai_suggest();
end $$;

-- ---------------------------------------------------------------------
-- Grants
-- ---------------------------------------------------------------------
grant execute on function
  public.my_roles(), public.my_profile(), public.my_bag(), public.my_scans(int), public.my_notifications(int),
  public.notification_read(uuid), public.my_active_hunt(), public.cancel_hunt(uuid),
  public.merchant_home(uuid), public.merchant_qr_list(uuid), public.merchant_campaigns(uuid), public.merchant_rewards(uuid),
  public.merchant_team(uuid), public.merchant_billing(uuid), public.merchant_recent_visits(uuid, int), public.merchant_tips(uuid),
  public.admin_users(text, int), public.admin_merchants(text), public.admin_campaigns(text), public.admin_rewards(), public.admin_spots(),
  public.admin_spot_status(uuid, text, text), public.admin_missions(), public.admin_mission_update(uuid, boolean, int),
  public.admin_audit(bigint, int), public.admin_config(), public.admin_analytics(int), public.admin_health(),
  public.admin_ai_list(text), public.admin_ai_decide(uuid, boolean), public.admin_ai_run()
to authenticated;
grant execute on function public.store_list(float8, float8) to anon, authenticated;
grant execute on function public.job_ai_suggest() to service_role;

do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    perform cron.schedule('amouni_ai_suggest', '*/30 * * * *', 'select public.job_ai_suggest()');
  end if;
end $$;
