-- =====================================================================
-- AMOUNI · 0004 · Bag, redemption, missions, billing, audit, analytics
-- =====================================================================

create table public.bag_items (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id),
  reward_id   uuid not null references public.rewards(id),
  source      text not null check (source in ('spot','store','mission','fund')),
  source_ref  text,
  status      text not null check (status in ('held','available','redeemed','expired','cancelled')),
  expires_at  timestamptz not null,
  created_at  timestamptz not null default now()
);
create index bag_items_user_idx on public.bag_items (user_id, status);

-- Short-lived redemption codes (60 s, single use). Private: shown only to the owner via RPC.
create table private.redeem_tokens (
  id          uuid primary key default gen_random_uuid(),
  bag_item_id uuid not null references public.bag_items(id) on delete cascade,
  merchant_id uuid not null references public.merchants(id),
  code        text not null check (code ~ '^[0-9]{6}$'),
  qr_secret   text not null,
  expires_at  timestamptz not null,
  used_at     timestamptz,
  created_at  timestamptz not null default now()
);
create index redeem_tokens_lookup_idx on private.redeem_tokens (merchant_id, code) where used_at is null;

create table public.redemptions (
  id             uuid primary key default gen_random_uuid(),
  bag_item_id    uuid not null references public.bag_items(id),
  staff_user_id  uuid not null references public.profiles(id),
  branch_id      uuid not null references public.branches(id),
  method         text not null check (method in ('qr','code')),
  created_at     timestamptz not null default now(),
  reversed_at    timestamptz,
  reversed_by    uuid references public.profiles(id),
  reverse_reason text
);
create unique index redemptions_one_live on public.redemptions (bag_item_id) where reversed_at is null;   -- redeemed once
create unique index bag_items_store_idem on public.bag_items (user_id, source_ref) where source = 'store';  -- purchase idempotency

create table public.missions (
  id            uuid primary key default gen_random_uuid(),
  code          text unique not null,
  kind          text not null check (kind in ('daily','weekly')),
  title_ar      text not null,
  rule          jsonb not null,           -- {"metric":"new_merchants"|"distinct_branches","target":2}
  reward_points int  not null check (reward_points > 0),
  active        boolean not null default true
);

create table public.mission_claims (
  user_id    uuid not null references public.profiles(id),
  mission_id uuid not null references public.missions(id),
  period     text not null,              -- '2026-10-01' or 'W2026-09-26'
  claimed_at timestamptz not null default now(),
  primary key (user_id, mission_id, period)   -- one claim per period, enforced by the database
);

-- What merchants owe for campaign Generated Visits (invoiced monthly).
create table public.merchant_charges (
  id          uuid primary key default gen_random_uuid(),
  merchant_id uuid not null references public.merchants(id),
  campaign_id uuid not null references public.campaigns(id),
  visit_id    uuid unique not null references public.visits(id),
  amount_iqd  int  not null check (amount_iqd >= 0),
  created_at  timestamptz not null default now()
);

create table public.subscriptions (
  id           uuid primary key default gen_random_uuid(),
  merchant_id  uuid not null references public.merchants(id),
  plan         text not null check (plan in ('free','basic','silver','gold')),
  period_start date not null,
  period_end   date not null,
  amount_iqd   int  not null check (amount_iqd >= 0),
  status       text not null default 'pending' check (status in ('pending','paid','overdue','cancelled')),
  check (period_end > period_start)
);

create table public.notifications (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references public.profiles(id),
  kind          text not null,
  payload       jsonb not null default '{}'::jsonb,
  scheduled_for timestamptz not null default now(),
  sent_at       timestamptz,
  opened_at     timestamptz
);
create index notifications_user_idx on public.notifications (user_id, scheduled_for desc);

-- Every admin / merchant / system action that changes something important.
create table public.audit_log (
  id         bigserial primary key,
  actor_id   uuid,
  action     text not null,
  entity     text not null,
  entity_id  text,
  before     jsonb,
  after      jsonb,
  reason     text,
  created_at timestamptz not null default now()
);
create index audit_log_entity_idx on public.audit_log (entity, entity_id, id desc);
create trigger audit_log_append_only before update or delete on public.audit_log
  for each row execute function private.forbid_mutation();

create or replace function private.audit(p_action text, p_entity text, p_entity_id text,
  p_before jsonb default null, p_after jsonb default null, p_reason text default null) returns void
language sql security definer set search_path = '' as $$
  insert into public.audit_log (actor_id, action, entity, entity_id, before, after, reason)
  values (auth.uid(), p_action, p_entity, p_entity_id, p_before, p_after, p_reason)
$$;

-- Product analytics events (also streamed to PostHog by the API layer).
create table public.events (
  id      bigserial primary key,
  name    text not null,
  user_id uuid,
  props   jsonb not null default '{}'::jsonb,
  ts      timestamptz not null default now()
);
create index events_name_ts_idx on public.events (name, ts desc);

-- AI suggests, rules decide: every suggestion is stored with the rule check that accepted or rejected it.
create table public.ai_recommendations (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null check (kind in ('rank','boost','campaign_tip','traffic_balance')),
  subject_type text not null,
  subject_id   text not null,
  payload      jsonb not null,
  reason_codes text[] not null default '{}',
  status       text not null default 'proposed' check (status in ('proposed','applied','rejected','expired')),
  rule_check   jsonb,
  created_at   timestamptz not null default now(),
  decided_at   timestamptz
);

-- Access helpers ------------------------------------------------------
create or replace function private.has_platform_role(p_roles text[]) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.platform_roles
                 where user_id = auth.uid() and (role = any(p_roles) or role = 'super_admin'))
$$;

-- Role of the caller at a merchant. With p_branch: members of that branch or merchant-wide members.
-- Without p_branch (merchant-wide actions): only merchant-wide members (branch-scoped staff are excluded).
create or replace function private.member_role(p_merchant uuid, p_branch uuid default null) returns text
language sql stable security definer set search_path = '' as $$
  select mm.role from public.merchant_members mm
  where mm.merchant_id = p_merchant and mm.user_id = auth.uid() and mm.active
    and (mm.branch_id is null or (p_branch is not null and mm.branch_id = p_branch))
$$;

-- Used by RLS policies (runs as owner so it can read merchant_members).
create or replace function public.is_merchant_member(p_merchant uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.merchant_members where merchant_id = p_merchant and user_id = auth.uid() and active)
$$;

create or replace function private.require_platform(p_roles text[]) returns uuid
language plpgsql stable security definer set search_path = '' as $$
begin
  if auth.uid() is null or not private.has_platform_role(p_roles) then perform private.fail('FORBIDDEN'); end if;
  return auth.uid();
end $$;

create or replace function private.require_member(p_merchant uuid, p_roles text[], p_branch uuid default null) returns text
language plpgsql stable security definer set search_path = '' as $$
declare r text;
begin
  r := private.member_role(p_merchant, p_branch);
  if r is null or not (r = any(p_roles)) then perform private.fail('FORBIDDEN'); end if;
  return r;
end $$;

-- A signed-in user. By default the account must be active (not limited/banned);
-- read-only endpoints pass p_active => false so restricted users can still see their data.
create or replace function private.require_user(p_active boolean default true) returns uuid
language plpgsql stable security definer set search_path = '' as $$
declare st text;
begin
  if auth.uid() is null then perform private.fail('UNAUTHENTICATED'); end if;
  select status into st from public.profiles where id = auth.uid();
  if st is null then perform private.fail('PROFILE_MISSING'); end if;
  if p_active and st <> 'active' then perform private.fail('ACCOUNT_LIMITED'); end if;
  return auth.uid();
end $$;
