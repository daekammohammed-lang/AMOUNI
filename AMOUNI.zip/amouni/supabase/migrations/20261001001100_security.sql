-- =====================================================================
-- AMOUNI · 0011 · Row Level Security, grants, function exposure.
--
-- Principle: deny by default. Clients may READ a few of their own rows
-- and public catalogue data; every WRITE goes through an RPC.
-- =====================================================================

do $$ declare t record;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('alter table public.%I enable row level security', t.tablename);
    execute format('alter table public.%I force row level security', t.tablename);
  end loop;
end $$;

revoke all on all tables    in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;
revoke all on all functions in schema private from public, anon, authenticated;
alter default privileges in schema public revoke all on tables from anon, authenticated;
alter default privileges in schema public revoke execute on functions from public, anon, authenticated;
alter default privileges in schema private revoke execute on functions from public, anon, authenticated;

-- Table owner (postgres) runs the SECURITY DEFINER functions; FORCE RLS would block it, so give it a bypass policy.
do $$ declare t record;
begin
  for t in select tablename from pg_tables where schemaname = 'public' loop
    execute format('create policy owner_all on public.%I for all to postgres using (true) with check (true)', t.tablename);
  end loop;
end $$;

-- ---------- public catalogue ----------
grant select on public.cities, public.districts to anon, authenticated;
create policy read_all on public.cities    for select to anon, authenticated using (active);
create policy read_all on public.districts for select to anon, authenticated using (true);

grant select (id, display_name, category, logo_path, status) on public.merchants to anon, authenticated;
create policy read_active on public.merchants for select to anon, authenticated using (status = 'active');

grant select (id, merchant_id, title_ar, description_ar, image_path, cost_points, stock, validity_days, terms_ar, branch_ids, active)
  on public.rewards to authenticated;
create policy read_store on public.rewards for select to authenticated using (active and cost_points is not null);

grant select on public.missions to authenticated;
create policy read_active on public.missions for select to authenticated using (active);

-- ---------- own rows ----------
grant select (id, phone, display_name, city_id, locale, status, xp, invite_code, created_at) on public.profiles to authenticated;
create policy read_own on public.profiles for select to authenticated using (id = auth.uid());

grant select on public.bag_items to authenticated;
create policy read_own on public.bag_items for select to authenticated using (user_id = auth.uid());

grant select (id, spot_id, branch_id, decision, result_code, points, created_at, response) on public.scans to authenticated;
create policy read_own on public.scans for select to authenticated using (user_id = auth.uid());

grant select (id, spot_id, status, started_at, expires_at, arrived_at, completed_at) on public.hunts to authenticated;
create policy read_own on public.hunts for select to authenticated using (user_id = auth.uid());

grant select (id, kind, balance) on public.wallets to authenticated;
create policy read_own on public.wallets for select to authenticated
  using (owner_id = auth.uid() and kind in ('user_available','user_held'));

grant select on public.mission_claims to authenticated;
create policy read_own on public.mission_claims for select to authenticated using (user_id = auth.uid());

grant select on public.notifications to authenticated;
create policy read_own on public.notifications for select to authenticated using (user_id = auth.uid());

-- Merchants read their own merchant rows (dashboards use RPCs, this is for realtime subscriptions).
grant select (id, merchant_id, name, address, geofence_m, hours, capacity, hint_ar, cashier_mode, status) on public.branches to authenticated;
create policy read_member on public.branches for select to authenticated using (public.is_merchant_member(merchant_id));
grant execute on function public.is_merchant_member(uuid) to authenticated;

-- ---------- RPC surface ----------
-- Anyone (also signed-out visitors) can browse.
grant execute on function
  public.discover_picks(float8, float8, int),
  public.discover_map(float8, float8, numeric, text),
  public.get_spot(uuid, float8, float8)
to anon, authenticated;

-- Signed-in users.
grant execute on function
  public.complete_profile(text, uuid, text),
  public.start_hunt(uuid, float8, float8, real, text, text),
  public.hunt_ping(uuid, float8, float8, real),
  public.hunt_hint(uuid),
  public.my_wallet(),
  public.my_missions(),
  public.claim_mission(uuid),
  public.my_discovery(uuid),
  public.buy_reward(uuid, text),
  public.issue_redeem_token(uuid),
  -- merchant (role checked inside)
  public.merchant_apply(text, text, uuid, text, float8, float8, text, uuid),
  public.merchant_add_branch(uuid, text, uuid, float8, float8, text, uuid, int, jsonb),
  public.merchant_add_staff(uuid, text, text, uuid),
  public.merchant_accept_invite(uuid),
  public.merchant_set_settings(uuid, int),
  public.branch_set_cashier_mode(uuid, boolean),
  public.qr_create(uuid, text, text),
  public.qr_print(uuid),
  public.qr_rotate(uuid, text),
  public.cashier_token(uuid),
  public.merchant_redeem(uuid, text),
  public.merchant_reward_upsert(uuid, text, int, int, int, text, uuid),
  public.campaign_estimate(uuid, numeric, int, int),
  public.campaign_save(uuid, jsonb, uuid),
  public.campaign_submit(uuid),
  public.campaign_pause(uuid, boolean),
  public.merchant_stats(uuid, int),
  -- platform staff (role checked inside)
  public.admin_review_queue(int),
  public.admin_resolve_scan(uuid, boolean, text),
  public.admin_user_status(uuid, text, text),
  public.admin_adjust_points(uuid, int, text),
  public.admin_set_config(text, jsonb, text),
  public.admin_merchant_decide(uuid, boolean, text, text),
  public.admin_reward_price(uuid, int, boolean),
  public.admin_spot_create(uuid, text, text, int, int, uuid, boolean, int, timestamptz, timestamptz, int),
  public.admin_reverse_redemption(uuid, text),
  public.admin_campaign_decide(uuid, boolean, text),
  public.admin_economy(),
  public.admin_city_pulse(uuid)
to authenticated;

-- Edge functions only (they authenticate the user, rate-limit IP/device and check attestation first).
grant execute on function
  public.scan_v1(uuid, text, float8, float8, real, text, text, text, text, inet, jsonb),
  public.step_up_v1(uuid, uuid, text, float8, float8, real),
  public.job_release_held(),
  public.job_housekeeping(),
  public.job_rotate_qr(),
  public.job_campaigns()
to service_role;
grant usage on schema public to anon, authenticated, service_role;

-- History tables cannot be truncated either.
create trigger ledger_tx_no_truncate      before truncate on public.ledger_tx      for each statement execute function private.forbid_mutation();
create trigger ledger_entries_no_truncate before truncate on public.ledger_entries for each statement execute function private.forbid_mutation();
create trigger audit_log_no_truncate      before truncate on public.audit_log      for each statement execute function private.forbid_mutation();
