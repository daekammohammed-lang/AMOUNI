-- =====================================================================
-- AMOUNI · 0008 · Merchant platform: onboarding, branches, QR,
-- cashier mode, rewards, campaigns, analytics (ROI).
-- =====================================================================

-- ---------- onboarding ----------
create or replace function public.merchant_apply(
  p_name text, p_category text, p_city uuid, p_branch_name text, p_lat float8, p_lng float8,
  p_address text default null, p_district uuid default null
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); mid uuid; bid uuid;
begin
  if length(btrim(coalesce(p_name, ''))) < 2 then perform private.fail('BAD_NAME'); end if;
  if (select count(*) from public.merchant_members where user_id = uid and role = 'owner') >= 5 then perform private.fail('TOO_MANY'); end if;
  insert into public.merchants (display_name, category, created_by) values (btrim(p_name), p_category, uid) returning id into mid;
  insert into public.merchant_settings (merchant_id) values (mid);
  insert into public.branches (merchant_id, city_id, district_id, name, address, location)
  values (mid, p_city, p_district, coalesce(p_branch_name, p_name), p_address,
          extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography)
  returning id into bid;
  insert into private.branch_secrets (branch_id) values (bid);
  insert into public.merchant_members (merchant_id, user_id, role, added_by) values (mid, uid, 'owner', uid);
  perform private.audit('merchant_applied', 'merchant', mid::text, null, jsonb_build_object('name', p_name, 'category', p_category));
  return jsonb_build_object('merchant_id', mid, 'branch_id', bid, 'status', 'pending');
end $$;

create or replace function public.merchant_add_branch(
  p_merchant uuid, p_name text, p_city uuid, p_lat float8, p_lng float8, p_address text default null,
  p_district uuid default null, p_geofence_m int default 60, p_hours jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare bid uuid;
begin
  perform private.require_member(p_merchant, array['owner']);
  insert into public.branches (merchant_id, city_id, district_id, name, address, location, geofence_m, hours)
  values (p_merchant, p_city, p_district, p_name, p_address,
          extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography, p_geofence_m, coalesce(p_hours, '{}'::jsonb))
  returning id into bid;
  insert into private.branch_secrets (branch_id) values (bid);
  perform private.audit('branch_added', 'branch', bid::text, null, jsonb_build_object('merchant', p_merchant, 'name', p_name));
  return bid;
end $$;

-- Invite staff by phone. The invitee must accept; the answer is the same whether or not the
-- phone is registered (no phone-number enumeration).
create or replace function public.merchant_add_staff(p_merchant uuid, p_phone text, p_role text, p_branch uuid default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare target uuid;
begin
  perform private.require_member(p_merchant, array['owner']);
  if (select status from public.merchants where id = p_merchant) <> 'active' then perform private.fail('MERCHANT_NOT_ACTIVE'); end if;
  if p_role not in ('manager','cashier') then perform private.fail('BAD_ROLE'); end if;
  if p_branch is not null and not exists (select 1 from public.branches where id = p_branch and merchant_id = p_merchant) then
    perform private.fail('BAD_BRANCH');
  end if;
  if not private.rate_ok('invite:' || auth.uid()::text, 20, 3600) then perform private.fail('RATE_LIMITED'); end if;
  select id into target from public.profiles where phone = p_phone;
  if target is not null and target <> auth.uid() then
    insert into public.merchant_members (merchant_id, user_id, role, branch_id, added_by, active)
    values (p_merchant, target, p_role, p_branch, auth.uid(), false)
    on conflict (merchant_id, user_id) do update set role = excluded.role, branch_id = excluded.branch_id
      where public.merchant_members.role <> 'owner';
    insert into public.notifications (user_id, kind, payload)
    values (target, 'staff_invite', jsonb_build_object('merchant_id', p_merchant, 'role', p_role));
    perform private.audit('staff_invited', 'merchant', p_merchant::text, null, jsonb_build_object('user', target, 'role', p_role, 'branch', p_branch));
  end if;
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.merchant_accept_invite(p_merchant uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user();
begin
  update public.merchant_members set active = true where merchant_id = p_merchant and user_id = uid and not active;
  if not found then perform private.fail('NOT_FOUND'); end if;
  perform private.audit('staff_joined', 'merchant', p_merchant::text, null, jsonb_build_object('user', uid));
  return jsonb_build_object('ok', true);
end $$;

create or replace function public.merchant_set_settings(p_merchant uuid, p_avg_ticket_iqd int) returns void
language plpgsql security definer set search_path = '' as $$
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  update public.merchant_settings set avg_ticket_iqd = p_avg_ticket_iqd where merchant_id = p_merchant;
end $$;

create or replace function public.branch_set_cashier_mode(p_branch uuid, p_on boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare m uuid;
begin
  select merchant_id into m from public.branches where id = p_branch;
  perform private.require_member(m, array['owner','manager'], p_branch);
  update public.branches set cashier_mode = p_on where id = p_branch;
  perform private.audit('cashier_mode', 'branch', p_branch::text, null, jsonb_build_object('on', p_on));
end $$;

-- ---------- QR ----------
create or replace function private.next_rotation(p_rotation text) returns timestamptz
language sql stable set search_path = '' as $$
  select case p_rotation when 'weekly' then now() + interval '7 days' when 'monthly' then now() + interval '30 days' end
$$;

create or replace function private.issue_qr(p_branch uuid, p_label text, p_rotation text, p_campaign uuid, p_actor uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare qid uuid; tries int := 0;
begin
  loop
    begin
      insert into public.qr_codes (branch_id, campaign_id, label, rotation, next_rotation_at, created_by)
      values (p_branch, p_campaign, coalesce(p_label, 'الكاشير'), p_rotation, private.next_rotation(p_rotation), p_actor)
      returning id into qid;
      exit;
    exception when unique_violation then   -- short code collision: try a new one
      tries := tries + 1; if tries > 5 then raise; end if;
    end;
  end loop;
  insert into private.qr_tokens (qr_id, token_hash) values (qid, private.sha256(private.qr_token(qid)));
  return qid;
end $$;

create or replace function public.qr_create(p_branch uuid, p_label text default 'الكاشير', p_rotation text default 'monthly') returns jsonb
language plpgsql security definer set search_path = '' as $$
declare m uuid; qid uuid;
begin
  select merchant_id into m from public.branches where id = p_branch;
  perform private.require_member(m, array['owner','manager'], p_branch);
  if (select count(*) from public.qr_codes where branch_id = p_branch and status <> 'disabled') >= 10 then perform private.fail('TOO_MANY'); end if;
  qid := private.issue_qr(p_branch, p_label, p_rotation, null, auth.uid());
  perform private.audit('qr_created', 'qr_code', qid::text, null, jsonb_build_object('branch', p_branch, 'label', p_label));
  return public.qr_print(qid);
end $$;

-- Printable content for a QR the caller manages (URL + short code). Used for posters.
create or replace function public.qr_print(p_qr uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare q record;
begin
  select c.*, b.merchant_id into q from public.qr_codes c join public.branches b on b.id = c.branch_id where c.id = p_qr;
  if q.id is null then perform private.fail('NOT_FOUND'); end if;
  perform private.require_member(q.merchant_id, array['owner','manager'], q.branch_id);
  if q.status = 'disabled' then perform private.fail('QR_DISABLED'); end if;
  return jsonb_build_object('qr_id', q.id, 'url', private.qr_url(q.id), 'short_code', q.short_code::text,
                            'label', q.label, 'status', q.status, 'grace_until', q.grace_until);
end $$;

-- Rotate: new token goes live; old one keeps working for 24 h (grace) unless the reason is a leak.
create or replace function private.rotate_qr(p_qr uuid, p_reason text, p_actor uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare q record; nq uuid;
begin
  select * into q from public.qr_codes where id = p_qr for update;
  if q.status = 'disabled' then perform private.fail('QR_DISABLED'); end if;
  nq := private.issue_qr(q.branch_id, q.label, q.rotation, q.campaign_id, p_actor);
  if p_reason = 'leak' then
    update public.qr_codes set status = 'disabled', disabled_reason = 'leak', replaced_by = nq where id = p_qr;
  else
    update public.qr_codes set status = 'grace', grace_until = now() + make_interval(hours => private.cfg_int('qr.grace_hours')),
           replaced_by = nq, next_rotation_at = null where id = p_qr;
  end if;
  perform private.audit('qr_rotated', 'qr_code', p_qr::text, jsonb_build_object('status', q.status),
                        jsonb_build_object('new_qr', nq), p_reason);
  return nq;
end $$;

create or replace function public.qr_rotate(p_qr uuid, p_reason text default 'manual') returns jsonb
language plpgsql security definer set search_path = '' as $$
declare m uuid; b uuid;
begin
  if p_reason not in ('manual','leak') then perform private.fail('BAD_REASON'); end if;
  select br.merchant_id, br.id into m, b from public.qr_codes c join public.branches br on br.id = c.branch_id where c.id = p_qr;
  perform private.require_member(m, array['owner','manager'], b);
  return public.qr_print(private.rotate_qr(p_qr, p_reason, auth.uid()));
end $$;

-- Cashier screen: current dynamic QR for a branch. Any staff of the branch may display it.
create or replace function public.cashier_token(p_branch uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare br record; w bigint := private.dynamic_window(); per int := private.cfg_int('qr.dynamic_window_seconds');
begin
  select * into br from public.branches where id = p_branch;
  if br.id is null then perform private.fail('NOT_FOUND'); end if;
  perform private.require_member(br.merchant_id, array['owner','manager','cashier'], p_branch);
  if not br.cashier_mode then perform private.fail('CASHIER_MODE_OFF'); end if;
  return jsonb_build_object('url', 'https://amouni.app/d/' || br.public_id || '/' || private.dynamic_token(br.id, w),
                            'expires_in', per - (floor(extract(epoch from now()))::bigint % per));
end $$;

-- ---------- rewards (merchant proposes; AMOUNI prices) ----------
create or replace function public.merchant_reward_upsert(
  p_merchant uuid, p_title text, p_value_iqd int, p_stock int, p_validity_days int default 14,
  p_terms text default null, p_reward uuid default null
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare rid uuid;
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  if p_reward is null then
    insert into public.rewards (merchant_id, title_ar, value_iqd, stock, validity_days, terms_ar, active)
    values (p_merchant, p_title, p_value_iqd, p_stock, p_validity_days, p_terms, false)   -- inactive until AMOUNI prices it
    returning id into rid;
  else
    update public.rewards set title_ar = p_title, value_iqd = p_value_iqd, stock = p_stock,
           validity_days = p_validity_days, terms_ar = p_terms
    where id = p_reward and merchant_id = p_merchant returning id into rid;
    if rid is null then perform private.fail('NOT_FOUND'); end if;
  end if;
  perform private.audit('reward_upserted', 'reward', rid::text, null, jsonb_build_object('title', p_title, 'stock', p_stock));
  return rid;
end $$;

-- ---------- campaigns ----------
-- Deterministic estimate (P0): active users near the branches × category conversion × days, as a range.
create or replace function public.campaign_estimate(p_merchant uuid, p_radius_km numeric, p_days int, p_bonus int) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare users int; conv numeric; mid numeric;
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  select count(distinct s.user_id) into users
  from public.scans s, public.branches b
  where b.merchant_id = p_merchant and s.created_at > now() - interval '14 days' and s.location is not null
    and extensions.st_dwithin(s.location, b.location, p_radius_km * 1000);
  conv := 0.02 + least(p_bonus, 300) / 300.0 * 0.04;     -- 2–6 % daily conversion, rises with the bonus
  mid := greatest(users, 30) * conv * greatest(p_days, 1);
  return jsonb_build_object('low', floor(mid * 0.7), 'high', ceil(mid * 1.1), 'audience', users);
end $$;

create or replace function public.campaign_save(p_merchant uuid, p_draft jsonb, p_campaign uuid default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare cid uuid; cpv int;
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  select coalesce(cpv_iqd, 1500) into cpv from public.merchant_settings where merchant_id = p_merchant;
  if p_campaign is null then
    insert into public.campaigns (merchant_id, name, goal_type, goal_visits, audience, radius_km, schedule, bonus_points, cpv_iqd, budget_iqd, created_by)
    values (p_merchant, p_draft ->> 'name', p_draft ->> 'goal_type', (p_draft ->> 'goal_visits')::int,
            coalesce(p_draft ->> 'audience', 'all'), coalesce((p_draft ->> 'radius_km')::numeric, 2), coalesce(p_draft -> 'schedule', '{}'::jsonb),
            (p_draft ->> 'bonus_points')::int, coalesce(cpv, 1500), (p_draft ->> 'budget_iqd')::bigint, auth.uid())
    returning id into cid;
  else
    update public.campaigns set name = p_draft ->> 'name', goal_type = p_draft ->> 'goal_type', goal_visits = (p_draft ->> 'goal_visits')::int,
           audience = coalesce(p_draft ->> 'audience', 'all'), radius_km = coalesce((p_draft ->> 'radius_km')::numeric, 2),
           schedule = coalesce(p_draft -> 'schedule', '{}'::jsonb), bonus_points = (p_draft ->> 'bonus_points')::int,
           budget_iqd = (p_draft ->> 'budget_iqd')::bigint
    where id = p_campaign and merchant_id = p_merchant and status = 'draft' returning id into cid;
    if cid is null then perform private.fail('NOT_EDITABLE'); end if;
  end if;
  return cid;
end $$;

create or replace function public.campaign_submit(p_campaign uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare c record;
begin
  select * into c from public.campaigns where id = p_campaign;
  if c.id is null then perform private.fail('NOT_FOUND'); end if;
  perform private.require_member(c.merchant_id, array['owner','manager']);
  if c.status <> 'draft' then perform private.fail('NOT_EDITABLE'); end if;
  update public.campaigns set status = 'pending_approval' where id = p_campaign;
  perform private.audit('campaign_submitted', 'campaign', p_campaign::text);
end $$;

-- AMOUNI approves: funds the campaign points wallet and attaches boosts to the merchant's live spots.
create or replace function public.admin_campaign_decide(p_campaign uuid, p_approve boolean, p_reason text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare actor uuid := private.require_platform(array['ops']); c record; w uuid; pts bigint; days int;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.id is null then perform private.fail('NOT_FOUND'); end if;
  if c.status <> 'pending_approval' then perform private.fail('NOT_PENDING'); end if;
  if not p_approve then
    update public.campaigns set status = 'rejected' where id = p_campaign;
    perform private.audit('campaign_rejected', 'campaign', p_campaign::text, null, null, p_reason);
    return jsonb_build_object('status', 'rejected');
  end if;
  w := private.wallet('campaign', p_campaign);
  pts := c.bonus_points::bigint * c.goal_visits;
  perform private.post_tx('fund', 'campaign', p_campaign::text,
    jsonb_build_array(jsonb_build_object('wallet', private.wallet('amouni_marketing'), 'amount', -pts),
                      jsonb_build_object('wallet', w, 'amount', pts)), actor, 'campaign funding');
  days := coalesce((c.schedule ->> 'days_count')::int, 7);
  update public.campaigns set status = 'running', wallet_id = w, approved_by = actor,
         starts_at = coalesce(starts_at, now()), ends_at = coalesce(ends_at, now() + make_interval(days => days))
  where id = p_campaign returning * into c;
  insert into public.boosts (spot_id, kind, amount, rule, wallet_id, starts_at, ends_at, source)
  select s.id, 'campaign', c.bonus_points, c.schedule || jsonb_build_object('audience', c.audience), w, c.starts_at, c.ends_at, 'campaign'
  from public.spots s join public.branches b on b.id = s.branch_id
  where b.merchant_id = c.merchant_id and s.status = 'live' and s.kind = 'normal';
  perform private.audit('campaign_approved', 'campaign', p_campaign::text, null, jsonb_build_object('points', pts), p_reason);
  return jsonb_build_object('status', 'running', 'points_funded', pts);
end $$;

create or replace function public.campaign_pause(p_campaign uuid, p_pause boolean) returns void
language plpgsql security definer set search_path = '' as $$
declare c record;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.id is null then perform private.fail('NOT_FOUND'); end if;
  if coalesce(private.member_role(c.merchant_id), '') not in ('owner','manager') and not private.has_platform_role(array['ops']) then perform private.fail('FORBIDDEN'); end if;
  if c.status not in ('running','paused') then perform private.fail('NOT_RUNNING'); end if;
  update public.campaigns set status = case when p_pause then 'paused' else 'running' end
  where id = p_campaign and status in ('running','paused');
  update public.boosts set active = not p_pause where wallet_id = c.wallet_id;
  perform private.audit(case when p_pause then 'campaign_paused' else 'campaign_resumed' end, 'campaign', p_campaign::text);
end $$;

-- ---------- analytics / ROI ----------
create or replace function public.merchant_stats(p_merchant uuid, p_days int default 7) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare since timestamptz := now() - make_interval(days => p_days); s jsonb; avg_ticket int; returned int; gen int; cost bigint;
begin
  perform private.require_member(p_merchant, array['owner','manager']);
  select avg_ticket_iqd into avg_ticket from public.merchant_settings where merchant_id = p_merchant;
  select count(*) filter (where generated) into gen from public.visits where merchant_id = p_merchant and verified_at >= since;
  select coalesce(sum(amount_iqd), 0) into cost from public.merchant_charges where merchant_id = p_merchant and created_at >= since;
  -- Of customers AMOUNI generated 30–60 days ago, how many came back within 30 days?
  select count(*) into returned from public.visits g
  where g.merchant_id = p_merchant and g.generated and g.verified_at between now() - interval '60 days' and now() - interval '30 days'
    and exists (select 1 from public.visits r where r.user_id = g.user_id and r.merchant_id = p_merchant
                and r.verified_at > g.verified_at and r.verified_at <= g.verified_at + interval '30 days');
  select jsonb_build_object(
    'generated_visits', gen,
    'verified_visits', (select count(*) from public.visits where merchant_id = p_merchant and verified_at >= since),
    'returning_visits', (select count(*) filter (where not generated) from public.visits where merchant_id = p_merchant and verified_at >= since),
    'scans', (select count(*) from public.scans sc join public.branches b on b.id = sc.branch_id where b.merchant_id = p_merchant and sc.created_at >= since),
    'rejected_scans', (select count(*) from public.scans sc join public.branches b on b.id = sc.branch_id
                       where b.merchant_id = p_merchant and sc.created_at >= since and sc.decision in ('rejected','gate_reject')),
    'redemptions', (select count(*) from public.redemptions r join public.branches b on b.id = r.branch_id where b.merchant_id = p_merchant and r.created_at >= since),
    'campaign_cost_iqd', cost,
    'cost_per_generated_visit_iqd', case when gen > 0 then round(cost::numeric / gen) end,
    'estimated_revenue_iqd', case when avg_ticket is not null then gen * avg_ticket end,
    'return_rate_30d', returned,
    'by_day', coalesce((select jsonb_agg(jsonb_build_object('day', d, 'verified', v, 'generated', g) order by d) from (
        select date_trunc('day', verified_at at time zone 'Asia/Baghdad')::date d, count(*) v, count(*) filter (where generated) g
        from public.visits where merchant_id = p_merchant and verified_at >= since group by 1) x), '[]'::jsonb),
    'quiet_hours', coalesce((select jsonb_agg(h order by h) from (
        select extract(hour from verified_at at time zone 'Asia/Baghdad')::int h, count(*) n
        from public.visits where merchant_id = p_merchant and verified_at > now() - interval '28 days' group by 1) z
        where n < (select avg(n2) * 0.7 from (select count(*) n2 from public.visits where merchant_id = p_merchant
                   and verified_at > now() - interval '28 days' group by extract(hour from verified_at at time zone 'Asia/Baghdad')) a)), '[]'::jsonb)
  ) into s;
  return s;
end $$;
