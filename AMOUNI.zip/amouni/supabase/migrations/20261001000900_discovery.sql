-- =====================================================================
-- AMOUNI · 0009 · Discovery: personalised picks, map, spot details.
-- Rule-based and explainable (every card carries its reason).
-- Mystery spots never reveal which shop they are in until found.
-- =====================================================================

create or replace function private.spot_cards(
  p_user uuid, p_lat float8, p_lng float8, p_radius_m float8, p_category text default null
) returns table (merchant_id uuid, score numeric, card jsonb)
language plpgsql security definer set search_path = '' as $$
declare
  me extensions.geography := extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography;
  r record; q jsonb; km numeric; total int; busy boolean; newcat boolean; aff numeric; sc numeric; reason jsonb;
  mystery boolean; pos extensions.geography; cats jsonb; nvisits int;
begin
  -- Category affinity from the user's own verified visits (no tracking beyond that).
  select coalesce(jsonb_object_agg(category, n), '{}'::jsonb), coalesce(sum(n), 0) into cats, nvisits from (
    select m.category, count(*) n from public.visits v join public.merchants m on m.id = v.merchant_id
    where v.user_id = p_user group by m.category) c;

  for r in
    select s.id, s.kind, s.title_ar, s.qty_left, s.qty_total, s.ends_at, s.mystery_radius_m, s.mystery_center, s.branch_id,
           b.name as branch_name, b.location, b.capacity, b.district_id, m.id as mid, m.display_name, m.category
    from public.spots s join public.branches b on b.id = s.branch_id join public.merchants m on m.id = b.merchant_id
    where s.status = 'live' and b.status = 'active' and m.status = 'active'
      and extensions.st_dwithin(coalesce(s.mystery_center, b.location), me, p_radius_m)
      and (p_category is null or m.category = p_category)
      and private.spot_open(s.id)
      and (p_user is null or not exists (select 1 from public.scans x where x.user_id = p_user and x.spot_id = s.id
                                         and x.decision in ('valid','held','step_up','review')))
      and (p_user is null or not exists (select 1 from public.visits v where v.user_id = p_user and v.branch_id = b.id
                                         and v.verified_at > now() - make_interval(days => private.cfg_int('scan.place_cooldown_days'))))
      and (s.qty_left is null or s.qty_left > 0)
  loop
    mystery := r.kind = 'mystery';
    pos := coalesce(r.mystery_center, r.location);
    km := round((extensions.st_distance(pos, me) / 1000.0)::numeric, 2);
    q := private.compute_quote(p_user, r.id);
    total := (q ->> 'total')::int;
    busy := r.capacity is not null and (select count(*) from public.visits v where v.branch_id = r.branch_id
              and v.verified_at > now() - interval '1 hour') > r.capacity * private.cfg_num('discover.busy_ratio');
    newcat := p_user is not null and not (cats ? r.category);
    aff := case when nvisits > 0 then coalesce((cats ->> r.category)::numeric, 0) / nvisits else 0 end;
    sc := total / (1 + km) + case when newcat then 50 else 0 end + case when (q ->> 'hot')::boolean then 30 else 0 end + aff * 40;
    if busy then sc := sc * 0.5; end if;                       -- traffic balancing: rank lower, never hide

    reason := case
      when km < 0.5 then jsonb_build_object('code', 'near', 'meters', round(km * 1000))
      when (q ->> 'hot')::boolean then jsonb_build_object('code', 'hot')
      when newcat then jsonb_build_object('code', 'new_category', 'category', r.category)
      when aff >= 0.3 then jsonb_build_object('code', 'you_like', 'category', r.category)
      else jsonb_build_object('code', 'points', 'points', total) end;

    merchant_id := r.mid; score := round(sc, 2);
    card := jsonb_build_object(
      'spot_id', r.id, 'kind', r.kind,
      'title_ar', case when mystery then 'فرصة مخفية' else r.title_ar end,
      'merchant', case when mystery then null else r.display_name end,
      'branch', case when mystery then null else r.branch_name end,
      'category', case when mystery then null else r.category end,
      'lat', extensions.st_y(pos::extensions.geometry), 'lng', extensions.st_x(pos::extensions.geometry),
      'circle_m', case when mystery then r.mystery_radius_m end,
      'district_id', r.district_id,
      'distance_m', round(km * 1000), 'walk_min', ceil(km * 1000 / 80),
      'points', total, 'lines', private.public_lines(q -> 'lines'), 'later', q -> 'later', 'hot', (q ->> 'hot')::boolean,
      'qty_left', r.qty_left, 'qty_total', r.qty_total, 'ends_at', r.ends_at,
      'busy', busy, 'reason', reason);
    return next;
  end loop;
end $$;

-- «عندي لك 3 فرص اليوم»: top picks, at most one per merchant.
create or replace function public.discover_picks(p_lat float8, p_lng float8, p_limit int default 3) returns jsonb
language sql security definer set search_path = '' as $$
  with best as (
    select distinct on (merchant_id) merchant_id, score, card
    from private.spot_cards(auth.uid(), p_lat, p_lng, private.cfg_int('discover.radius_km') * 1000.0)
    order by merchant_id, score desc),
  top as (select * from best order by score desc limit least(greatest(p_limit, 1), 10))
  select coalesce(jsonb_agg(card order by score desc), '[]'::jsonb) from top
$$;

create or replace function public.discover_map(p_lat float8, p_lng float8, p_radius_km numeric default 5, p_category text default null) returns jsonb
language sql security definer set search_path = '' as $$
  select coalesce(jsonb_agg(card order by score desc), '[]'::jsonb) from (
    select score, card from private.spot_cards(auth.uid(), p_lat, p_lng, least(p_radius_km, 25) * 1000.0, p_category)
    order by score desc limit 300) x
$$;

-- Spot details + live quote. Records the view (counts toward Generated Visit attribution).
create or replace function public.get_spot(p_spot_id uuid, p_lat float8, p_lng float8) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); c jsonb; s record;
begin
  select card into c from private.spot_cards(uid, p_lat, p_lng, 50000) where (card ->> 'spot_id')::uuid = p_spot_id;
  if c is null then perform private.fail('SPOT_CLOSED'); end if;
  select sp.kind, b.hint_ar, b.hours, r.title_ar as reward into s
  from public.spots sp join public.branches b on b.id = sp.branch_id left join public.rewards r on r.id = sp.instant_reward_id
  where sp.id = p_spot_id;
  if uid is not null then insert into public.spot_views (user_id, spot_id) values (uid, p_spot_id); end if;
  return c || jsonb_build_object('reward_ar', s.reward, 'hours', s.hours,
                                 'hint_ar', null,          -- hints are revealed only after arrival (hunt_hint)
                                 'quote_lock_minutes', private.cfg_int('hunt.quote_lock_minutes'));
end $$;

-- Hint after the user arrived (or 2 minutes into an arrived hunt).
create or replace function public.hunt_hint(p_hunt_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(false); h record;
begin
  select hu.*, b.hint_ar into h from public.hunts hu join public.spots s on s.id = hu.spot_id join public.branches b on b.id = s.branch_id
  where hu.id = p_hunt_id and hu.user_id = uid;
  if h.id is null then perform private.fail('NOT_FOUND'); end if;
  if h.arrived_at is null then return jsonb_build_object('available', false, 'reason', 'not_arrived'); end if;
  return jsonb_build_object('available', true, 'hint_ar', h.hint_ar);
end $$;
