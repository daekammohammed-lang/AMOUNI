-- =====================================================================
-- AMOUNI · 0007 · Wallet, store, redemption, missions, profile
-- =====================================================================

create or replace function public.my_wallet() returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(false);
begin
  return jsonb_build_object(
    'available', (select balance from public.wallets where kind = 'user_available' and owner_id = uid),
    'held',      (select balance from public.wallets where kind = 'user_held' and owner_id = uid),
    'history', coalesce((
      select jsonb_agg(x order by x.at desc) from (
        select t.kind, t.ref_type, t.reason, e.amount, t.created_at as at
        from public.ledger_entries e join public.ledger_tx t on t.id = e.tx_id
        where e.wallet_id in (select id from public.wallets where owner_id = uid and kind in ('user_available','user_held'))
        order by e.id desc limit 30) x), '[]'::jsonb));
end $$;

create or replace function public.complete_profile(p_name text, p_city uuid, p_invite_code text default null) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); inv uuid;
begin
  if p_name is null or length(btrim(p_name)) < 2 or length(p_name) > 40 then perform private.fail('BAD_NAME'); end if;
  if p_invite_code is not null and length(btrim(p_invite_code)) > 0 then
    select id into inv from public.profiles where invite_code = upper(btrim(p_invite_code)) and id <> uid;
    if inv is null then perform private.fail('BAD_INVITE'); end if;
  end if;
  update public.profiles set display_name = btrim(p_name), city_id = p_city,
         invited_by = coalesce(invited_by, inv) where id = uid;
  perform private.event('profile_completed', uid, jsonb_build_object('invited', inv is not null));
  return jsonb_build_object('ok', true);
end $$;

-- ---------- points store ----------
create or replace function public.buy_reward(p_reward_id uuid, p_idem text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); rw record; bid uuid; existing uuid;
begin
  select id into existing from public.bag_items where user_id = uid and source = 'store' and source_ref = 'buy:' || p_idem;
  if existing is not null then return jsonb_build_object('bag_item_id', existing, 'idempotent', true); end if;

  if p_idem is null or length(p_idem) < 8 then perform private.fail('BAD_REQUEST'); end if;
  begin
    update public.rewards set stock = stock - 1
    where id = p_reward_id and active and cost_points is not null and stock > 0
    returning * into rw;
    if rw.id is null then perform private.fail('OUT_OF_STOCK'); end if;
    insert into public.bag_items (user_id, reward_id, source, source_ref, status, expires_at)
    values (uid, rw.id, 'store', 'buy:' || p_idem, 'available', now() + make_interval(days => rw.validity_days))
    returning id into bid;
  exception when unique_violation then   -- a concurrent retry with the same key already bought it
    select id into existing from public.bag_items where user_id = uid and source = 'store' and source_ref = 'buy:' || p_idem;
    return jsonb_build_object('bag_item_id', existing, 'idempotent', true);
  end;

  -- Fails with INSUFFICIENT_POINTS (whole purchase rolls back) if the balance is too low.
  perform private.post_tx('spend', 'bag_item', bid::text,
    jsonb_build_array(jsonb_build_object('wallet', private.wallet('user_available', uid), 'amount', -rw.cost_points),
                      jsonb_build_object('wallet', private.wallet('store_sink'), 'amount', rw.cost_points)),
    uid, rw.title_ar);
  perform private.event('reward_bought', uid, jsonb_build_object('reward', rw.id, 'cost', rw.cost_points));
  return jsonb_build_object('bag_item_id', bid, 'title_ar', rw.title_ar, 'cost', rw.cost_points);
end $$;

-- ---------- redemption ----------
-- The user opens a reward → gets a 6-digit code + QR valid 60 s, single use.
create or replace function public.issue_redeem_token(p_bag_item_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); b record; v_code text; sec text; tid uuid; exp timestamptz; tries int := 0;
begin
  select bi.*, r.merchant_id into b from public.bag_items bi join public.rewards r on r.id = bi.reward_id
  where bi.id = p_bag_item_id and bi.user_id = uid;
  if b.id is null then perform private.fail('NOT_FOUND'); end if;
  if b.status <> 'available' then perform private.fail('NOT_AVAILABLE', b.status); end if;
  if b.expires_at < now() then perform private.fail('EXPIRED'); end if;

  update private.redeem_tokens set used_at = now() where bag_item_id = b.id and used_at is null;   -- one live code per item
  exp := now() + make_interval(secs => private.cfg_int('redeem.token_seconds'));
  loop
    v_code := lpad((abs((('x' || encode(extensions.gen_random_bytes(4), 'hex'))::bit(32)::int)::bigint) % 1000000)::text, 6, '0');
    exit when not exists (select 1 from private.redeem_tokens where merchant_id = b.merchant_id and code = v_code and used_at is null and expires_at > now());
    tries := tries + 1; if tries > 10 then perform private.fail('TRY_AGAIN'); end if;
  end loop;
  sec := private.random_base62(20);
  insert into private.redeem_tokens (bag_item_id, merchant_id, code, qr_secret, expires_at)
  values (b.id, b.merchant_id, v_code, sec, exp) returning id into tid;
  return jsonb_build_object('code', v_code, 'qr', 'AMR1.' || tid::text || '.' || sec, 'expires_at', exp);
end $$;

-- Staff confirms a redemption by scanning the user's QR or typing the code.
create or replace function public.merchant_redeem(p_branch_id uuid, p_input text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := private.require_user(); br record; tk record; b record; m text[]; method text; rw record;
begin
  select * into br from public.branches where id = p_branch_id;
  if br.id is null then perform private.fail('NOT_FOUND'); end if;
  perform private.require_member(br.merchant_id, array['owner','manager','cashier'], br.id);
  if not private.rate_ok('redeem:' || uid::text, 20) then perform private.fail('RATE_LIMITED'); end if;

  p_input := btrim(coalesce(p_input, ''));
  m := regexp_match(p_input, '^AMR1\.([0-9a-f-]{36})\.([A-Za-z0-9]{20})$');
  if m is not null then
    method := 'qr';
    select * into tk from private.redeem_tokens where id = m[1]::uuid and qr_secret = m[2] for update;
  elsif p_input ~ '^[0-9]{6}$' then
    method := 'code';
    select * into tk from private.redeem_tokens where merchant_id = br.merchant_id and code = p_input
      and used_at is null and expires_at > now() order by created_at desc limit 1 for update;
  end if;
  -- Same answer for "wrong merchant", "expired" and "unknown": staff cannot probe other merchants' codes.
  if tk.id is null or tk.merchant_id <> br.merchant_id or tk.expires_at < now() then perform private.fail('CODE_INVALID'); end if;
  if tk.used_at is not null then perform private.fail('CODE_USED'); end if;

  select * into b from public.bag_items where id = tk.bag_item_id for update;
  if b.status = 'redeemed' then perform private.fail('ALREADY_REDEEMED'); end if;
  if b.status <> 'available' or b.expires_at < now() then perform private.fail('NOT_AVAILABLE'); end if;
  select * into rw from public.rewards where id = b.reward_id;
  if rw.branch_ids is not null and not (br.id = any(rw.branch_ids)) then perform private.fail('WRONG_BRANCH'); end if;

  update private.redeem_tokens set used_at = now() where id = tk.id;
  insert into public.redemptions (bag_item_id, staff_user_id, branch_id, method) values (b.id, uid, br.id, method);
  update public.bag_items set status = 'redeemed' where id = b.id;
  perform private.event('reward_redeemed', b.user_id, jsonb_build_object('reward', rw.id, 'branch', br.id, 'method', method));
  return jsonb_build_object('ok', true, 'title_ar', rw.title_ar,
                            'customer', (select split_part(coalesce(display_name, ''), ' ', 1) from public.profiles where id = b.user_id));
end $$;

-- ---------- missions ----------
create or replace function private.mission_progress(p_user uuid, p_mission uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare ms record; tz text; since timestamptz; v_period text; n int := 0;
begin
  select * into ms from public.missions where id = p_mission and active;
  if ms.id is null then return null; end if;
  select coalesce(c.timezone, 'Asia/Baghdad') into tz from public.profiles p left join public.cities c on c.id = p.city_id where p.id = p_user;
  tz := coalesce(tz, 'Asia/Baghdad');
  if ms.kind = 'daily' then
    since := private.local_day_start(tz); v_period := to_char(since at time zone tz, 'YYYY-MM-DD');
  else
    since := private.local_week_start(tz); v_period := 'W' || to_char(since at time zone tz, 'YYYY-MM-DD');
  end if;
  if ms.rule ->> 'metric' = 'new_merchants' then
    -- merchants whose FIRST ever verified visit by this user happened in the period
    select count(*) into n from (
      select merchant_id, min(verified_at) first_at from public.visits where user_id = p_user group by merchant_id) f
    where f.first_at >= since;
  elsif ms.rule ->> 'metric' = 'distinct_branches' then
    select count(distinct branch_id) into n from public.visits where user_id = p_user and verified_at >= since;
  end if;
  return jsonb_build_object('mission_id', ms.id, 'code', ms.code, 'kind', ms.kind, 'title_ar', ms.title_ar,
    'target', (ms.rule ->> 'target')::int, 'progress', least(n, (ms.rule ->> 'target')::int), 'reward_points', ms.reward_points,
    'period', v_period, 'claimed', exists (select 1 from public.mission_claims mc where mc.user_id = p_user and mc.mission_id = ms.id and mc.period = v_period),
    'ends_at', case when ms.kind = 'daily' then since + interval '1 day' else since + interval '7 days' end);
end $$;

create or replace function public.my_missions() returns jsonb
language sql security definer set search_path = '' as $$
  select coalesce(jsonb_agg(private.mission_progress(private.require_user(false), m.id) order by m.kind), '[]'::jsonb)
  from public.missions m where m.active
$$;

create or replace function public.claim_mission(p_mission_id uuid) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); p jsonb;
begin
  p := private.mission_progress(uid, p_mission_id);
  if p is null then perform private.fail('NOT_FOUND'); end if;
  if (p ->> 'progress')::int < (p ->> 'target')::int then perform private.fail('NOT_COMPLETE'); end if;
  begin
    insert into public.mission_claims (user_id, mission_id, period) values (uid, p_mission_id, p ->> 'period');
  exception when unique_violation then perform private.fail('ALREADY_CLAIMED');
  end;
  perform private.post_tx('mission', 'mission_claim', uid::text || ':' || p_mission_id::text || ':' || (p ->> 'period'),
    jsonb_build_array(jsonb_build_object('wallet', private.wallet('amouni_marketing'), 'amount', -(p ->> 'reward_points')::int),
                      jsonb_build_object('wallet', private.wallet('user_available', uid), 'amount', (p ->> 'reward_points')::int)),
    uid, p ->> 'title_ar');
  perform private.event('mission_claimed', uid, jsonb_build_object('mission', p_mission_id));
  return jsonb_build_object('ok', true, 'points', (p ->> 'reward_points')::int);
end $$;

-- ---------- discovery progress (fog of war) ----------
create or replace function public.my_discovery(p_city uuid) returns jsonb
language sql security definer set search_path = '' as $$
  with me as (select private.require_user(false) as uid),
  d as (
    select dd.id, dd.name_ar,
           count(distinct b.id) filter (where b.status = 'active' and m.status = 'active') as places,
           count(distinct v.branch_id) as discovered
    from public.districts dd
    left join public.branches b on b.district_id = dd.id
    left join public.merchants m on m.id = b.merchant_id
    left join public.visits v on v.branch_id = b.id and v.user_id = (select uid from me)
    where dd.city_id = p_city
    group by dd.id, dd.name_ar)
  select jsonb_build_object(
    'districts', coalesce(jsonb_agg(jsonb_build_object('id', id, 'name_ar', name_ar, 'places', places, 'discovered', discovered) order by name_ar), '[]'::jsonb),
    'places', coalesce(sum(places), 0), 'discovered', coalesce(sum(discovered), 0))
  from d
$$;
