-- =====================================================================
-- AMOUNI · 0002 · Domain model
-- Places, people, merchants, spots, QR, hunts, scans, visits.
-- =====================================================================

-- ---------- geography ----------
create table public.cities (
  id        uuid primary key default gen_random_uuid(),
  slug      text unique not null,
  name_ar   text not null,
  name_en   text not null,
  name_ku   text,
  timezone  text not null default 'Asia/Baghdad',
  centroid  extensions.geography(point, 4326) not null,
  active    boolean not null default false
);

create table public.districts (
  id        uuid primary key default gen_random_uuid(),
  city_id   uuid not null references public.cities(id),
  name_ar   text not null,
  name_en   text,
  centroid  extensions.geography(point, 4326) not null,
  unique (city_id, name_ar)
);

-- ---------- people ----------
create table public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  phone         text unique not null,
  display_name  text,
  city_id       uuid references public.cities(id),
  locale        text not null default 'ar' check (locale in ('ar','en','ku')),
  status        text not null default 'active' check (status in ('active','limited','banned')),
  account_trust int  not null default 80 check (account_trust between 0 and 100),
  xp            int  not null default 0 check (xp >= 0),
  invite_code   text unique not null default private.random_short_code(),
  invited_by    uuid references public.profiles(id),
  created_at    timestamptz not null default now()
);

-- Platform staff roles. Merchant roles live in merchant_members.
create table public.platform_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role    text not null check (role in ('super_admin','ops','fraud_analyst','finance','support')),
  granted_by uuid references public.profiles(id),
  granted_at timestamptz not null default now(),
  primary key (user_id, role)
);

create table public.devices (
  id               uuid primary key default gen_random_uuid(),
  user_id          uuid not null references public.profiles(id) on delete cascade,
  fingerprint_hash bytea not null,
  platform         text not null default 'web' check (platform in ('web','ios','android')),
  integrity        text not null default 'unknown' check (integrity in ('unknown','passed','failed')),
  first_seen       timestamptz not null default now(),
  last_seen        timestamptz not null default now(),
  unique (user_id, fingerprint_hash)
);
create index devices_fingerprint_idx on public.devices (fingerprint_hash);

-- ---------- merchants ----------
create table public.merchants (
  id            uuid primary key default gen_random_uuid(),
  display_name  text not null,
  legal_name    text,
  category      text not null check (category in ('coffee','food','sweets','juice','mall','fitness','beauty','fun','books','retail','services')),
  status        text not null default 'pending' check (status in ('pending','active','suspended','rejected')),
  plan          text not null default 'basic' check (plan in ('free','basic','silver','gold')),
  logo_path     text,
  reject_reason text,
  created_by    uuid not null references public.profiles(id),
  created_at    timestamptz not null default now()
);

-- Business numbers the merchant shares only with AMOUNI (used for ROI).
create table public.merchant_settings (
  merchant_id     uuid primary key references public.merchants(id) on delete cascade,
  avg_ticket_iqd  int check (avg_ticket_iqd is null or avg_ticket_iqd > 0),
  cpv_iqd         int check (cpv_iqd is null or cpv_iqd >= 0),   -- price per Generated Visit for campaigns
  notes           text
);

create table public.branches (
  id           uuid primary key default gen_random_uuid(),
  merchant_id  uuid not null references public.merchants(id) on delete cascade,
  city_id      uuid not null references public.cities(id),
  district_id  uuid references public.districts(id),
  name         text not null,
  address      text,
  location     extensions.geography(point, 4326) not null,
  geofence_m   int  not null default 60 check (geofence_m between 15 and 500),
  hours        jsonb not null default '{}'::jsonb,   -- {"0":[["09:00","24:00"]], ...} 0 = Sunday, city local time
  capacity     int check (capacity is null or capacity > 0),
  hint_ar      text,
  cashier_mode boolean not null default false,        -- has a cashier screen able to show dynamic QR (enables step-up)
  status       text not null default 'active' check (status in ('active','paused','closed')),
  public_id    text unique not null default private.random_base62(10),  -- appears in dynamic QR URLs
  created_at   timestamptz not null default now()
);
create index branches_location_idx on public.branches using gist (location);
create index branches_merchant_idx on public.branches (merchant_id);

create table private.branch_secrets (
  branch_id      uuid primary key references public.branches(id) on delete cascade,
  dynamic_secret bytea not null default extensions.gen_random_bytes(32),
  rotated_at     timestamptz not null default now()
);

create table public.merchant_members (
  merchant_id uuid not null references public.merchants(id) on delete cascade,
  user_id     uuid not null references public.profiles(id) on delete cascade,
  role        text not null check (role in ('owner','manager','cashier')),
  branch_id   uuid references public.branches(id) on delete cascade,  -- null = all branches
  active      boolean not null default true,
  added_by    uuid references public.profiles(id),
  added_at    timestamptz not null default now(),
  primary key (merchant_id, user_id)
);
create index merchant_members_user_idx on public.merchant_members (user_id) where active;

-- ---------- rewards ----------
create table public.rewards (
  id               uuid primary key default gen_random_uuid(),
  merchant_id      uuid not null references public.merchants(id),
  title_ar         text not null,
  description_ar   text,
  image_path       text,
  value_iqd        int  not null check (value_iqd >= 0),          -- admin/merchant only
  cost_points      int  check (cost_points is null or cost_points > 0),  -- store price, set by AMOUNI; null = instant-only
  stock            int  not null check (stock >= 0),
  validity_days    int  not null default 14 check (validity_days between 1 and 365),
  terms_ar         text,
  branch_ids       uuid[],                                         -- null = all branches
  active           boolean not null default true,
  created_at       timestamptz not null default now()
);

-- ---------- campaigns ----------
create table public.campaigns (
  id             uuid primary key default gen_random_uuid(),
  merchant_id    uuid not null references public.merchants(id),
  name           text not null,
  goal_type      text not null check (goal_type in ('new_visits','quiet_hours','win_back','new_branch')),
  goal_visits    int  not null check (goal_visits between 10 and 5000),
  audience       text not null default 'all' check (audience in ('all','new','lapsed')),
  radius_km      numeric(4,1) not null default 2 check (radius_km between 0.5 and 25),
  schedule       jsonb not null default '{}'::jsonb,    -- {"days":[0..6],"from":"17:00","to":"22:00"}
  bonus_points   int  not null check (bonus_points between 10 and 500),
  instant_reward_id uuid references public.rewards(id),
  cpv_iqd        int  not null check (cpv_iqd >= 0),     -- agreed price per Generated Visit
  budget_iqd     bigint not null check (budget_iqd > 0),
  spent_iqd      bigint not null default 0,
  generated_visits int not null default 0,
  status         text not null default 'draft'
                 check (status in ('draft','pending_approval','scheduled','running','paused','completed','cancelled','rejected')),
  starts_at      timestamptz,
  ends_at        timestamptz,
  approved_by    uuid references public.profiles(id),
  wallet_id      uuid,                                    -- points budget, set on approval
  created_by     uuid not null references public.profiles(id),
  created_at     timestamptz not null default now(),
  check (spent_iqd <= budget_iqd),
  check (ends_at is null or starts_at is null or ends_at > starts_at)
);

-- ---------- spots ("فرصة") ----------
create table public.spots (
  id                uuid primary key default gen_random_uuid(),
  branch_id         uuid not null references public.branches(id),
  campaign_id       uuid references public.campaigns(id),
  title_ar          text not null,
  kind              text not null default 'normal' check (kind in ('normal','golden_drop','first_finder','mystery')),
  base_points       int  not null check (base_points between 0 and 5000),
  cap_points        int  not null default 500 check (cap_points > 0),
  instant_reward_id uuid references public.rewards(id),
  qty_total         int  check (qty_total is null or qty_total > 0),
  qty_left          int  check (qty_left is null or qty_left >= 0),                 -- never negative
  requires_dynamic  boolean not null default false,  -- Golden Drops: only the cashier screen QR counts
  mystery_radius_m  int  check (mystery_radius_m is null or mystery_radius_m between 50 and 1000),
  mystery_center    extensions.geography(point, 4326),
  hours_override    jsonb,
  status            text not null default 'draft' check (status in ('draft','scheduled','live','paused','ended')),
  starts_at         timestamptz not null default now(),
  ends_at           timestamptz,
  created_at        timestamptz not null default now(),
  check ((qty_total is null) = (qty_left is null)),
  check (qty_left is null or qty_left <= qty_total),
  check (kind <> 'mystery' or (mystery_radius_m is not null and mystery_center is not null))
);
create index spots_live_idx on public.spots (status, starts_at) where status = 'live';
create index spots_branch_idx on public.spots (branch_id);

create table public.boosts (
  id         uuid primary key default gen_random_uuid(),
  spot_id    uuid not null references public.spots(id) on delete cascade,
  kind       text not null check (kind in ('time','new_customer','campaign','quiet_place','new_location','mission','streak')),
  amount     int  not null check (amount between 1 and 500),
  rule       jsonb not null default '{}'::jsonb,   -- time: {"from":"15:00","to":"18:00","days":[...]}
  wallet_id  uuid,                                 -- who pays; null = AMOUNI marketing
  active     boolean not null default true,
  starts_at  timestamptz not null default now(),
  ends_at    timestamptz,
  source     text not null default 'merchant' check (source in ('merchant','campaign','system','ai')),
  created_at timestamptz not null default now()
);
create index boosts_spot_idx on public.boosts (spot_id) where active;

-- ---------- QR ----------
create table public.qr_codes (
  id             uuid primary key default gen_random_uuid(),
  branch_id      uuid not null references public.branches(id),
  campaign_id    uuid references public.campaigns(id),
  label          text not null default 'الكاشير',
  short_code     extensions.citext unique not null default private.random_short_code(),
  status         text not null default 'active' check (status in ('active','grace','disabled')),
  grace_until    timestamptz,
  rotation       text not null default 'monthly' check (rotation in ('fixed','weekly','monthly','campaign')),
  next_rotation_at timestamptz,
  replaced_by    uuid references public.qr_codes(id),
  disabled_reason text,
  scans_count    int not null default 0,
  created_by     uuid references public.profiles(id),
  created_at     timestamptz not null default now()
);
create index qr_codes_branch_idx on public.qr_codes (branch_id, status);

-- The printed token is derived from a server master key (so a lost poster can be re-printed)
-- and only its hash is stored for lookup. Leaking this table does not leak printable tokens.
create table private.qr_tokens (
  qr_id       uuid primary key references public.qr_codes(id) on delete cascade,
  token_hash  bytea unique not null
);

-- ---------- hunts ----------
create table public.point_quotes (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references public.profiles(id),
  spot_id    uuid not null references public.spots(id),
  total      int  not null check (total >= 0),
  lines      jsonb not null,           -- [{"kind":"base","label_ar":"الأساس","points":100,"wallet":"<uuid>"}...]
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);

create table public.hunts (
  id          uuid primary key default gen_random_uuid(),
  user_id     uuid not null references public.profiles(id),
  spot_id     uuid not null references public.spots(id),
  quote_id    uuid not null references public.point_quotes(id),
  device_id   uuid references public.devices(id),
  status      text not null default 'active' check (status in ('active','completed','expired','cancelled')),
  start_location extensions.geography(point, 4326),
  started_at  timestamptz not null default now(),
  expires_at  timestamptz not null,
  arrived_at  timestamptz,
  completed_at timestamptz
);
create unique index hunts_one_open_per_spot on public.hunts (user_id, spot_id) where status in ('active','completed');
create index hunts_user_idx on public.hunts (user_id, started_at desc);

-- One-time scan nonce bound to hunt + device (replay protection).
create table private.hunt_nonces (
  hunt_id    uuid primary key references public.hunts(id) on delete cascade,
  nonce_hash bytea not null,
  used_at    timestamptz
);

-- Movement trail while hunting (privacy: only during an active hunt; purged after 90 days).
create table public.location_pings (
  id          bigserial primary key,
  hunt_id     uuid not null references public.hunts(id) on delete cascade,
  user_id     uuid not null references public.profiles(id),
  location    extensions.geography(point, 4326) not null,
  accuracy_m  real not null,
  recorded_at timestamptz not null default now()
);
create index location_pings_hunt_idx on public.location_pings (hunt_id, recorded_at);

create table public.spot_views (
  user_id   uuid not null references public.profiles(id),
  spot_id   uuid not null references public.spots(id),
  viewed_at timestamptz not null default now()
);
create index spot_views_idx on public.spot_views (user_id, spot_id, viewed_at desc);

-- ---------- scans ----------
create table public.scans (
  id              uuid primary key default gen_random_uuid(),
  idempotency_key text not null,
  user_id         uuid not null references public.profiles(id),
  hunt_id         uuid references public.hunts(id),
  spot_id         uuid references public.spots(id),
  branch_id       uuid references public.branches(id),
  qr_id           uuid references public.qr_codes(id),
  input_kind      text check (input_kind in ('static','dynamic','short_code')),
  location        extensions.geography(point, 4326),
  accuracy_m      real,
  distance_m      real,
  device_id       uuid references public.devices(id),
  ip              inet,
  trust_score     int check (trust_score between 0 and 100),
  decision        text not null check (decision in ('valid','held','step_up','review','rejected','gate_reject')),
  result_code     text not null,
  points          int not null default 0,
  quote_id        uuid references public.point_quotes(id),
  step_up_until   timestamptz,
  resolved_at     timestamptz,
  resolved_by     uuid references public.profiles(id),
  resolution_note text,
  created_at      timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
-- A user can hold at most one non-rejected scan per spot: no double points, ever.
create unique index scans_one_success_per_spot on public.scans (user_id, spot_id)
  where decision in ('valid','held','step_up','review');
create index scans_user_time_idx   on public.scans (user_id, created_at desc);
create index scans_branch_time_idx on public.scans (branch_id, created_at desc);
create index scans_qr_time_idx     on public.scans (qr_id, created_at desc);
create index scans_pending_idx     on public.scans (decision, created_at) where decision in ('held','step_up','review');

create table public.scan_signals (
  scan_id  uuid not null references public.scans(id) on delete cascade,
  signal   text not null,
  points   int  not null,
  evidence jsonb not null default '{}'::jsonb,
  primary key (scan_id, signal)
);

create table private.trust_weights (
  signal      text primary key,
  points      int  not null check (points between 0 and 100),
  description text not null
);
insert into private.trust_weights values
  ('location_edge',          20, 'Between geofence and 2× geofence (big buildings, malls).'),
  ('gps_accuracy',           10, 'Reported accuracy worse than 100 m.'),
  ('no_session',              5, 'Scan without an active hunt for this spot.'),
  ('no_trail',               10, 'Hunt active but no location fixes on the way.'),
  ('arrival_too_fast',       25, 'Arrived faster than plausible city travel from the hunt start point.'),
  ('impossible_travel',      50, 'Previous scan elsewhere implies > 120 km/h.'),
  ('velocity',               25, 'More than 4 verified visits in 30 minutes.'),
  ('shared_device',          25, 'Device fingerprint used by more than 2 accounts in 30 days.'),
  ('new_account_high_value', 20, 'Account younger than 24 h scanning a spot worth ≥ 300 points.'),
  ('qr_leak_suspect',        30, 'This QR has far-away scans in the last hour.'),
  ('collusion',              10, 'Same user at the same merchant more than 3 times in 7 days.'),
  ('low_account_trust',      15, 'Rolling account trust below 50.'),
  ('vpn_datacenter',         10, 'Request from a VPN / hosting IP range (edge-provided).'),
  ('mock_location',          50, 'Native app detected mock location (edge-provided).'),
  ('device_integrity_fail',  40, 'Play Integrity / App Attest failed (edge-provided).');

create table public.visits (
  id          uuid primary key default gen_random_uuid(),
  scan_id     uuid unique not null references public.scans(id),
  user_id     uuid not null references public.profiles(id),
  branch_id   uuid not null references public.branches(id),
  merchant_id uuid not null references public.merchants(id),
  spot_id     uuid not null references public.spots(id),
  campaign_id uuid references public.campaigns(id),
  generated   boolean not null,
  verified_at timestamptz not null default now()
);
create index visits_merchant_time_idx on public.visits (merchant_id, verified_at desc);
create index visits_user_merchant_idx on public.visits (user_id, merchant_id, verified_at desc);
create index visits_branch_time_idx   on public.visits (branch_id, verified_at desc);

-- Per-user rate limit buckets (scan attempts per minute).
create table private.rate_buckets (
  key          text not null,
  window_start timestamptz not null,
  hits         int not null default 0,
  primary key (key, window_start)
);
