-- =====================================================================
-- AMOUNI · 0012 · Helpers for the edge (API) layer.
-- =====================================================================
create or replace function public.edge_rate_ok(p_key text, p_limit int, p_window_seconds int default 60) returns boolean
language sql security definer set search_path = '' as $$
  select private.rate_ok('edge:' || p_key, p_limit, p_window_seconds)
$$;
revoke all on function public.edge_rate_ok(text, int, int) from public, anon, authenticated;
grant execute on function public.edge_rate_ok(text, int, int) to service_role;
