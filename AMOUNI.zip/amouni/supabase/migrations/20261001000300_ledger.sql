-- =====================================================================
-- AMOUNI · 0003 · Points ledger (double-entry)
--
-- Every point that reaches a user comes out of a funding wallet
-- (AMOUNI marketing, a merchant campaign, ...). Each transaction is a set
-- of entries that sums to zero. Balances are derived by trigger only;
-- nothing can UPDATE a balance or DELETE history.
--
--   user scans (valid):   marketing -100, campaign -50, user_available +150
--   user scans (held):    marketing -100, campaign -50, user_held      +150
--   hold released:        user_held -150, user_available +150
--   hold reversed:        user_held -150, marketing +100, campaign +50
--   store purchase:       user_available -400, store_sink +400
-- =====================================================================

create table public.wallets (
  id             uuid primary key default gen_random_uuid(),
  kind           text not null check (kind in (
                   'user_available','user_held',        -- per user
                   'campaign',                          -- per campaign (merchant-funded points budget)
                   'amouni_marketing',                  -- AMOUNI-funded issuance (base, discovery, missions)
                   'amouni_rewards_fund',               -- monthly achievement prizes
                   'store_sink','expiry_sink','reversal_sink')),
  owner_id       uuid,                                  -- user id / campaign id / null for platform wallets
  balance        bigint not null default 0,
  allow_negative boolean not null default false,        -- only issuance wallets
  created_at     timestamptz not null default now(),
  unique nulls not distinct (kind, owner_id),
  check (allow_negative or balance >= 0)
);

create table public.ledger_tx (
  id         uuid primary key default gen_random_uuid(),
  kind       text not null check (kind in ('earn','hold','release','reverse','spend','refund','expire','adjust','mission','fund','bonus')),
  ref_type   text not null,          -- 'scan','bag_item','mission_claim','campaign','admin_adjust',...
  ref_id     text not null,
  actor_id   uuid,                   -- user/admin who caused it; null = system job
  reason     text,
  metadata   jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique (kind, ref_type, ref_id)    -- idempotent: the same event can never post twice
);

create table public.ledger_entries (
  id         bigserial primary key,
  tx_id      uuid not null references public.ledger_tx(id),
  wallet_id  uuid not null references public.wallets(id),
  amount     bigint not null check (amount <> 0),
  created_at timestamptz not null default now()
);
create index ledger_entries_wallet_idx on public.ledger_entries (wallet_id, id desc);
create index ledger_entries_tx_idx on public.ledger_entries (tx_id);

-- Balance maintenance: the ONLY place balances change.
create or replace function private.apply_entry() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  update public.wallets set balance = balance + new.amount where id = new.wallet_id;
  return new;
exception when check_violation then
  perform private.fail('INSUFFICIENT_POINTS', new.wallet_id::text);
end $$;
create trigger ledger_entries_apply after insert on public.ledger_entries
  for each row execute function private.apply_entry();

-- Zero-sum check at commit time.
create or replace function private.check_tx_balanced() returns trigger
language plpgsql security definer set search_path = '' as $$
declare s bigint;
begin
  select coalesce(sum(amount), 0) into s from public.ledger_entries where tx_id = new.tx_id;
  if s <> 0 then raise exception 'AMOUNI:LEDGER_UNBALANCED tx % sums to %', new.tx_id, s; end if;
  return null;
end $$;
create constraint trigger ledger_entries_balanced after insert on public.ledger_entries
  deferrable initially deferred for each row execute function private.check_tx_balanced();

-- History is append-only.
create or replace function private.forbid_mutation() returns trigger
language plpgsql as $$
begin
  raise exception 'AMOUNI:APPEND_ONLY % on %', tg_op, tg_table_name;
end $$;
create trigger ledger_tx_append_only before update or delete on public.ledger_tx
  for each row execute function private.forbid_mutation();
create trigger ledger_entries_append_only before update or delete on public.ledger_entries
  for each row execute function private.forbid_mutation();

-- Platform wallets (singletons).
insert into public.wallets (kind, owner_id, allow_negative) values
  ('amouni_marketing',    null, true),
  ('amouni_rewards_fund', null, true),
  ('store_sink',          null, false),
  ('expiry_sink',         null, false),
  ('reversal_sink',       null, false);

create or replace function private.wallet(p_kind text, p_owner uuid default null) returns uuid
language plpgsql security definer set search_path = '' as $$
declare w uuid;
begin
  select id into w from public.wallets where kind = p_kind and owner_id is not distinct from p_owner;
  if w is null then
    insert into public.wallets (kind, owner_id) values (p_kind, p_owner)
    on conflict (kind, owner_id) do nothing
    returning id into w;
    if w is null then
      select id into w from public.wallets where kind = p_kind and owner_id is not distinct from p_owner;
    end if;
  end if;
  return w;
end $$;

-- Post one balanced transaction. p_entries: [{"wallet":"<uuid>","amount":-100}, ...]
-- Returns the tx id; re-posting the same (kind, ref_type, ref_id) is a no-op that returns the original id.
create or replace function private.post_tx(
  p_kind text, p_ref_type text, p_ref_id text, p_entries jsonb,
  p_actor uuid default null, p_reason text default null, p_meta jsonb default '{}'::jsonb
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  t uuid; e jsonb;
begin
  insert into public.ledger_tx (kind, ref_type, ref_id, actor_id, reason, metadata)
  values (p_kind, p_ref_type, p_ref_id, p_actor, p_reason, coalesce(p_meta, '{}'::jsonb))
  on conflict (kind, ref_type, ref_id) do nothing
  returning id into t;
  if t is null then
    select id into t from public.ledger_tx where kind = p_kind and ref_type = p_ref_type and ref_id = p_ref_id;
    return t;
  end if;
  for e in select * from jsonb_array_elements(p_entries) loop
    if (e ->> 'amount')::bigint <> 0 then
      insert into public.ledger_entries (tx_id, wallet_id, amount)
      values (t, (e ->> 'wallet')::uuid, (e ->> 'amount')::bigint);
    end if;
  end loop;
  return t;
end $$;

-- Outstanding user points (available + held) — the liability AMOUNI must cover with rewards.
create or replace view private.points_liability as
  select coalesce(sum(balance), 0)::bigint as outstanding
  from public.wallets where kind in ('user_available','user_held');
