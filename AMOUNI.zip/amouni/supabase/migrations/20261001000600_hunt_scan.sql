-- =====================================================================
-- AMOUNI · 0006 · Hunts, scan pipeline, proof of presence, step-up,
-- hold/review resolution, visits, campaign charging, leak detection.
-- =====================================================================

-- ---------------------------------------------------------------------
-- start_hunt — called by the app when the user taps «ابدأ».
-- Locks the points quote, opens a hunt and returns a one-time scan nonce.
-- ---------------------------------------------------------------------
create or replace function public.start_hunt(
  p_spot_id uuid, p_lat float8 default null, p_lng float8 default null,
  p_accuracy real default null, p_device_fp text default null, p_platform text default 'web'
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  uid uuid := private.require_user();
  prof record; sp record; h record; q jsonb; qid uuid; nonce text; dev uuid; hid uuid; tz text;
begin
  select * into prof from public.profiles where id = uid;
  -- The start point feeds the arrival-plausibility signals; a hunt cannot start without it.
  if p_lat is null or p_lng is null then perform private.fail('NO_LOCATION'); end if;

  select s.*, b.merchant_id, b.id as br_id into sp from public.spots s join public.branches b on b.id = s.branch_id where s.id = p_spot_id;
  if sp.id is null or not private.spot_open(p_spot_id) then perform private.fail('SPOT_CLOSED'); end if;
  if exists (select 1 from public.scans where user_id = uid and spot_id = p_spot_id and decision in ('valid','held','step_up','review')) then
    perform private.fail('ALREADY_FOUND');
  end if;
  if exists (select 1 from public.visits where user_id = uid and branch_id = sp.br_id
             and verified_at > now() - make_interval(days => private.cfg_int('scan.place_cooldown_days'))) then
    perform private.fail('PLACE_COOLDOWN');
  end if;
  if sp.qty_left = 0 then perform private.fail('SOLD_OUT'); end if;

  -- Expire stale hunts; one active hunt at a time (starting another cancels the previous one).
  update public.hunts set status = 'expired' where user_id = uid and status = 'active' and expires_at <= now();
  update public.hunts set status = 'cancelled' where user_id = uid and status = 'active' and spot_id <> p_spot_id;

  dev := private.device_id(uid, p_device_fp, p_platform);
  nonce := private.random_base62(24);

  select * into h from public.hunts where user_id = uid and spot_id = p_spot_id and status = 'active';
  if h.id is not null then
    -- Resume: same locked quote, fresh nonce (the client may have lost it).
    update private.hunt_nonces set nonce_hash = private.sha256(nonce), used_at = null where hunt_id = h.id;
    select jsonb_build_object('total', total, 'lines', private.public_lines(lines)) into q from public.point_quotes where id = h.quote_id;
    return jsonb_build_object('hunt_id', h.id, 'quote', q, 'expires_at', h.expires_at, 'nonce', nonce, 'resumed', true);
  end if;

  q := private.compute_quote(uid, p_spot_id);
  insert into public.point_quotes (user_id, spot_id, total, lines, expires_at)
  values (uid, p_spot_id, (q ->> 'total')::int, q -> 'lines', now() + make_interval(mins => private.cfg_int('hunt.quote_lock_minutes')))
  returning id into qid;

  begin
    insert into public.hunts (user_id, spot_id, quote_id, device_id, start_location, expires_at)
    values (uid, p_spot_id, qid, dev,
            extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography,
            now() + make_interval(mins => private.cfg_int('hunt.quote_lock_minutes')))
    returning id into hid;
  exception when unique_violation then
    perform private.fail('ALREADY_FOUND');
  end;
  insert into private.hunt_nonces (hunt_id, nonce_hash) values (hid, private.sha256(nonce));
  insert into public.spot_views (user_id, spot_id) values (uid, p_spot_id);
  perform private.event('hunt_started', uid, jsonb_build_object('spot', p_spot_id, 'points', q -> 'total'));

  return jsonb_build_object('hunt_id', hid, 'quote', jsonb_build_object('total', q -> 'total', 'lines', private.public_lines(q -> 'lines')),
                            'expires_at', now() + make_interval(mins => private.cfg_int('hunt.quote_lock_minutes')),
                            'nonce', nonce, 'resumed', false);
end $$;

-- Location fix on the way (movement trail). Throttled to one per 15 s.
create or replace function public.hunt_ping(p_hunt_id uuid, p_lat float8, p_lng float8, p_accuracy real) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare uid uuid := private.require_user(); h record; pt extensions.geography; d float8; arrived boolean := false;
begin
  select hu.*, coalesce(s.mystery_center, b.location) as bloc,
         case when s.kind = 'mystery' then s.mystery_radius_m else b.geofence_m end as geofence_m, s.kind = 'mystery' as mystery
  into h
  from public.hunts hu join public.spots s on s.id = hu.spot_id join public.branches b on b.id = s.branch_id
  where hu.id = p_hunt_id and hu.user_id = uid and hu.status = 'active';
  if h.id is null then perform private.fail('HUNT_NOT_ACTIVE'); end if;
  if exists (select 1 from public.location_pings where hunt_id = p_hunt_id and recorded_at > now() - interval '15 seconds') then
    return jsonb_build_object('ok', true, 'throttled', true);
  end if;
  pt := extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography;
  insert into public.location_pings (hunt_id, user_id, location, accuracy_m) values (p_hunt_id, uid, pt, p_accuracy);
  d := extensions.st_distance(h.bloc, pt);
  if d <= h.geofence_m + least(coalesce(p_accuracy, 100), 100) and h.arrived_at is null then
    update public.hunts set arrived_at = now() where id = p_hunt_id; arrived := true;
  end if;
  -- For mystery spots the distance is to the public circle centre only (never the shop).
  return jsonb_build_object('ok', true, 'distance_m', round(d), 'arrived', arrived or h.arrived_at is not null, 'mystery', h.mystery);
end $$;

-- ---------------------------------------------------------------------
-- Helpers used by the scan pipeline
-- ---------------------------------------------------------------------
create or replace function private.sig(p_signal text, p_evidence jsonb default '{}'::jsonb) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object('signal', p_signal, 'points', coalesce((select points from private.trust_weights where signal = p_signal), 0),
                            'evidence', coalesce(p_evidence, '{}'::jsonb))
$$;

-- Store a rejected attempt (always logged, even rejections) and return its response.
create or replace function private.gate_reject(
  p_user uuid, p_idem text, p_code text, p_params jsonb default '{}'::jsonb,
  p_branch uuid default null, p_spot uuid default null, p_qr uuid default null, p_kind text default null,
  p_pt extensions.geography default null, p_acc real default null, p_dist real default null,
  p_dev uuid default null, p_ip inet default null
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare resp jsonb := jsonb_build_object('code', p_code, 'decision', 'gate_reject', 'params', coalesce(p_params, '{}'::jsonb), 'points', 0);
        prev jsonb;
begin
  insert into public.scans (idempotency_key, user_id, spot_id, branch_id, qr_id, input_kind, location, accuracy_m, distance_m,
                            device_id, ip, decision, result_code, points, response)
  values (p_idem, p_user, p_spot, p_branch, p_qr, p_kind, p_pt, p_acc, p_dist, p_dev, p_ip, 'gate_reject', p_code, 0, resp)
  on conflict (user_id, idempotency_key) do nothing;
  if not found then
    select response into prev from public.scans where user_id = p_user and idempotency_key = p_idem;
    return prev;
  end if;
  perform private.event('scan_rejected', p_user, jsonb_build_object('code', p_code, 'branch', p_branch));
  return resp;
end $$;

-- Parse a dynamic payload. Returns (branch_id, status) where status ∈ ok | stale | unknown.
create or replace function private.check_dynamic(p_payload text, out branch_id uuid, out status text)
language plpgsql security definer set search_path = '' as $$
declare m text[]; w bigint := private.dynamic_window(); n int := private.cfg_int('qr.dynamic_accept_windows'); i int;
begin
  status := 'unknown';
  m := regexp_match(p_payload, '^https://amouni\.app/d/([A-Za-z0-9]{10})/([A-Za-z0-9_-]{16})$');
  if m is null then return; end if;
  select id into branch_id from public.branches where public_id = m[1];
  if branch_id is null then return; end if;
  for i in 0 .. n - 1 loop
    if private.dynamic_token(branch_id, w - i) = m[2] then status := 'ok'; return; end if;
  end loop;
  for i in n .. 120 loop       -- up to an hour old → the screen was photographed
    if private.dynamic_token(branch_id, w - i) = m[2] then status := 'stale'; return; end if;
  end loop;
end $$;

-- Campaign attribution + charge for a Generated Visit.
create or replace function private.charge_campaign(p_campaign uuid, p_visit uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare c record;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.id is null or c.status <> 'running' then return; end if;
  if c.spent_iqd + c.cpv_iqd > c.budget_iqd then
    perform private.close_campaign(p_campaign, 'completed', 'budget');
    return;
  end if;
  insert into public.merchant_charges (merchant_id, campaign_id, visit_id, amount_iqd)
  values (c.merchant_id, c.id, p_visit, c.cpv_iqd) on conflict (visit_id) do nothing;
  if found then
    update public.campaigns set spent_iqd = spent_iqd + cpv_iqd, generated_visits = generated_visits + 1 where id = c.id
    returning * into c;
    if c.generated_visits >= c.goal_visits or c.spent_iqd + c.cpv_iqd > c.budget_iqd then
      perform private.close_campaign(p_campaign, 'completed', case when c.generated_visits >= c.goal_visits then 'goal' else 'budget' end);
    end if;
  end if;
end $$;

-- Close a campaign: stop its boosts and return unused points to AMOUNI marketing.
create or replace function private.close_campaign(p_campaign uuid, p_status text, p_reason text) returns void
language plpgsql security definer set search_path = '' as $$
declare c record; bal bigint;
begin
  select * into c from public.campaigns where id = p_campaign for update;
  if c.id is null or c.status in ('completed','cancelled','rejected') then return; end if;
  perform private.lock_wallets(array[c.wallet_id, private.wallet('amouni_marketing')]);
  update public.campaigns set status = p_status, ends_at = least(coalesce(ends_at, now()), now()) where id = p_campaign;
  update public.boosts set active = false where wallet_id = c.wallet_id;
  if c.wallet_id is not null then
    select balance into bal from public.wallets where id = c.wallet_id;
    if bal > 0 then
      perform private.post_tx('reverse', 'campaign', p_campaign::text,
        jsonb_build_array(jsonb_build_object('wallet', c.wallet_id, 'amount', -bal),
                          jsonb_build_object('wallet', private.wallet('amouni_marketing'), 'amount', bal)),
        null, 'campaign ' || p_status || ': ' || p_reason);
    end if;
  end if;
  perform private.audit('campaign_' || p_status, 'campaign', p_campaign::text, null, jsonb_build_object('reason', p_reason));
end $$;

-- Verified visit (the unit merchants pay for when it is Generated).
create or replace function private.create_visit(p_scan uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare r record; gen boolean; vid uuid; camp uuid; win int := private.cfg_int('visit.generated_view_hours');
begin
  select sc.*, b.merchant_id, s.campaign_id as spot_campaign, q.lines
  into r
  from public.scans sc join public.branches b on b.id = sc.branch_id join public.spots s on s.id = sc.spot_id
  left join public.point_quotes q on q.id = sc.quote_id
  where sc.id = p_scan;

  gen := (exists (select 1 from public.hunts h where h.user_id = r.user_id and h.spot_id = r.spot_id
                    and h.started_at > r.created_at - make_interval(hours => win))
          or exists (select 1 from public.spot_views v where v.user_id = r.user_id and v.spot_id = r.spot_id
                    and v.viewed_at > r.created_at - make_interval(hours => win)))
     and not exists (select 1 from public.visits v where v.user_id = r.user_id and v.merchant_id = r.merchant_id
                    and v.verified_at > r.created_at - make_interval(days => private.cfg_int('visit.new_customer_days')))
     and not exists (select 1 from public.merchant_members mm where mm.merchant_id = r.merchant_id and mm.user_id = r.user_id);

  camp := coalesce(r.spot_campaign,
                   (select w.owner_id from public.wallets w
                    where w.kind = 'campaign' and w.id in (select (l ->> 'wallet')::uuid from jsonb_array_elements(coalesce(r.lines, '[]'::jsonb)) l)
                    limit 1));

  insert into public.visits (scan_id, user_id, branch_id, merchant_id, spot_id, campaign_id, generated)
  values (p_scan, r.user_id, r.branch_id, r.merchant_id, r.spot_id, camp, gen)
  on conflict (scan_id) do nothing
  returning id into vid;
  if vid is null then return null; end if;

  update public.profiles set xp = xp + private.cfg_int('xp.per_visit') where id = r.user_id;
  if gen and camp is not null then perform private.charge_campaign(camp, vid); end if;
  perform private.event('visit_verified', r.user_id, jsonb_build_object('branch', r.branch_id, 'generated', gen));
  return vid;
end $$;

-- Lock a set of wallets in a deterministic order (prevents deadlocks between concurrent transactions).
create or replace function private.lock_wallets(p_ids uuid[]) returns void
language sql security definer set search_path = '' as $$
  select null from (select id from public.wallets where id = any(p_ids) order by id for update) x
$$;

-- Move quoted points from their funding wallets to the user (earn) or to held (hold).
create or replace function private.grant_scan(p_scan uuid, p_mode text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  sc record; sp record; ln jsonb; lines jsonb; entries jsonb := '[]'::jsonb; w uuid; wk text; bal bigint;
  mkt uuid := private.wallet('amouni_marketing'); pts int; rw record; reward jsonb := null;
begin
  select s.*, q.lines as qlines into sc from public.scans s join public.point_quotes q on q.id = s.quote_id where s.id = p_scan;
  select * into sp from public.spots where id = sc.spot_id;
  lines := private.trim_lines(sc.qlines, sc.points);
  perform private.lock_wallets(array(select (l ->> 'wallet')::uuid from jsonb_array_elements(lines) l) || mkt);

  for ln in select * from jsonb_array_elements(lines) loop
    w := (ln ->> 'wallet')::uuid; pts := (ln ->> 'points')::int;
    select kind, balance into wk, bal from public.wallets where id = w;
    if wk = 'campaign' and (bal < pts or not exists (select 1 from public.campaigns c where c.wallet_id = w and c.status = 'running')) then
      w := mkt;                                                 -- AMOUNI honours the quote if a campaign ran dry or closed
    end if;
    entries := entries || jsonb_build_object('wallet', w, 'amount', -pts);
  end loop;
  if sc.points > 0 then
    entries := entries || jsonb_build_object('wallet',
      private.wallet(case when p_mode = 'earn' then 'user_available' else 'user_held' end, sc.user_id), 'amount', sc.points);
    perform private.post_tx(p_mode, 'scan', p_scan::text, entries, sc.user_id, null, jsonb_build_object('spot', sc.spot_id));
  end if;

  if sp.instant_reward_id is not null then
    update public.rewards set stock = stock - 1 where id = sp.instant_reward_id and active and stock > 0 returning * into rw;
    if rw.id is not null then
      insert into public.bag_items (user_id, reward_id, source, source_ref, status, expires_at)
      values (sc.user_id, rw.id, 'spot', p_scan::text, case when p_mode = 'earn' then 'available' else 'held' end,
              now() + make_interval(days => rw.validity_days));
      reward := jsonb_build_object('title_ar', rw.title_ar);
    end if;
  end if;

  if sc.qr_id is not null then update public.qr_codes set scans_count = scans_count + 1 where id = sc.qr_id; end if;
  if p_mode = 'earn' then perform private.create_visit(p_scan); end if;
  return jsonb_build_object('lines', lines, 'reward', reward);
end $$;

-- Auto-disable a printed QR whose photo is being scanned far away.
create or replace function private.check_leak(p_qr uuid) returns void
language plpgsql security definer set search_path = '' as $$
declare n int; q record; owner record;
begin
  if p_qr is null then return; end if;
  select count(distinct s.user_id) into n from public.scans s join public.profiles p on p.id = s.user_id
  where s.qr_id = p_qr and s.created_at > now() - interval '1 hour' and s.distance_m > private.cfg_num('qr.leak_far_km') * 1000
    and p.created_at < now() - interval '7 days' and p.status = 'active'
    and s.device_id is not null
    and (select count(distinct x.device_id) from public.scans x where x.qr_id = p_qr and x.created_at > now() - interval '1 hour'
         and x.distance_m > private.cfg_num('qr.leak_far_km') * 1000) >= private.cfg_int('qr.leak_threshold');
  if n >= private.cfg_int('qr.leak_threshold') then
    update public.qr_codes set status = 'disabled', disabled_reason = 'leak_auto' where id = p_qr and status <> 'disabled' returning * into q;
    if q.id is not null then
      perform private.audit('qr_auto_disabled', 'qr_code', p_qr::text, null, jsonb_build_object('far_users', n), 'leak detection');
      for owner in select mm.user_id from public.merchant_members mm join public.branches b on b.merchant_id = mm.merchant_id
                   where b.id = q.branch_id and mm.role in ('owner','manager') and mm.active loop
        insert into public.notifications (user_id, kind, payload)
        values (owner.user_id, 'qr_leak', jsonb_build_object('qr_id', p_qr, 'label', q.label));
      end loop;
    end if;
  end if;
end $$;

-- ---------------------------------------------------------------------
-- scan_v1 — THE transaction. Called only by the `scan` edge function
-- (service role) after it has authenticated the user, rate-limited the
-- device/IP and evaluated device attestation. Clients cannot call it.
-- ---------------------------------------------------------------------
create or replace function public.scan_v1(
  p_user uuid, p_payload text, p_lat float8, p_lng float8, p_accuracy real,
  p_idem text, p_nonce text default null, p_device_fp text default null, p_platform text default 'web',
  p_ip inet default null, p_flags jsonb default '{}'::jsonb
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare
  prev jsonb; prof record; qr record; br record; sp record; hu record; nn record;
  v_kind text; tok text; dyn record;
  pt extensions.geography; dist real; allowed real; acc real := p_accuracy;
  signals jsonb := '[]'::jsonb; risk int := 0; v_trust int; v_decision text; v_code text;
  q jsonb; qid uuid; pts int; remaining int; tz text; ql int; sid uuid := gen_random_uuid();
  dev uuid; dev_hash bytea; g jsonb; resp jsonb; d0 float8; secs float8; prevscan record; bound boolean := false;
  valid_min int := private.cfg_int('trust.valid_min');
begin
  -- Give every record a shape so field access is safe on every path.
  select * into qr from public.qr_codes limit 0;
  select * into br from public.branches limit 0;
  select * into sp from public.spots limit 0;
  select * into hu from public.hunts limit 0;
  select * into nn from private.hunt_nonces limit 0;

  if p_idem is null or length(p_idem) < 8 or length(p_idem) > 100 then perform private.fail('BAD_REQUEST', 'idempotency key'); end if;
  -- One scan at a time per user: daily cap, cooldown and "one per spot" are evaluated without races.
  perform pg_advisory_xact_lock(hashtextextended('scan:' || p_user::text, 0));
  select response into prev from public.scans where user_id = p_user and idempotency_key = p_idem;
  if prev is not null then return prev; end if;
  if not private.rate_ok('scan:' || p_user::text, private.cfg_int('scan.rate_per_minute')) then
    return jsonb_build_object('code', 'RATE_LIMITED', 'decision', 'gate_reject', 'points', 0);
  end if;

  select * into prof from public.profiles where id = p_user;
  if prof.id is null then perform private.fail('UNAUTHENTICATED'); end if;
  dev := private.device_id(p_user, p_device_fp, p_platform);
  if p_lat is not null and p_lng is not null then
    pt := extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography;
  end if;

  -- 1. Resolve the input -----------------------------------------------
  p_payload := btrim(coalesce(p_payload, ''));
  if p_payload ~ '^https://amouni\.app/q/[A-Za-z0-9_-]{16,64}$' then
    v_kind := 'static'; tok := substring(p_payload from '/q/(.+)$');
    select c.* into qr from private.qr_tokens t join public.qr_codes c on c.id = t.qr_id where t.token_hash = private.sha256(tok);
  elsif p_payload ~* '^AM-[A-Z0-9]{4}-[A-Z0-9]{2}$' then
    v_kind := 'short_code';
    select * into qr from public.qr_codes where short_code = upper(p_payload)::extensions.citext;
  elsif p_payload ~ '^https://amouni\.app/d/' then
    v_kind := 'dynamic';
    select * into dyn from private.check_dynamic(p_payload);
    if dyn.status = 'stale' then return private.gate_reject(p_user, p_idem, 'DYNAMIC_STALE', '{}', dyn.branch_id, null, null, v_kind, pt, acc, null, dev, p_ip); end if;
    if dyn.status <> 'ok' then return private.gate_reject(p_user, p_idem, 'QR_UNKNOWN', '{}', null, null, null, v_kind, pt, acc, null, dev, p_ip); end if;
    select * into br from public.branches where id = dyn.branch_id;
  else
    return private.gate_reject(p_user, p_idem, 'QR_UNKNOWN', '{}', null, null, null, null, pt, acc, null, dev, p_ip);
  end if;

  if v_kind in ('static','short_code') then
    if qr.id is null then return private.gate_reject(p_user, p_idem, 'QR_UNKNOWN', '{}', null, null, null, v_kind, pt, acc, null, dev, p_ip); end if;
    if qr.status = 'disabled' or (qr.status = 'grace' and qr.grace_until < now()) then
      return private.gate_reject(p_user, p_idem, 'QR_EXPIRED', '{}', qr.branch_id, null, qr.id, v_kind, pt, acc, null, dev, p_ip);
    end if;
    select * into br from public.branches where id = qr.branch_id;
  end if;
  tz := private.city_tz(br.id);
  if pt is not null then dist := extensions.st_distance(br.location, pt); end if;

  -- 2. Which spot? Prefer the one the user is hunting here ----------------
  select h.* into hu from public.hunts h join public.spots s on s.id = h.spot_id
  where h.user_id = p_user and h.status = 'active' and h.expires_at > now() and s.branch_id = br.id
  order by h.started_at desc limit 1;

  if hu.id is not null and private.spot_open(hu.spot_id) and (v_kind = 'dynamic' or not (select requires_dynamic from public.spots where id = hu.spot_id)) then
    select * into sp from public.spots where id = hu.spot_id;
  else
    select * into hu from public.hunts limit 0;
    select s.* into sp from public.spots s
    where s.branch_id = br.id and private.spot_open(s.id) and (v_kind = 'dynamic' or not s.requires_dynamic)
      and not exists (select 1 from public.scans x where x.user_id = p_user and x.spot_id = s.id and x.decision in ('valid','held','step_up','review'))
    order by (s.kind in ('golden_drop','first_finder')) desc, s.base_points desc
    limit 1;
  end if;

  if sp.id is null then
    if exists (select 1 from public.spots s where s.branch_id = br.id and private.spot_open(s.id) and s.requires_dynamic and v_kind <> 'dynamic') then
      return private.gate_reject(p_user, p_idem, 'DYNAMIC_REQUIRED', '{}', br.id, null, qr.id, v_kind, pt, acc, dist, dev, p_ip);
    end if;
    if exists (select 1 from public.spots s join public.scans x on x.spot_id = s.id
               where s.branch_id = br.id and x.user_id = p_user and x.decision in ('valid','held','step_up','review') and private.spot_open(s.id)) then
      return private.gate_reject(p_user, p_idem, 'ALREADY_FOUND', '{}', br.id, null, qr.id, v_kind, pt, acc, dist, dev, p_ip);
    end if;
    return private.gate_reject(p_user, p_idem, 'SPOT_CLOSED', '{}', br.id, null, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end if;

  -- 3. Gates ----------------------------------------------------------
  if prof.status <> 'active' then
    return private.gate_reject(p_user, p_idem, 'ACCOUNT_LIMITED', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end if;
  if exists (select 1 from public.scans x where x.user_id = p_user and x.branch_id = br.id
             and x.decision in ('valid','held','step_up','review')
             and x.created_at > now() - make_interval(days => private.cfg_int('scan.place_cooldown_days'))) then
    return private.gate_reject(p_user, p_idem, 'PLACE_COOLDOWN',
      jsonb_build_object('days_left', (select private.cfg_int('scan.place_cooldown_days') - floor(extract(epoch from now() - max(x.created_at)) / 86400)::int
                                       from public.scans x where x.user_id = p_user and x.branch_id = br.id and x.decision in ('valid','held','step_up','review'))),
      br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end if;
  if sp.qty_left = 0 then
    return private.gate_reject(p_user, p_idem, 'SOLD_OUT', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end if;
  select private.cfg_int('points.daily_cap') - coalesce(sum(x.points), 0) into remaining from public.scans x
  where x.user_id = p_user and x.decision in ('valid','held','step_up','review') and x.created_at >= private.local_day_start(tz);
  if remaining <= 0 then
    return private.gate_reject(p_user, p_idem, 'DAILY_LIMIT', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end if;
  if pt is null then
    return private.gate_reject(p_user, p_idem, 'NO_LOCATION', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, null, dev, p_ip);
  end if;
  allowed := br.geofence_m * private.cfg_num('scan.geofence_multiplier') + least(coalesce(acc, 100), private.cfg_int('scan.accuracy_margin_max_m'));
  if dist > allowed then
    resp := private.gate_reject(p_user, p_idem, 'TOO_FAR', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
    perform private.check_leak(qr.id);
    return resp;
  end if;

  -- 4. Session binding (replay protection) ------------------------------
  if hu.id is not null then
    select * into nn from private.hunt_nonces where hunt_id = hu.id;
    if p_nonce is not null and nn.nonce_hash = private.sha256(p_nonce) then
      if nn.used_at is not null then
        return private.gate_reject(p_user, p_idem, 'REPLAY', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
      end if;
      bound := true;
    end if;
  end if;

  -- 5. Proof-of-presence signals ---------------------------------------
  if dist > br.geofence_m then signals := signals || private.sig('location_edge', jsonb_build_object('distance_m', round(dist), 'geofence_m', br.geofence_m)); end if;
  if coalesce(acc, 999) > 100 then signals := signals || private.sig('gps_accuracy', jsonb_build_object('accuracy_m', acc)); end if;
  if not bound then signals := signals || private.sig('no_session'); end if;
  if hu.id is not null and hu.start_location is null then
    signals := signals || private.sig('no_trail', jsonb_build_object('start', 'missing'));
  end if;
  if hu.id is not null and hu.start_location is not null then
    d0 := extensions.st_distance(hu.start_location, br.location);
    secs := greatest(extract(epoch from now() - hu.started_at), 1);
    if d0 > 300 and not exists (select 1 from public.location_pings where hunt_id = hu.id) then
      signals := signals || private.sig('no_trail', jsonb_build_object('start_distance_m', round(d0)));
    end if;
    if d0 > 300 and (d0 / secs) * 3.6 > private.cfg_int('hunt.max_city_speed_kmh') then
      signals := signals || private.sig('arrival_too_fast', jsonb_build_object('start_distance_m', round(d0), 'seconds', round(secs)));
    end if;
  end if;
  select x.location, x.created_at into prevscan from public.scans x
  where x.user_id = p_user and x.location is not null and x.created_at > now() - interval '6 hours'
  order by x.created_at desc limit 1;
  if prevscan.location is not null then
    d0 := extensions.st_distance(prevscan.location, pt);
    secs := greatest(extract(epoch from now() - prevscan.created_at), 1);
    if d0 > 2000 and (d0 / secs) * 3.6 > 120 then
      signals := signals || private.sig('impossible_travel', jsonb_build_object('km', round((d0 / 1000)::numeric, 1), 'minutes', round((secs / 60)::numeric)));
    end if;
  end if;
  if (select count(*) from public.visits where user_id = p_user and verified_at > now() - interval '30 minutes') >= 4 then
    signals := signals || private.sig('velocity');
  end if;
  if dev is not null then
    select fingerprint_hash into dev_hash from public.devices where id = dev;
    if (select count(distinct user_id) from public.devices where fingerprint_hash = dev_hash and last_seen > now() - interval '30 days') > 2 then
      signals := signals || private.sig('shared_device');
    end if;
  end if;
  if hu.id is not null then
    select jsonb_build_object('total', total, 'lines', lines), id into q, qid from public.point_quotes where id = hu.quote_id and expires_at > now();
  end if;
  if q is null then
    q := private.compute_quote(p_user, sp.id);
    insert into public.point_quotes (user_id, spot_id, total, lines, expires_at)
    values (p_user, sp.id, (q ->> 'total')::int, q -> 'lines', now()) returning id into qid;
  end if;
  if prof.created_at > now() - interval '24 hours' and (q ->> 'total')::int >= 300 then
    signals := signals || private.sig('new_account_high_value');
  end if;
  if qr.id is not null and exists (select 1 from public.scans x where x.qr_id = qr.id and x.user_id <> p_user
             and x.created_at > now() - interval '1 hour' and x.distance_m > private.cfg_num('qr.leak_far_km') * 1000) then
    signals := signals || private.sig('qr_leak_suspect');
  end if;
  if (select count(*) from public.visits v where v.user_id = p_user and v.merchant_id = br.merchant_id and v.verified_at > now() - interval '7 days') >= 3 then
    signals := signals || private.sig('collusion');
  end if;
  if prof.account_trust < 50 then signals := signals || private.sig('low_account_trust', jsonb_build_object('account_trust', prof.account_trust)); end if;
  if coalesce((p_flags ->> 'vpn')::boolean, false) then signals := signals || private.sig('vpn_datacenter'); end if;
  if coalesce((p_flags ->> 'mock_location')::boolean, false) then signals := signals || private.sig('mock_location'); end if;
  if coalesce((p_flags ->> 'integrity_failed')::boolean, false) then signals := signals || private.sig('device_integrity_fail'); end if;

  select coalesce(sum((s ->> 'points')::int), 0) into risk from jsonb_array_elements(signals) s;
  v_trust := greatest(0, 100 - risk);

  -- 6. Decision (risk-based, never one signal = ban) --------------------
  if sp.requires_dynamic then
    v_decision := case when v_trust >= valid_min and coalesce(acc, 999) <= 50 and prof.created_at < now() - interval '48 hours'
                     then 'valid' else 'review' end;
  elsif v_trust >= valid_min then v_decision := 'valid';
  elsif v_trust >= private.cfg_int('trust.step_up_min') then
    v_decision := case when br.cashier_mode and v_kind <> 'dynamic' then 'step_up' else 'held' end;
  elsif v_trust >= private.cfg_int('trust.review_min') then v_decision := 'review';
  else v_decision := 'rejected';
  end if;
  v_code := case v_decision when 'valid' then 'OK' when 'held' then 'HELD' when 'step_up' then 'STEP_UP' when 'review' then 'REVIEW' else 'REJECTED' end;
  pts := case when v_decision = 'rejected' then 0 else least((q ->> 'total')::int, remaining) end;

  -- 7. Inventory + scan row, atomically ----------------------------------
  begin
    if v_decision <> 'rejected' and sp.qty_left is not null then
      update public.spots set qty_left = qty_left - 1 where id = sp.id and qty_left > 0 returning qty_left into ql;
      if ql is null then
        return private.gate_reject(p_user, p_idem, 'SOLD_OUT', '{}', br.id, sp.id, qr.id, v_kind, pt, acc, dist, dev, p_ip);
      end if;
    end if;
    insert into public.scans (id, idempotency_key, user_id, hunt_id, spot_id, branch_id, qr_id, input_kind, location, accuracy_m,
                              distance_m, device_id, ip, trust_score, decision, result_code, points, quote_id, step_up_until)
    values (sid, p_idem, p_user, hu.id, sp.id, br.id, qr.id, v_kind, pt, acc, dist, dev, p_ip, v_trust, v_decision, v_code, pts, qid,
            case when v_decision = 'step_up' then now() + make_interval(mins => private.cfg_int('scan.step_up_minutes')) end);
  exception when unique_violation then
    select response into prev from public.scans where user_id = p_user and idempotency_key = p_idem;
    if prev is not null then return prev; end if;
    return private.gate_reject(p_user, p_idem, 'ALREADY_FOUND', '{}', br.id, null, qr.id, v_kind, pt, acc, dist, dev, p_ip);
  end;

  insert into public.scan_signals (scan_id, signal, points, evidence)
  select sid, s ->> 'signal', (s ->> 'points')::int, s -> 'evidence' from jsonb_array_elements(signals) s;

  if bound then update private.hunt_nonces set used_at = now() where hunt_id = hu.id; end if;
  if hu.id is not null and v_decision <> 'rejected' then
    update public.hunts set status = 'completed', completed_at = now(), arrived_at = coalesce(arrived_at, now()) where id = hu.id;
  end if;

  g := jsonb_build_object('lines', private.trim_lines(q -> 'lines', pts), 'reward', null);
  if v_decision = 'valid' then g := private.grant_scan(sid, 'earn');
  elsif v_decision = 'held' then g := private.grant_scan(sid, 'hold');
  end if;

  resp := jsonb_build_object(
    'code', v_code, 'decision', v_decision, 'scan_id', sid,
    'points', pts, 'lines', private.public_lines(g -> 'lines'), 'reward', g -> 'reward',
    'spot', jsonb_build_object('id', sp.id, 'title_ar', sp.title_ar, 'kind', sp.kind),
    'rank', case when sp.qty_total is not null and v_decision <> 'rejected' then sp.qty_total - ql end,
    'step_up_until', case when v_decision = 'step_up' then now() + make_interval(mins => private.cfg_int('scan.step_up_minutes')) end);
  update public.scans set response = resp where id = sid;

  if dist > private.cfg_num('qr.leak_far_km') * 1000 then perform private.check_leak(qr.id); end if;
  perform private.event('scan', p_user, jsonb_build_object('code', v_code, 'trust', v_trust, 'branch', br.id, 'spot', sp.id));
  return resp;
end $$;

-- ---------------------------------------------------------------------
-- Step-up: user scans the cashier screen to confirm a medium-risk scan.
-- ---------------------------------------------------------------------
create or replace function public.step_up_v1(
  p_user uuid, p_scan_id uuid, p_payload text, p_lat float8, p_lng float8, p_accuracy real
) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare sc record; br record; dyn record; pt extensions.geography; d real; g jsonb; resp jsonb;
begin
  select * into sc from public.scans where id = p_scan_id and user_id = p_user for update;
  if sc.id is null then perform private.fail('NOT_FOUND'); end if;
  if sc.decision <> 'step_up' then return coalesce(sc.response, jsonb_build_object('code', 'NOT_PENDING')); end if;
  if sc.step_up_until < now() then return jsonb_build_object('code', 'STEP_UP_EXPIRED'); end if;

  select * into dyn from private.check_dynamic(p_payload);
  if dyn.status = 'stale' then return jsonb_build_object('code', 'DYNAMIC_STALE'); end if;
  if dyn.status <> 'ok' or dyn.branch_id <> sc.branch_id then return jsonb_build_object('code', 'QR_UNKNOWN'); end if;
  if p_lat is null or p_lng is null then return jsonb_build_object('code', 'NO_LOCATION'); end if;

  select * into br from public.branches where id = sc.branch_id;
  pt := extensions.st_setsrid(extensions.st_makepoint(p_lng, p_lat), 4326)::extensions.geography;
  d := extensions.st_distance(br.location, pt);
  if d > br.geofence_m * private.cfg_num('scan.geofence_multiplier') + least(coalesce(p_accuracy, 100), private.cfg_int('scan.accuracy_margin_max_m')) then
    return jsonb_build_object('code', 'TOO_FAR');
  end if;

  update public.scans set decision = 'valid', result_code = 'OK', resolved_at = now(), resolution_note = 'step_up_passed' where id = sc.id;
  g := private.grant_scan(sc.id, 'earn');
  resp := sc.response || jsonb_build_object('code', 'OK', 'decision', 'valid', 'lines', private.public_lines(g -> 'lines'), 'reward', g -> 'reward', 'step_up_until', null);
  update public.scans set response = resp where id = sc.id;
  perform private.event('step_up_passed', p_user, jsonb_build_object('scan', sc.id));
  return resp;
end $$;

-- ---------------------------------------------------------------------
-- Resolve a pending scan (held / review / step_up). Used by analysts and jobs.
-- ---------------------------------------------------------------------
create or replace function private.resolve_scan(p_scan uuid, p_approve boolean, p_actor uuid, p_note text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare sc record; t uuid; rev jsonb; held_w uuid; avail_w uuid;
begin
  select * into sc from public.scans where id = p_scan for update;
  if sc.id is null then perform private.fail('NOT_FOUND'); end if;
  if sc.decision not in ('held','review','step_up') then perform private.fail('NOT_PENDING'); end if;

  if sc.decision = 'held' then
    held_w := private.wallet('user_held', sc.user_id); avail_w := private.wallet('user_available', sc.user_id);
    if p_approve then
      if sc.points > 0 then
        perform private.post_tx('release', 'scan', sc.id::text,
          jsonb_build_array(jsonb_build_object('wallet', held_w, 'amount', -sc.points), jsonb_build_object('wallet', avail_w, 'amount', sc.points)),
          p_actor, p_note);
      end if;
      update public.bag_items set status = 'available' where source = 'spot' and source_ref = sc.id::text and status = 'held';
      update public.scans set decision = 'valid', result_code = 'OK', resolved_at = now(), resolved_by = p_actor, resolution_note = p_note where id = sc.id;
      perform private.create_visit(sc.id);
    else
      select id into t from public.ledger_tx where kind = 'hold' and ref_type = 'scan' and ref_id = sc.id::text;
      if t is not null then
        select jsonb_agg(jsonb_build_object('wallet',
                 case when w.kind = 'campaign' and not exists (select 1 from public.campaigns c where c.wallet_id = w.id and c.status in ('running','paused'))
                      then private.wallet('amouni_marketing') else e.wallet_id end,
                 'amount', -e.amount))
        into rev from public.ledger_entries e join public.wallets w on w.id = e.wallet_id where e.tx_id = t;
        perform private.post_tx('reverse', 'scan', sc.id::text, rev, p_actor, p_note);
      end if;
      update public.rewards r set stock = stock + 1 from public.bag_items b
        where b.source = 'spot' and b.source_ref = sc.id::text and b.status = 'held' and r.id = b.reward_id;
      update public.bag_items set status = 'cancelled' where source = 'spot' and source_ref = sc.id::text and status = 'held';
      update public.spots set qty_left = qty_left + 1 where id = sc.spot_id and qty_left is not null;
      update public.scans set decision = 'rejected', result_code = 'REJECTED', resolved_at = now(), resolved_by = p_actor, resolution_note = p_note where id = sc.id;
      update public.hunts set status = 'cancelled' where id = sc.hunt_id;
    end if;
  else  -- review / step_up
    if p_approve then
      update public.scans set decision = 'valid', result_code = 'OK', resolved_at = now(), resolved_by = p_actor, resolution_note = p_note where id = sc.id;
      perform private.grant_scan(sc.id, 'earn');
    else
      update public.spots set qty_left = qty_left + 1 where id = sc.spot_id and qty_left is not null;
      update public.scans set decision = 'rejected', result_code = 'REJECTED', resolved_at = now(), resolved_by = p_actor, resolution_note = p_note where id = sc.id;
      update public.hunts set status = 'cancelled' where id = sc.hunt_id;
    end if;
  end if;

  insert into public.notifications (user_id, kind, payload)
  values (sc.user_id, 'scan_resolved', jsonb_build_object('scan_id', sc.id, 'approved', p_approve));
  perform private.audit(case when p_approve then 'scan_approved' else 'scan_rejected' end, 'scan', sc.id::text,
                        jsonb_build_object('decision', sc.decision), jsonb_build_object('approved', p_approve), p_note);
  return jsonb_build_object('scan_id', sc.id, 'approved', p_approve);
end $$;
