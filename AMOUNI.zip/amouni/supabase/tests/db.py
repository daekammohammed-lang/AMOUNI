"""Local test harness: a fresh Postgres database with the Supabase shim,
all migrations and the seed. Each test acts as a real role (authenticated
user / service_role) exactly like PostgREST does on Supabase."""
import glob, json, os, uuid, contextlib
import psycopg

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DSN_ADMIN = os.environ.get('AMOUNI_PG', 'host=/tmp/pg port=54322 user=postgres')
DB = os.environ.get('AMOUNI_TEST_DB', 'amouni_test')


def rebuild():
    with psycopg.connect(DSN_ADMIN + ' dbname=postgres', autocommit=True) as c:
        c.execute(f'drop database if exists {DB} with (force)')
        c.execute(f'create database {DB}')
    files = [os.path.join(ROOT, 'tests', 'supabase_shim.sql')] + sorted(glob.glob(os.path.join(ROOT, 'migrations', '*.sql')))
    seed = os.path.join(ROOT, 'seed.sql')
    if os.path.exists(seed):
        files.append(seed)
    with psycopg.connect(dsn(), autocommit=True) as c:
        for f in files:
            try:
                c.execute(open(f, encoding='utf-8').read())
            except Exception as e:
                raise SystemExit(f'\n✗ {os.path.basename(f)}\n{e}')
    return files


def dsn():
    return DSN_ADMIN + f' dbname={DB}'


class AmouniError(Exception):
    def __init__(self, code, raw):
        super().__init__(code); self.code = code; self.raw = raw


@contextlib.contextmanager
def session(user=None, role=None):
    """user=uuid → acts as that signed-in user; role='service_role' → edge function."""
    conn = psycopg.connect(dsn(), autocommit=True)
    try:
        r = role or ('authenticated' if user else 'anon')
        claims = {'role': r}
        if user: claims['sub'] = str(user)
        conn.execute("select set_config('request.jwt.claims', %s, false)", (json.dumps(claims),))
        conn.execute(f'set role {r}')
        yield Conn(conn)
    finally:
        conn.close()


class Conn:
    def __init__(self, c): self.c = c
    def rpc(self, fn, **kw):
        args = ', '.join(f'p_{k} => %s' for k in kw)
        # Send every argument untyped (like PostgREST does) and let Postgres resolve the signature.
        def lit(v):
            if v is None: return None
            if isinstance(v, bool): return 'true' if v else 'false'
            if isinstance(v, (dict, list)): return json.dumps(v)
            return str(v)
        vals = [lit(v) for v in kw.values()]
        try:
            row = self.c.execute(f'select public.{fn}({args})', vals).fetchone()
        except psycopg.errors.RaiseException as e:
            msg = str(e).split('\n')[0]
            code = msg.split('AMOUNI:')[1].split()[0] if 'AMOUNI:' in msg else msg
            raise AmouniError(code, msg)
        return row[0] if row else None
    def q(self, sql, *a):
        return self.c.execute(sql, a).fetchall()
    def one(self, sql, *a):
        r = self.c.execute(sql, a).fetchone(); return r[0] if r and len(r) == 1 else r



@contextlib.contextmanager
def superuser():
    conn = psycopg.connect(dsn(), autocommit=True)
    try: yield Conn(conn)
    finally: conn.close()
