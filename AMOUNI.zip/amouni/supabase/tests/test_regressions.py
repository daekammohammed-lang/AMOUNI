"""Regression tests for issues found in the independent security review."""
import uuid
import psycopg, pytest
import db
from conftest import *


def test_step_up_requires_both_coordinates():
    u = new_user()
    lat, lng = branch_pos(1)
    with su() as s:
        g = s.one('select geofence_m from public.branches where id = %s', B(1))
    r = scan(u, qr_url(1), *offset(lat, lng, north_m=g * 1.5), acc=150)
    assert r['code'] == 'STEP_UP'
    with db.session(user=OWNER) as s:
        dyn = s.rpc('cashier_token', branch=B(1))['url']
    with db.session(role='service_role') as s:
        assert s.rpc('step_up_v1', user=u, scan_id=r['scan_id'], payload=dyn, lat=0, lng=None, accuracy=5)['code'] == 'NO_LOCATION'
    assert balance(u) == 0


def test_parallel_store_purchase_with_same_key_buys_once():
    u = new_user()
    with db.session(user=ADMIN) as s:
        s.rpc('admin_adjust_points', user=u, amount=2000, reason='test')
    with su() as s:
        rid = str(s.one("select id from public.rewards where title_ar = 'لاتيه بأي نكهة'"))
    key = 'same-' + uuid.uuid4().hex
    def buy():
        with db.session(user=u) as s:
            return s.rpc('buy_reward', reward_id=rid, idem=key)
    res = parallel([buy] * 6)
    assert len({r['bag_item_id'] for r in res}) == 1
    assert balance(u) == 1600
    ledger_ok()


def test_owner_can_read_own_branches_through_rls():
    with db.session(user=OWNER) as s:
        assert len(s.q('select id from public.branches')) == 11
    with db.session(user=new_user()) as s:
        assert s.q('select id from public.branches') == []


def test_banned_user_is_blocked_everywhere_but_can_still_read():
    u = new_user()
    with su() as s:
        s.q("update public.profiles set status = 'banned' where id = %s returning id", u)
    with db.session(user=u) as s:
        for fn, kw in [('start_hunt', dict(spot_id=spot_of(2), lat=33.42, lng=43.29, accuracy=10)),
                       ('merchant_apply', dict(name='x محل', category='coffee', city=CITY, branch_name='x', lat=33.4, lng=43.3)),
                       ('complete_profile', dict(name='اسم', city=CITY))]:
            with pytest.raises(db.AmouniError) as e:
                s.rpc(fn, **kw)
            assert e.value.code == 'ACCOUNT_LIMITED', fn
        assert 'available' in s.rpc('my_wallet')
    assert scan(u, qr_url(2), *branch_pos(2))['code'] == 'ACCOUNT_LIMITED'


def test_hunt_ping_never_reveals_the_mystery_shop():
    u = new_user()
    lat, lng = branch_pos(11)
    with su() as s:
        clat, clng = s.one("select extensions.st_y(mystery_center::extensions.geometry), extensions.st_x(mystery_center::extensions.geometry) from public.spots where kind = 'mystery'")
    h = hunt(u, spot_of(11, 'mystery'), *offset(clat, clng, north_m=100))
    with db.session(user=u) as s:
        p = s.rpc('hunt_ping', hunt_id=h['hunt_id'], lat=lat, lng=lng, accuracy=10)   # standing exactly at the shop
    assert p['mystery'] is True and p['distance_m'] > 30                               # distance is to the circle centre, not 0


def test_hunt_needs_a_start_location():
    u = new_user()
    with db.session(user=u) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('start_hunt', spot_id=spot_of(2), lat=None, lng=None, accuracy=None)
    assert e.value.code == 'NO_LOCATION'


def test_campaign_schedule_and_audience_are_enforced():
    with db.session(user=OWNER) as s:
        cid = s.rpc('campaign_save', merchant=M(6), draft={'name': 'ليل فقط', 'goal_type': 'quiet_hours', 'goal_visits': 10,
             'bonus_points': 150, 'budget_iqd': 30000, 'audience': 'new',
             'schedule': {'days': [], 'from': '03:00', 'to': '03:01'}})
        s.rpc('campaign_submit', campaign=cid)
    with db.session(user=ADMIN) as s:
        s.rpc('admin_campaign_decide', campaign=cid, approve=True, reason='ok')
    u = new_user()
    h = hunt(u, spot_of(6), *branch_pos(6))
    assert not any(l['kind'] == 'campaign' for l in h['quote']['lines'])


def test_reversed_redemption_can_be_redeemed_again():
    u = new_user()
    with db.session(user=ADMIN) as s:
        s.rpc('admin_adjust_points', user=u, amount=500, reason='test')
    with su() as s:
        rid = str(s.one("select id from public.rewards where title_ar = 'لاتيه بأي نكهة'"))
    with db.session(user=u) as s:
        bag = s.rpc('buy_reward', reward_id=rid, idem='k-' + uuid.uuid4().hex)
        tok = s.rpc('issue_redeem_token', bag_item_id=bag['bag_item_id'])
    with db.session(user=OWNER) as s:
        s.rpc('merchant_redeem', branch_id=B(1), input=tok['code'])
    with su() as s:
        red = str(s.one('select id from public.redemptions where bag_item_id = %s', bag['bag_item_id']))
    with db.session(user=ADMIN) as s:
        s.rpc('admin_reverse_redemption', redemption=red, reason='cashier pressed by mistake')
    with db.session(user=u) as s:
        tok2 = s.rpc('issue_redeem_token', bag_item_id=bag['bag_item_id'])
    with db.session(user=OWNER) as s:
        assert s.rpc('merchant_redeem', branch_id=B(1), input=tok2['code'])['ok']


def test_unknown_campaign_id_is_not_found():
    with db.session(user=ADMIN) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('admin_campaign_decide', campaign=str(uuid.uuid4()), approve=True, reason='x')
    assert e.value.code == 'NOT_FOUND'
    ledger_ok()


def test_branch_scoped_manager_cannot_act_merchant_wide():
    mgr = new_user('مدير فرع')
    with su() as s:
        s.q("insert into public.merchant_members (merchant_id, user_id, role, branch_id) values (%s, %s, 'manager', %s) returning user_id", M(1), mgr, B(1))
    with db.session(user=mgr) as s:
        assert s.rpc('qr_create', branch=B(1))['url']                     # own branch: fine
        for fn, kw in [('merchant_stats', dict(merchant=M(1))), ('merchant_set_settings', dict(merchant=M(1), avg_ticket_iqd=1)),
                       ('campaign_save', dict(merchant=M(1), draft={'name': 'x'}))]:
            with pytest.raises(db.AmouniError) as e:
                s.rpc(fn, **kw)
            assert e.value.code == 'FORBIDDEN', fn


def test_fresh_accounts_cannot_disable_a_merchants_qr():
    lat, lng = branch_pos(6)
    url = qr_url(6)
    for i in range(5):
        scan(new_user(f'troll{i}', age_hours=1), url, *offset(lat, lng, north_m=5000))
    with su() as s:
        assert s.one("select status from public.qr_codes where branch_id = %s order by created_at limit 1", B(6)) == 'active'


def test_held_reversal_after_campaign_closed_goes_back_to_amouni():
    with db.session(user=OWNER) as s:
        cid = s.rpc('campaign_save', merchant=M(5), draft={'name': 'نادي', 'goal_type': 'new_visits', 'goal_visits': 10,
                                                           'bonus_points': 100, 'budget_iqd': 30000})
        s.rpc('campaign_submit', campaign=cid)
    with db.session(user=ADMIN) as s:
        s.rpc('admin_campaign_decide', campaign=cid, approve=True, reason='ok')
    u = new_user()
    lat, lng = branch_pos(5)
    with su() as s:
        g = s.one('select geofence_m from public.branches where id = %s', B(5))
    r = scan(u, qr_url(5), *offset(lat, lng, north_m=g * 1.5), acc=150)
    assert r['code'] == 'HELD'
    with su() as s:
        s.q("select private.close_campaign(%s, 'cancelled', 'test')", cid)
    with db.session(user=ADMIN) as s:
        s.rpc('admin_resolve_scan', scan=r['scan_id'], approve=False, reason='fraud')
    with su() as s:
        assert s.one("select balance from public.wallets where kind = 'campaign' and owner_id = %s", cid) == 0
    ledger_ok()
