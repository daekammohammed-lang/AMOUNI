"""Scan pipeline: happy path, idempotency, gates, dynamic QR, races."""
import uuid
import pytest
import db
from conftest import *


def test_happy_path_hunt_then_scan():
    u = new_user('علي')
    lat, lng = branch_pos(2)                        # مطعم بيت الكص: base 80 + new customer 100 + discovery 100
    slat, slng = offset(lat, lng, north_m=200)
    h = hunt(u, spot_of(2), slat, slng)
    assert h['quote']['total'] == 280
    assert [l['kind'] for l in h['quote']['lines']] == ['base', 'new_customer', 'discovery']

    r = scan(u, qr_url(2), *offset(lat, lng, east_m=10), nonce=h['nonce'])
    assert r['code'] == 'OK' and r['points'] == 280
    assert balance(u) == 280
    with su() as s:
        assert s.one('select generated from public.visits where user_id = %s', u) is True
        assert s.one("select status from public.hunts where id = %s", h['hunt_id']) == 'completed'
        assert s.one('select used_at is not null from private.hunt_nonces where hunt_id = %s', h['hunt_id'])
        assert s.one('select xp from public.profiles where id = %s', u) == 60
    ledger_ok()


def test_quote_is_locked_for_the_hunt():
    u = new_user()
    lat, lng = branch_pos(2)
    h = hunt(u, spot_of(2), lat, lng)
    with su() as s:                                 # admin raises base points after the user started
        s.q('update public.spots set base_points = 400 where id = %s returning id', spot_of(2))
    r = scan(u, qr_url(2), lat, lng, nonce=h['nonce'])
    assert r['points'] == h['quote']['total'] == 280


def test_idempotent_retry_returns_same_result_and_pays_once():
    u = new_user()
    lat, lng = branch_pos(2)
    h = hunt(u, spot_of(2), lat, lng)
    key = uuid.uuid4().hex
    a = scan(u, qr_url(2), lat, lng, idem=key, nonce=h['nonce'])
    b = scan(u, qr_url(2), lat, lng, idem=key, nonce=h['nonce'])
    assert a == b and a['code'] == 'OK'
    assert balance(u) == 280
    with su() as s:
        assert s.one('select count(*) from public.scans where user_id = %s', u) == 1
    ledger_ok()


def test_second_scan_of_found_spot():
    u = new_user()
    lat, lng = branch_pos(2)
    h = hunt(u, spot_of(2), lat, lng)
    assert scan(u, qr_url(2), lat, lng, nonce=h['nonce'])['code'] == 'OK'
    assert scan(u, qr_url(2), lat, lng)['code'] == 'ALREADY_FOUND'
    assert balance(u) == 280


@pytest.mark.parametrize('payload,code', [
    ('https://amouni.app/q/AAAAAAAAAAAAAAAAAAAAAA', 'QR_UNKNOWN'),
    ('https://evil.example/q/whatever', 'QR_UNKNOWN'),
    ('AM-ZZZZ-ZZ', 'QR_UNKNOWN'),
    ('', 'QR_UNKNOWN'),
])
def test_unknown_inputs(payload, code):
    u = new_user()
    assert scan(u, payload, *branch_pos(2))['code'] == code


def test_short_code_works_like_the_printed_qr():
    u = new_user()
    lat, lng = branch_pos(5)
    h = hunt(u, spot_of(5), lat, lng)
    assert scan(u, short_code(5).lower(), lat, lng, nonce=h['nonce'])['code'] == 'OK'


def test_photo_of_qr_scanned_far_away_is_too_far():
    u = new_user()
    lat, lng = branch_pos(2)
    r = scan(u, qr_url(2), *offset(lat, lng, north_m=5000))
    assert r['code'] == 'TOO_FAR' and balance(u) == 0


def test_no_location():
    u = new_user()
    assert scan(u, qr_url(2), None, None)['code'] == 'NO_LOCATION'


def test_place_cooldown_blocks_a_second_spot_at_the_same_branch():
    u = new_user()
    lat, lng = branch_pos(2)
    assert scan(u, qr_url(2), lat, lng)['code'] in ('OK',)
    with su() as s:
        s.q("insert into public.spots (branch_id, title_ar, base_points, status) values (%s, 'لقطة ثانية', 50, 'live') returning id", B(2))
    r = scan(u, qr_url(2), lat, lng)
    assert r['code'] == 'PLACE_COOLDOWN' and r['params']['days_left'] == 7


def test_daily_cap_trims_then_blocks():
    with su() as s:
        s.q("update private.config set value = '300' where key = 'points.daily_cap' returning key")
    u = new_user()
    assert scan(u, qr_url(2), *branch_pos(2))['points'] == 280
    r2 = scan(u, qr_url(5), *branch_pos(5))
    assert r2['code'] == 'OK' and r2['points'] == 20                    # trimmed to what is left today
    assert scan(u, qr_url(6), *branch_pos(6))['code'] == 'DAILY_LIMIT'
    ledger_ok()


def test_spot_closed_outside_hours():
    u = new_user()
    with su() as s:   # sweets shop open 16:00–21:00 every day; force "now" outside by making hours impossible
        s.q("""update public.branches set hours = '{"0":[],"1":[],"2":[],"3":[],"4":[],"5":[],"6":[]}' where id = %s returning id""", B(3))
    assert scan(u, qr_url(3), *branch_pos(3))['code'] == 'SPOT_CLOSED'


def test_replayed_nonce_is_rejected():
    u = new_user()
    lat, lng = branch_pos(2)
    h = hunt(u, spot_of(2), lat, lng)
    with su() as s:
        s.q('update private.hunt_nonces set used_at = now() where hunt_id = %s returning hunt_id', h['hunt_id'])
    assert scan(u, qr_url(2), lat, lng, nonce=h['nonce'])['code'] == 'REPLAY'


# ---------------- dynamic (cashier screen) ----------------
def cashier_url(n):
    with db.session(user=OWNER) as s:
        return s.rpc('cashier_token', branch=B(n))['url']


def test_golden_drop_needs_the_cashier_screen():
    u = new_user(age_hours=72)
    lat, lng = branch_pos(4)
    assert scan(u, qr_url(4), lat, lng)['code'] == 'DYNAMIC_REQUIRED'
    r = scan(u, cashier_url(4), lat, lng, acc=15)
    assert r['code'] == 'OK' and r['points'] == 600 and r['rank'] == 1      # 500 + 100 discovery, drop cap 600
    assert r['reward']['title_ar'] == 'سماعات لاسلكية'
    ledger_ok()


def test_photographed_cashier_screen_is_stale():
    u = new_user()
    with su() as s:
        old = s.one("select 'https://amouni.app/d/' || public_id || '/' || private.dynamic_token(id, private.dynamic_window() - 5) from public.branches where id = %s", B(4))
    assert scan(u, old, *branch_pos(4))['code'] == 'DYNAMIC_STALE'


def test_new_account_cannot_win_a_golden_drop_instantly():
    u = new_user(age_hours=2)
    r = scan(u, cashier_url(4), *branch_pos(4), acc=15)
    assert r['code'] == 'REVIEW' and balance(u) == 0 and balance(u, 'user_held') == 0


# ---------------- races ----------------
def test_last_unit_race_has_exactly_one_winner():
    with su() as s:
        s.q("update public.spots set qty_left = 1 where branch_id = %s returning id", B(8))   # First Finder
    users = [new_user(f'u{i}') for i in range(8)]
    lat, lng = branch_pos(8)
    res = parallel([lambda u=u: scan(u, qr_url(8), lat, lng) for u in users])
    codes = sorted(r['code'] for r in res)
    assert codes.count('OK') == 1 and codes.count('SOLD_OUT') == 7, codes
    with su() as s:
        assert s.one("select qty_left from public.spots where branch_id = %s", B(8)) == 0
    ledger_ok()


def test_drop_with_three_units_and_twenty_hunters():
    with su() as s:
        s.q("update public.spots set qty_left = 3, qty_total = 3 where branch_id = %s returning id", B(8))
    users = [new_user(f'h{i}') for i in range(20)]
    lat, lng = branch_pos(8)
    res = parallel([lambda u=u: scan(u, qr_url(8), lat, lng) for u in users])
    assert sum(r['code'] == 'OK' for r in res) == 3
    assert sorted(r['rank'] for r in res if r['code'] == 'OK') == [1, 2, 3]
    ledger_ok()


def test_same_user_double_tap_pays_once():
    u = new_user()
    lat, lng = branch_pos(2)
    res = parallel([lambda: scan(u, qr_url(2), lat, lng) for _ in range(5)])
    assert sum(r['code'] == 'OK' for r in res) == 1
    assert balance(u) == 280
    ledger_ok()
