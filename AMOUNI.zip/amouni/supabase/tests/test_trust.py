"""Trust score tiers, step-up, analyst review, jobs, QR rotation and leak detection."""
import uuid
import db
from conftest import *

# A "borderline" scan: no hunt (5) + poor GPS (10) + inside the mall-edge band (20) → trust 65.
def borderline(u, n, **kw):
    lat, lng = branch_pos(n)
    with su() as s:
        g = s.one('select geofence_m from public.branches where id = %s', B(n))
    return scan(u, qr_url(n), *offset(lat, lng, north_m=g * 1.5), acc=150, **kw)


def test_borderline_without_cashier_screen_is_held_then_auto_released():
    u = new_user()
    r = borderline(u, 5)                               # نادي القوة: no cashier mode
    assert r['code'] == 'HELD' and r['points'] > 0
    assert balance(u) == 0 and balance(u, 'user_held') == r['points']
    with su() as s:
        signals = {x[0] for x in s.q('select signal from public.scan_signals where scan_id = %s', r['scan_id'])}
        assert signals == {'no_session', 'gps_accuracy', 'location_edge'}
        s.q("update public.scans set created_at = now() - interval '25 hours' where id = %s returning id", r['scan_id'])
    with db.session(role='service_role') as s:
        assert s.rpc('job_release_held') == 1
    assert balance(u) == r['points'] and balance(u, 'user_held') == 0
    ledger_ok()


def test_user_response_never_reveals_signals_or_trust():
    u = new_user()
    r = borderline(u, 5)
    assert 'trust' not in r and 'signals' not in r and 'trust_score' not in r


def test_borderline_with_cashier_screen_steps_up():
    u = new_user()
    r = borderline(u, 1)                               # كافيه الفرات has cashier mode
    assert r['code'] == 'STEP_UP' and balance(u) == 0
    with db.session(user=OWNER) as s:
        dyn = s.rpc('cashier_token', branch=B(1))['url']
    lat, lng = branch_pos(1)
    with db.session(role='service_role') as s:
        ok = s.rpc('step_up_v1', user=u, scan_id=r['scan_id'], payload=dyn, lat=lat, lng=lng, accuracy=20)
    assert ok['code'] == 'OK' and balance(u) == r['points']
    ledger_ok()


def test_step_up_rejects_another_branches_screen_and_expired_window():
    u = new_user()
    r = borderline(u, 1)
    with db.session(user=OWNER) as s:
        other = s.rpc('cashier_token', branch=B(4))['url']
    lat, lng = branch_pos(1)
    with db.session(role='service_role') as s:
        assert s.rpc('step_up_v1', user=u, scan_id=r['scan_id'], payload=other, lat=lat, lng=lng, accuracy=20)['code'] == 'QR_UNKNOWN'
    with su() as s:
        s.q("update public.scans set step_up_until = now() - interval '1 minute' where id = %s returning id", r['scan_id'])
    with db.session(role='service_role') as s:
        assert s.rpc('job_housekeeping')['step_up_to_review'] == 1
    with su() as s:
        assert s.one('select decision from public.scans where id = %s', r['scan_id']) == 'review'


def test_mock_location_and_vpn_goes_to_review_then_analyst_rejects():
    u = new_user()
    with su() as s:
        s.q("update public.spots set qty_left = 5 where branch_id = %s returning id", B(8))
    lat, lng = branch_pos(8)
    r = scan(u, qr_url(8), lat, lng, flags={'mock_location': True, 'vpn': True})
    assert r['code'] == 'REVIEW' and balance(u) == 0
    with su() as s:
        assert s.one('select qty_left from public.spots where branch_id = %s', B(8)) == 4   # unit reserved while reviewed
    with db.session(user=ADMIN) as s:
        q = s.rpc('admin_review_queue')
        assert any(x['id'] == r['scan_id'] for x in q)
        s.rpc('admin_resolve_scan', scan=r['scan_id'], approve=False, reason='mock location confirmed')
    with su() as s:
        assert s.one('select qty_left from public.spots where branch_id = %s', B(8)) == 5   # unit returned
        assert s.one("select count(*) from public.audit_log where action = 'scan_rejected' and entity_id = %s", r['scan_id']) == 1
    assert balance(u) == 0
    ledger_ok()


def test_review_approved_pays_the_quoted_points():
    u = new_user()
    r = scan(u, qr_url(2), *branch_pos(2), flags={'mock_location': True, 'vpn': True})
    assert r['code'] == 'REVIEW'
    with db.session(user=ADMIN) as s:
        s.rpc('admin_resolve_scan', scan=r['scan_id'], approve=True, reason='checked CCTV with merchant')
    assert balance(u) == r['points'] == 280
    ledger_ok()


def test_clear_fraud_is_rejected_outright():
    u = new_user()
    r = scan(u, qr_url(2), *branch_pos(2), flags={'mock_location': True, 'integrity_failed': True})
    assert r['code'] == 'REJECTED' and r['points'] == 0 and balance(u) == 0
    # A rejected scan does not burn the spot: a genuine retry later still works.
    h = hunt(u, spot_of(2), *branch_pos(2))
    assert scan(u, qr_url(2), *branch_pos(2), nonce=h['nonce'])['code'] == 'OK'


def test_held_rejected_returns_points_to_their_funding_wallets():
    u = new_user()
    with su() as s:
        before = s.one("select balance from public.wallets where kind = 'amouni_marketing'")
    r = borderline(u, 5)
    with db.session(user=ADMIN) as s:
        s.rpc('admin_resolve_scan', scan=r['scan_id'], approve=False, reason='same device as 4 accounts')
    with su() as s:
        assert s.one("select balance from public.wallets where kind = 'amouni_marketing'") == before
    assert balance(u, 'user_held') == 0 and balance(u) == 0
    ledger_ok()


def test_shared_device_farm_is_flagged():
    lat, lng = branch_pos(2)
    for i in range(3):
        u = new_user(f'farm{i}')
        r = scan(u, qr_url(2), lat, lng, fp='same-phone-1234')
    with su() as s:
        assert s.one("select count(*) from public.scan_signals where scan_id = %s and signal = 'shared_device'", r['scan_id']) == 1


def test_impossible_travel():
    u = new_user()
    assert scan(u, qr_url(10), *branch_pos(10))['code'] == 'OK'
    with su() as s:   # pretend the previous scan was in Baghdad 10 minutes ago
        s.q("""update public.scans set location = extensions.st_setsrid(extensions.st_makepoint(44.36, 33.31), 4326)::extensions.geography,
               created_at = now() - interval '10 minutes' where user_id = %s returning id""", u)
    r = scan(u, qr_url(2), *branch_pos(2))
    with su() as s:
        assert s.one("select count(*) from public.scan_signals where scan_id = %s and signal = 'impossible_travel'", r['scan_id']) == 1


def test_hunt_from_far_with_no_trail_and_teleport_is_suspicious():
    u = new_user()
    lat, lng = branch_pos(5)
    h = hunt(u, spot_of(5), *offset(lat, lng, north_m=3000))   # starts 3 km away…
    r = scan(u, qr_url(5), lat, lng, nonce=h['nonce'])           # …and scans one second later, no fixes on the way
    with su() as s:
        sig = {x[0] for x in s.q('select signal from public.scan_signals where scan_id = %s', r['scan_id'])}
    assert {'no_trail', 'arrival_too_fast'} <= sig
    assert r['code'] in ('HELD', 'STEP_UP')                      # 100 - 10 - 25 = 65


# ---------------- QR lifecycle ----------------
def test_rotation_keeps_old_qr_for_grace_but_leak_kills_it():
    old = qr_url(2)
    with su() as s:
        qid = s.one("select id from public.qr_codes where branch_id = %s and status = 'active'", B(2))
    with db.session(user=OWNER) as s:
        new = s.rpc('qr_rotate', qr=qid, reason='manual')
    assert new['url'] != old
    u1 = new_user()
    assert scan(u1, old, *branch_pos(2))['code'] == 'OK'          # grace period
    with db.session(user=OWNER) as s:
        s.rpc('qr_rotate', qr=new['qr_id'], reason='leak')
    u2 = new_user()
    assert scan(u2, new['url'], *branch_pos(2))['code'] == 'QR_EXPIRED'


def test_leak_detection_auto_disables_qr():
    lat, lng = branch_pos(6)
    url = qr_url(6)
    for i in range(3):
        assert scan(new_user(f'far{i}', age_hours=24 * 10), url, *offset(lat, lng, north_m=4000 + i * 100))['code'] == 'TOO_FAR'
    with su() as s:
        assert s.one("select status from public.qr_codes where branch_id = %s order by created_at limit 1", B(6)) == 'disabled'
        assert s.one("select count(*) from public.notifications where kind = 'qr_leak'") >= 1
    assert scan(new_user(), url, lat, lng)['code'] == 'QR_EXPIRED'
