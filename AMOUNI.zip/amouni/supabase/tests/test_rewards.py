"""Points store, redemption, missions, discovery progress."""
import uuid
import pytest
import db
from conftest import *


def give(u, pts):
    with db.session(user=ADMIN) as s:
        s.rpc('admin_adjust_points', user=u, amount=pts, reason='test credit')


def store_item(title):
    with su() as s:
        return str(s.one('select id from public.rewards where title_ar = %s', title))


def test_cannot_buy_without_points_and_nothing_changes():
    u = new_user()
    rid = store_item('لاتيه بأي نكهة')
    with su() as s:
        stock = s.one('select stock from public.rewards where id = %s', rid)
    with db.session(user=u) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('buy_reward', reward_id=rid, idem='k-' + uuid.uuid4().hex)
    assert e.value.code == 'INSUFFICIENT_POINTS'
    with su() as s:
        assert s.one('select stock from public.rewards where id = %s', rid) == stock   # rolled back
        assert s.one('select count(*) from public.bag_items where user_id = %s', u) == 0
    ledger_ok()


def test_buy_redeem_once_at_the_right_merchant():
    u = new_user('زبون'); give(u, 1000)
    rid = store_item('لاتيه بأي نكهة')                     # كافيه الفرات (merchant 1)
    key = 'k-' + uuid.uuid4().hex
    with db.session(user=u) as s:
        bag = s.rpc('buy_reward', reward_id=rid, idem=key)
        again = s.rpc('buy_reward', reward_id=rid, idem=key)          # retry = same purchase
        assert again['bag_item_id'] == bag['bag_item_id']
        tok = s.rpc('issue_redeem_token', bag_item_id=bag['bag_item_id'])
    assert balance(u) == 600

    # A cashier of another merchant cannot use the code.
    other_cashier = new_user('كاشير ثاني')
    with su() as s:
        s.q("insert into public.merchant_members (merchant_id, user_id, role) values (%s, %s, 'cashier') returning user_id", M(2), other_cashier)
    with db.session(user=other_cashier) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('merchant_redeem', branch_id=B(2), input=tok['code'])
    assert e.value.code == 'CODE_INVALID'
    # Nor can a random user.
    with db.session(user=new_user()) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('merchant_redeem', branch_id=B(1), input=tok['code'])
    assert e.value.code == 'FORBIDDEN'

    cashier = new_user('كاشير')
    with su() as s:
        s.q("insert into public.merchant_members (merchant_id, user_id, role, branch_id) values (%s, %s, 'cashier', %s) returning user_id", M(1), cashier, B(1))
    with db.session(user=cashier) as s:
        ok = s.rpc('merchant_redeem', branch_id=B(1), input=tok['qr'])
        assert ok['ok'] and ok['title_ar'] == 'لاتيه بأي نكهة' and ok['customer'] == 'زبون'
        with pytest.raises(db.AmouniError) as e:
            s.rpc('merchant_redeem', branch_id=B(1), input=tok['qr'])
        assert e.value.code == 'CODE_USED'
    ledger_ok()


def test_two_cashiers_redeem_same_code_at_once():
    u = new_user(); give(u, 1000)
    with db.session(user=u) as s:
        bag = s.rpc('buy_reward', reward_id=store_item('لاتيه بأي نكهة'), idem='k-' + uuid.uuid4().hex)
        tok = s.rpc('issue_redeem_token', bag_item_id=bag['bag_item_id'])
    def try_redeem():
        with db.session(user=OWNER) as s:
            return s.rpc('merchant_redeem', branch_id=B(1), input=tok['code'])
    res = parallel([try_redeem, try_redeem, try_redeem])
    assert sum(isinstance(r, dict) and r.get('ok') for r in res) == 1
    with su() as s:
        assert s.one('select count(*) from public.redemptions where bag_item_id = %s', bag['bag_item_id']) == 1


def test_expired_code_is_invalid():
    u = new_user(); give(u, 500)
    with db.session(user=u) as s:
        bag = s.rpc('buy_reward', reward_id=store_item('عصير طبيعي كبير'), idem='k-' + uuid.uuid4().hex)
        tok = s.rpc('issue_redeem_token', bag_item_id=bag['bag_item_id'])
    with su() as s:
        s.q("update private.redeem_tokens set expires_at = now() - interval '1 second' returning id")
    with db.session(user=OWNER) as s, pytest.raises(db.AmouniError) as e:
        s.rpc('merchant_redeem', branch_id=B(9), input=tok['code'])
    assert e.value.code == 'CODE_INVALID'


def test_instant_reward_from_spot_lands_in_bag():
    u = new_user()
    lat, lng = branch_pos(1)
    h = hunt(u, spot_of(1), lat, lng)
    r = scan(u, qr_url(1), lat, lng, nonce=h['nonce'])
    assert r['reward']['title_ar'] == 'إسبريسو مجاني'
    with su() as s:
        assert s.one("select status from public.bag_items where user_id = %s and source = 'spot'", u) == 'available'


def test_daily_mission_claim_once():
    u = new_user()
    for n in (2, 5):
        assert scan(u, qr_url(n), *branch_pos(n))['code'] == 'OK'
    with db.session(user=u) as s:
        ms = {m['code']: m for m in s.rpc('my_missions')}
        assert ms['daily_new_2']['progress'] == 2 and not ms['daily_new_2']['claimed']
        before = balance(u)
        assert s.rpc('claim_mission', mission_id=ms['daily_new_2']['mission_id'])['points'] == 150
        with pytest.raises(db.AmouniError) as e:
            s.rpc('claim_mission', mission_id=ms['daily_new_2']['mission_id'])
        assert e.value.code == 'ALREADY_CLAIMED'
        with pytest.raises(db.AmouniError) as e:
            s.rpc('claim_mission', mission_id=ms['weekly_4']['mission_id'])
        assert e.value.code == 'NOT_COMPLETE'
    assert balance(u) == before + 150
    ledger_ok()


def test_discovery_progress_by_district():
    u = new_user()
    scan(u, qr_url(1), *branch_pos(1))
    with db.session(user=u) as s:
        d = s.rpc('my_discovery', city=CITY)
    assert d['discovered'] == 1 and d['places'] == 11
    malaab = next(x for x in d['districts'] if x['name_ar'] == 'حي الملعب')
    assert malaab['discovered'] == 1 and malaab['places'] == 2
