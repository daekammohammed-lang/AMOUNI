"""What a signed-in (or signed-out) client can and cannot do directly against the API."""
import psycopg, pytest
import db
from conftest import *


def denied(fn):
    with pytest.raises((psycopg.errors.InsufficientPrivilege, db.AmouniError)) as e:
        fn()
    return e.value


def test_clients_cannot_call_the_scan_transaction_directly():
    u = new_user()
    with db.session(user=u) as s:
        denied(lambda: s.rpc('scan_v1', user=u, payload=qr_url(2), lat=33.42, lng=43.29, accuracy=10, idem='abcdefgh12'))
        denied(lambda: s.rpc('step_up_v1', user=u, scan_id=u, payload='x', lat=1, lng=1, accuracy=1))
        denied(lambda: s.rpc('job_release_held'))


def test_clients_cannot_write_tables_or_read_secrets():
    u = new_user()
    with db.session(user=u) as s:
        for sql in ["update public.wallets set balance = 999999",
                    "insert into public.ledger_entries (tx_id, wallet_id, amount) values (gen_random_uuid(), gen_random_uuid(), 5)",
                    "update public.profiles set status = 'active'",
                    "insert into public.platform_roles (user_id, role) values (auth.uid(), 'super_admin')",
                    "select * from private.qr_tokens",
                    "select * from private.branch_secrets",
                    "select * from private.config",
                    "select trust_score from public.scans",
                    "select * from public.scan_signals",
                    "select * from public.ledger_entries",
                    "select value_iqd from public.rewards",
                    "select * from public.audit_log"]:
            with pytest.raises(psycopg.errors.InsufficientPrivilege):
                s.q(sql)


def test_users_only_see_their_own_rows():
    a, b = new_user('a'), new_user('b')
    scan(a, qr_url(1), *branch_pos(1))
    with db.session(user=b) as s:
        assert s.q('select id from public.scans') == []
        assert s.q('select id from public.bag_items') == []
        assert s.q('select id from public.wallets') != []                 # their own two wallets
        assert all(r[0] == str(b) or True for r in s.q('select id from public.profiles'))
        assert len(s.q('select id from public.profiles')) == 1
    with db.session(user=a) as s:
        assert len(s.q('select id from public.scans')) == 1


def test_admin_functions_require_platform_roles():
    u = new_user()
    with db.session(user=u) as s:
        for fn, kw in [('admin_adjust_points', dict(user=u, amount=1000, reason='free money')),
                       ('admin_economy', {}), ('admin_review_queue', {}),
                       ('admin_set_config', dict(key='points.daily_cap', value=99999, reason='x')),
                       ('admin_merchant_decide', dict(merchant=M(1), approve=False, reason='x'))]:
            e = denied(lambda: s.rpc(fn, **kw))
            assert getattr(e, 'code', 'priv') in ('FORBIDDEN', 'priv'), fn
    assert balance(u) == 0


def test_finance_role_is_scoped():
    fa = new_user('analyst')
    with su() as s:
        s.q("insert into public.platform_roles (user_id, role) values (%s, 'fraud_analyst') returning user_id", fa)
    with db.session(user=fa) as s:
        assert isinstance(s.rpc('admin_review_queue'), list)
        assert denied(lambda: s.rpc('admin_adjust_points', user=fa, amount=50, reason='self')).code == 'FORBIDDEN'


def test_history_is_append_only_even_for_the_owner():
    u = new_user(); scan(u, qr_url(2), *branch_pos(2))
    with db.session(user=ADMIN) as s:
        s.rpc('admin_set_config', key='points.daily_cap', value=1600, reason='make an audit row')
    with su() as s:
        for sql in ['update public.ledger_entries set amount = amount * 10', 'delete from public.ledger_tx',
                    'delete from public.audit_log', 'update public.audit_log set reason = null',
                    'truncate public.ledger_entries cascade', 'truncate public.audit_log']:
            with pytest.raises(psycopg.errors.RaiseException):
                s.q(sql)


def test_config_change_is_audited():
    with db.session(user=ADMIN) as s:
        s.rpc('admin_set_config', key='points.daily_cap', value=2000, reason='Ramadan event')
    with su() as s:
        before, after, reason = s.one("select before, after, reason from public.audit_log where action = 'config_changed'")
    assert before == 1500 and after == 2000 and reason == 'Ramadan event'


def test_economy_coverage_ratio():
    with db.session(user=ADMIN) as s:
        e = s.rpc('admin_economy')
    assert e['outstanding_points'] == 1250 and e['store_value_points'] > 0
    assert e['coverage_ratio'] > 1.2 and e['alert'] is False


def test_signed_out_visitor_can_browse_but_not_hunt():
    with db.session() as s:
        assert isinstance(s.rpc('discover_picks', lat=33.4262, lng=43.3001), list)
        denied(lambda: s.rpc('start_hunt', spot_id=spot_of(2), lat=33.42, lng=43.29, accuracy=10))
