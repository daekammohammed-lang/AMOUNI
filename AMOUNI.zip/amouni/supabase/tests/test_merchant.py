"""Merchant platform: onboarding, staff, campaigns + billing, analytics; discovery."""
import pytest
import db
from conftest import *


def test_merchant_onboarding_needs_approval_before_going_live():
    owner = new_user('صاحب محل')
    lat, lng = branch_pos(1)
    with db.session(user=owner) as s:
        app = s.rpc('merchant_apply', name='كافيه النخيل', category='coffee', city=CITY, branch_name='الفرع الرئيسي', lat=lat + 0.002, lng=lng)
        assert app['status'] == 'pending'
        qr = s.rpc('qr_create', branch=app['branch_id'], label='الكاشير')
        assert qr['url'].startswith('https://amouni.app/q/') and qr['short_code'].startswith('AM-')
    with db.session(user=ADMIN) as s:
        s.rpc('admin_merchant_decide', merchant=app['merchant_id'], approve=True, reason='verified', plan='basic')
        sid = s.rpc('admin_spot_create', branch=app['branch_id'], title='لقطة النخيل', kind='normal', base_points=70)
    u = new_user()
    r = scan(u, qr['url'], lat + 0.002, lng)
    assert r['code'] == 'OK' and r['spot']['id'] == str(sid)


def test_staff_roles():
    cashier = new_user('كاشير')
    with su() as s:
        phone = s.one('select phone from public.profiles where id = %s', cashier)
    with db.session(user=OWNER) as s:
        s.rpc('merchant_add_staff', merchant=M(1), phone=phone, role='cashier', branch=B(1))
        assert s.rpc('merchant_add_staff', merchant=M(1), phone='+964000000', role='cashier') == {'ok': True}  # no enumeration
    with db.session(user=cashier) as s:
        with pytest.raises(db.AmouniError):
            s.rpc('cashier_token', branch=B(1))                          # not active until accepted
        s.rpc('merchant_accept_invite', merchant=M(1))
        assert s.rpc('cashier_token', branch=B(1))['url'].startswith('https://amouni.app/d/')
        for fn, kw in [('qr_create', dict(branch=B(1))), ('merchant_stats', dict(merchant=M(1))),
                       ('merchant_add_staff', dict(merchant=M(1), phone='+1', role='manager'))]:
            with pytest.raises(db.AmouniError) as e:
                s.rpc(fn, **kw)
            assert e.value.code == 'FORBIDDEN', fn
        with pytest.raises(db.AmouniError):
            s.rpc('cashier_token', branch=B(2))                      # other merchant's branch


def test_campaign_lifecycle_funding_attribution_and_billing():
    with db.session(user=OWNER) as s:
        est = s.rpc('campaign_estimate', merchant=M(6), radius_km=2, days=7, bonus=150)
        assert est['low'] <= est['high']
        cid = s.rpc('campaign_save', merchant=M(6), draft={'name': 'زبائن جدد للصالون', 'goal_type': 'new_visits', 'goal_visits': 10,
                                                           'bonus_points': 150, 'budget_iqd': 30000, 'radius_km': 2})
        s.rpc('campaign_submit', campaign=cid)
    with db.session(user=OWNER) as s, pytest.raises(db.AmouniError) as e:   # merchants cannot approve themselves
        s.rpc('admin_campaign_decide', campaign=cid, approve=True, reason='x')
    assert e.value.code == 'FORBIDDEN'
    with db.session(user=ADMIN) as s:
        assert s.rpc('admin_campaign_decide', campaign=cid, approve=True, reason='ok')['points_funded'] == 1500

    u = new_user()
    lat, lng = branch_pos(6)
    h = hunt(u, spot_of(6), lat, lng)
    assert any(l['kind'] == 'campaign' and l['points'] == 150 for l in h['quote']['lines'])
    r = scan(u, qr_url(6), lat, lng, nonce=h['nonce'])
    assert r['code'] == 'OK' and r['points'] == 60 + 150 + 100
    with su() as s:
        assert s.one('select generated_visits, spent_iqd from public.campaigns where id = %s', cid) == (1, 1500)
        assert s.one('select count(*) from public.merchant_charges where campaign_id = %s', cid) == 1
        assert s.one("select balance from public.wallets where kind = 'campaign' and owner_id = %s", cid) == 1500 - 150
    with db.session(user=OWNER) as s:
        st = s.rpc('merchant_stats', merchant=M(6), days=7)
    assert st['generated_visits'] == 1 and st['campaign_cost_iqd'] == 1500 and st['cost_per_generated_visit_iqd'] == 1500
    assert st['estimated_revenue_iqd'] == 12000
    ledger_ok()


def test_campaign_completes_at_goal_and_returns_unused_points():
    with db.session(user=OWNER) as s:
        cid = s.rpc('campaign_save', merchant=M(6), draft={'name': 'حملة قصيرة', 'goal_type': 'new_visits', 'goal_visits': 10,
                                                           'bonus_points': 100, 'budget_iqd': 1500 * 2})
        s.rpc('campaign_submit', campaign=cid)
    with db.session(user=ADMIN) as s:
        s.rpc('admin_campaign_decide', campaign=cid, approve=True, reason='ok')
    lat, lng = branch_pos(6)
    for i in range(3):
        u = new_user(f'c{i}')
        h = hunt(u, spot_of(6), lat, lng)
        scan(u, qr_url(6), lat, lng, nonce=h['nonce'])
    with su() as s:
        status, gen, spent = s.one('select status, generated_visits, spent_iqd from public.campaigns where id = %s', cid)
        assert status == 'completed' and spent <= 3000
        assert s.one("select balance from public.wallets where kind = 'campaign' and owner_id = %s", cid) == 0
    ledger_ok()


def test_staff_visits_are_never_generated():
    with su() as s:
        s.q('update public.profiles set created_at = now() - interval \'10 days\' where id = %s returning id', OWNER)
    lat, lng = branch_pos(2)
    h = hunt(OWNER, spot_of(2), lat, lng)
    scan(OWNER, qr_url(2), lat, lng, nonce=h['nonce'])
    with su() as s:
        assert s.one('select generated from public.visits where user_id = %s', OWNER) is False


# ---------------- discovery ----------------
def test_picks_are_three_distinct_merchants_with_reasons():
    u = new_user()
    lat, lng = branch_pos(1)
    with db.session(user=u) as s:
        picks = s.rpc('discover_picks', lat=lat, lng=lng)
    assert 1 <= len(picks) <= 3
    names = [p['merchant'] for p in picks]
    assert len(set(names)) == len(names)
    assert all(p['reason']['code'] in ('near', 'hot', 'new_category', 'you_like', 'points') for p in picks)


def test_mystery_spot_never_reveals_the_shop():
    with db.session() as s:                                   # anonymous visitor
        cards = s.rpc('discover_map', lat=33.4262, lng=43.3001, radius_km=10)
    m = next(c for c in cards if c['kind'] == 'mystery')
    assert m['merchant'] is None and m['branch'] is None and m['circle_m'] == 150
    lat, lng = branch_pos(11)
    from math import dist
    assert dist((m['lat'], m['lng']), (lat, lng)) > 0.0001     # circle centre is not the shop


def test_found_and_cooldown_spots_leave_discovery():
    u = new_user()
    lat, lng = branch_pos(2)
    scan(u, qr_url(2), lat, lng)
    with db.session(user=u) as s:
        cards = s.rpc('discover_map', lat=lat, lng=lng, radius_km=10)
    assert all(c['merchant'] != 'مطعم بيت الكص' for c in cards)
