import json, math, uuid, threading
import psycopg, pytest
import db

TEMPLATE = 'amouni_tpl'
CITY = '00000000-0000-4000-8000-000000000001'
OWNER = '00000000-0000-4000-8002-000000000002'      # owns every seeded merchant
ADMIN = '00000000-0000-4000-8002-000000000003'      # super_admin
B = lambda n: f'00000000-0000-4000-8004-{n:012d}'   # seeded branch n
M = lambda n: f'00000000-0000-4000-8003-{n:012d}'   # seeded merchant n


@pytest.fixture(scope='session', autouse=True)
def template():
    db.DB = TEMPLATE
    db.rebuild()
    yield


@pytest.fixture(autouse=True)
def fresh_db(request):
    name = 'amouni_t_' + uuid.uuid4().hex[:8]
    with psycopg.connect(db.DSN_ADMIN + ' dbname=postgres', autocommit=True) as c:
        c.execute(f'create database {name} template {TEMPLATE}')
    db.DB = name
    yield
    with psycopg.connect(db.DSN_ADMIN + ' dbname=postgres', autocommit=True) as c:
        c.execute(f'drop database if exists {name} with (force)')


# ---------------- helpers ----------------
def su():
    return db.superuser()


def new_user(name='مستخدم', age_hours=72, phone=None):
    uid = str(uuid.uuid4())
    phone = phone or '+96477' + uuid.uuid4().hex[:8]
    with su() as s:
        s.q('insert into auth.users (id, phone) values (%s, %s) returning id', uid, phone)
        s.q("update public.profiles set display_name = %s, city_id = %s, created_at = now() - make_interval(hours => %s) where id = %s returning id",
            name, CITY, age_hours, uid)
    return uid


def branch_pos(n):
    with su() as s:
        lat, lng = s.one('select extensions.st_y(location::extensions.geometry), extensions.st_x(location::extensions.geometry) from public.branches where id = %s', B(n))
    return lat, lng


def offset(lat, lng, north_m=0.0, east_m=0.0):
    return lat + north_m / 111_320.0, lng + east_m / (111_320.0 * math.cos(math.radians(lat)))


def spot_of(n, kind=None):
    with su() as s:
        if kind:
            return str(s.one('select id from public.spots where branch_id = %s and kind = %s', B(n), kind))
        return str(s.one('select id from public.spots where branch_id = %s order by created_at limit 1', B(n)))


def qr_url(n):
    with su() as s:
        return s.one("select private.qr_url(id) from public.qr_codes where branch_id = %s and status = 'active' order by created_at limit 1", B(n))


def short_code(n):
    with su() as s:
        return str(s.one("select short_code::text from public.qr_codes where branch_id = %s and status = 'active' order by created_at limit 1", B(n)))


def balance(uid, kind='user_available'):
    with su() as s:
        return s.one('select balance from public.wallets where kind = %s and owner_id = %s', kind, uid) or 0


def scan(uid, payload, lat, lng, acc=20.0, idem=None, nonce=None, fp=None, flags=None):
    with db.session(role='service_role') as s:
        return s.rpc('scan_v1', user=uid, payload=payload, lat=lat, lng=lng, accuracy=acc,
                     idem=idem or uuid.uuid4().hex, nonce=nonce, device_fp=fp or ('dev-' + uid), platform='web',
                     ip=None, flags=flags or {})


def hunt(uid, spot, lat, lng, acc=20.0):
    with db.session(user=uid) as s:
        return s.rpc('start_hunt', spot_id=spot, lat=lat, lng=lng, accuracy=acc, device_fp='dev-' + uid)


def parallel(fns):
    out = [None] * len(fns); start = threading.Barrier(len(fns))
    def run(i, f):
        start.wait()
        try: out[i] = f()
        except Exception as e: out[i] = e
    ts = [threading.Thread(target=run, args=(i, f)) for i, f in enumerate(fns)]
    [t.start() for t in ts]; [t.join() for t in ts]
    return out


def ledger_ok():
    """The two invariants that must hold after every test."""
    with su() as s:
        unbalanced = s.one('select count(*) from (select tx_id from public.ledger_entries group by tx_id having sum(amount) <> 0) x')
        total = s.one('select coalesce(sum(balance), 0) from public.wallets')
        drift = s.one('''select count(*) from public.wallets w
                         where w.balance <> coalesce((select sum(amount) from public.ledger_entries e where e.wallet_id = w.id), 0)''')
    assert unbalanced == 0, 'a ledger transaction does not sum to zero'
    assert total == 0, f'wallet balances sum to {total}, expected 0'
    assert drift == 0, 'a wallet balance differs from its ledger'
