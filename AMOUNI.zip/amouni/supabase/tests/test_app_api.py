"""Read models used by the apps, and the AI recommendation layer."""
import pytest
import db
from conftest import *


def test_roles_profile_bag_history_notifications():
    u = new_user('سارة علي')
    lat, lng = branch_pos(1)
    h = hunt(u, spot_of(1), lat, lng)
    with db.session(user=u) as s:
        assert s.rpc('my_active_hunt')['hunt_id'] == h['hunt_id']
    scan(u, qr_url(1), lat, lng, nonce=h['nonce'])
    with db.session(user=u) as s:
        roles = s.rpc('my_roles')
        assert roles['profile_complete'] and roles['merchants'] == [] and roles['platform_roles'] == []
        p = s.rpc('my_profile')
        assert p['wallet']['available'] > 0 and p['stats']['visits'] == 1 and p['streak']['days'] == 1
        assert p['level']['name_ar'] == 'مبتدئ' and 0 <= p['level']['pct'] <= 100
        bag = s.rpc('my_bag')
        assert bag[0]['title_ar'] == 'إسبريسو مجاني' and bag[0]['merchant'] == 'كافيه الفرات'
        hist = s.rpc('my_scans')
        assert hist[0]['code'] == 'OK' and hist[0]['merchant'] == 'كافيه الفرات'
        assert s.rpc('my_active_hunt') is None
        store = s.rpc('store_list', lat=lat, lng=lng)
        assert len(store) == 7 and all('value_iqd' not in x for x in store)


def test_notifications_read_flow():
    u = new_user()
    r = scan(u, qr_url(2), *branch_pos(2), flags={'mock_location': True, 'vpn': True})
    with db.session(user=ADMIN) as s:
        s.rpc('admin_resolve_scan', scan=r['scan_id'], approve=True, reason='ok after check')
    with db.session(user=u) as s:
        n = s.rpc('my_notifications')
        assert n['unread'] == 1 and n['items'][0]['kind'] == 'scan_resolved'
        s.rpc('notification_read')
        assert s.rpc('my_notifications')['unread'] == 0


def test_merchant_read_models_and_roles():
    with db.session(user=OWNER) as s:
        roles = s.rpc('my_roles')
        assert len(roles['merchants']) == 11
        home = s.rpc('merchant_home', merchant=M(1))
        assert home['role'] == 'owner' and home['branches'][0]['cashier_mode'] is True
        qrs = s.rpc('merchant_qr_list', merchant=M(1))
        assert qrs[0]['url'].startswith('https://amouni.app/q/')
        assert isinstance(s.rpc('merchant_rewards', merchant=M(1)), list)
        assert s.rpc('merchant_team', merchant=M(1))[0]['role'] == 'owner'
        assert s.rpc('merchant_billing', merchant=M(1))['month_charges_iqd'] == 0
    stranger = new_user()
    with db.session(user=stranger) as s:
        for fn in ('merchant_home', 'merchant_qr_list', 'merchant_campaigns', 'merchant_team', 'merchant_billing', 'merchant_recent_visits'):
            with pytest.raises(db.AmouniError):
                s.rpc(fn, merchant=M(1))


def test_cashier_sees_only_their_branch():
    c = new_user('كاشير')
    with su() as s:
        s.q("insert into public.merchant_members (merchant_id, user_id, role, branch_id) values (%s, %s, 'cashier', %s) returning user_id", M(1), c, B(1))
    with db.session(user=c) as s:
        home = s.rpc('merchant_home', merchant=M(1))
        assert home['role'] == 'cashier' and home['settings'] is None and len(home['branches']) == 1
        with pytest.raises(db.AmouniError):
            s.rpc('merchant_qr_list', merchant=M(1))


def test_admin_read_models():
    with db.session(user=ADMIN) as s:
        assert len(s.rpc('admin_users', q='')) >= 3
        assert len(s.rpc('admin_merchants')) == 11
        assert isinstance(s.rpc('admin_campaigns'), list)
        assert any(r['suggested_points'] for r in s.rpc('admin_rewards'))
        assert len(s.rpc('admin_spots')) == 11
        ms = s.rpc('admin_missions'); assert len(ms) == 2
        s.rpc('admin_mission_update', mission=ms[0]['id'], active=False, reward_points=200)
        assert s.rpc('admin_audit')[0]['action'] == 'mission_updated'
        an = s.rpc('admin_analytics', days=7)
        assert 'dau' in an and len(an['series']) == 7
        assert 'pending_review' in s.rpc('admin_health')
        assert len(s.rpc('admin_config')) > 20
    with db.session(user=new_user()) as s, pytest.raises(db.AmouniError):
        s.rpc('admin_analytics')


def test_ai_quiet_place_proposal_is_rule_checked_and_capped():
    # Give branch 7 a usual flow at this hour for the past two weeks, and nothing in the last hour.
    people = [new_user(f'v{i}') for i in range(14)]
    with su() as s:
        for g, uid in enumerate(people, start=1):
            s.q("""insert into public.scans (idempotency_key, user_id, spot_id, branch_id, decision, result_code, points, created_at)
                   values ('hist' || %s, %s, %s, %s, 'valid', 'OK', 0, now() - make_interval(days => %s) + interval '1 minute') returning id""",
                g, uid, spot_of(7), B(7), g)
        s.q("""insert into public.visits (scan_id, user_id, branch_id, merchant_id, spot_id, generated, verified_at)
               select id, user_id, branch_id, %s, spot_id, false, created_at from public.scans where idempotency_key like 'hist%%'
               returning id""", M(7))
    with db.session(role='service_role') as s:
        assert s.rpc('job_ai_suggest') >= 1
    with db.session(user=ADMIN) as s:
        props = [p for p in s.rpc('admin_ai_list') if p['kind'] == 'traffic_balance' and p['subject_id'] == spot_of(7)]
        assert len(props) == 1
        chk = s.rpc('admin_ai_decide', id=props[0]['id'], apply=True)
        assert chk['ok'] and chk['amount'] == 50
    u = new_user()
    h = hunt(u, spot_of(7), *branch_pos(7))
    assert any(l['kind'] == 'quiet_place' and l['points'] == 50 for l in h['quote']['lines'])
    with db.session(user=OWNER) as s:
        assert any(t['kind'] == 'traffic_balance' for t in s.rpc('merchant_tips', merchant=M(7)))
    ledger_ok()


def test_ai_respects_daily_budget():
    with su() as s:
        s.q("update private.config set value = '10' where key = 'ai.daily_boost_points' returning key")
        rid = s.one("""insert into public.ai_recommendations (kind, subject_type, subject_id, payload)
                       values ('traffic_balance', 'spot', %s, jsonb_build_object('merchant_id', %s::text, 'amount', 50, 'hours', 2)) returning id""",
                    spot_of(5), M(5))
    with db.session(user=ADMIN) as s:
        chk = s.rpc('admin_ai_decide', id=str(rid), apply=True)
    assert chk['ok'] is False
    with su() as s:
        assert s.one("select count(*) from public.boosts where kind = 'quiet_place'") == 0
