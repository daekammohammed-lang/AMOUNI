// POST /functions/v1/scan
// The only way to turn a QR scan into points. Authenticates the user, validates input,
// rate-limits by IP, evaluates edge-only risk signals, then runs the database transaction.
import { z } from 'npm:zod@3';
import { clientIp, dbErrorCode, preflight, reply, requireUser, serviceClient } from '../_shared/http.ts';
import { evaluateRisk } from '../_shared/risk.ts';

const Body = z.object({
  payload: z.string().min(1).max(200),                         // scanned text or typed short code
  lat: z.number().min(-90).max(90).nullable(),
  lng: z.number().min(-180).max(180).nullable(),
  accuracy: z.number().min(0).max(10_000).nullable(),
  nonce: z.string().max(64).optional(),
  device_fp: z.string().min(8).max(200),
  platform: z.enum(['web', 'ios', 'android']).default('web'),
  attestation: z.string().max(10_000).optional(),
  mock_location: z.boolean().optional(),
}).refine((b) => (b.lat === null) === (b.lng === null), { message: 'lat and lng go together' });

const IP_LIMIT_PER_MIN = Number(Deno.env.get('SCAN_IP_LIMIT_PER_MIN') ?? 60);

Deno.serve(async (req) => {
  const pf = preflight(req); if (pf) return pf;
  if (req.method !== 'POST') return reply(req, { code: 'BAD_REQUEST' });

  const userId = await requireUser(req);
  if (!userId) return reply(req, { code: 'UNAUTHENTICATED' });

  const idem = req.headers.get('idempotency-key') ?? '';
  if (!/^[A-Za-z0-9_-]{8,100}$/.test(idem)) return reply(req, { code: 'BAD_REQUEST', params: { field: 'Idempotency-Key' } });

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return reply(req, { code: 'BAD_REQUEST' });
  const b = parsed.data;

  const db = serviceClient();
  const ip = clientIp(req);
  if (ip) {
    const { data: ok } = await db.rpc('edge_rate_ok', { p_key: `ip:${ip}`, p_limit: IP_LIMIT_PER_MIN, p_window_seconds: 60 });
    if (ok === false) return reply(req, { code: 'RATE_LIMITED' });
  }

  const flags = await evaluateRisk({ ip, platform: b.platform, attestation: b.attestation, mockLocation: b.mock_location });

  const { data, error } = await db.rpc('scan_v1', {
    p_user: userId, p_payload: b.payload, p_lat: b.lat, p_lng: b.lng, p_accuracy: b.accuracy,
    p_idem: idem, p_nonce: b.nonce ?? null, p_device_fp: b.device_fp, p_platform: b.platform,
    p_ip: ip, p_flags: flags,
  });
  if (error) {
    console.error('scan_v1', error.message);
    return reply(req, { code: dbErrorCode(error) });
  }
  return reply(req, data as Record<string, unknown>);
});
