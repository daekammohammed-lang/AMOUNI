// Signals that only the API layer can evaluate. Each one becomes a flag passed to
// scan_v1, where it is weighted like every other trust signal (never a ban by itself).

export type Platform = 'web' | 'ios' | 'android';

export interface RiskInput {
  ip: string | null;
  platform: Platform;
  attestation?: string;          // Play Integrity token (Android) or App Attest assertion (iOS)
  mockLocation?: boolean;        // reported by the native location API (Android isFromMockProvider / iOS sourceInformation)
}

export interface RiskFlags {
  vpn: boolean;
  mock_location: boolean;
  integrity_failed: boolean;
}

/** VPN / hosting detection via an IP-intelligence provider (optional; off when no key is configured). */
async function isVpnOrHosting(ip: string | null): Promise<boolean> {
  const token = Deno.env.get('IPINFO_TOKEN');
  if (!ip || !token) return false;
  try {
    const res = await fetch(`https://ipinfo.io/${encodeURIComponent(ip)}/privacy?token=${token}`, { signal: AbortSignal.timeout(800) });
    if (!res.ok) return false;
    const p = await res.json();
    return Boolean(p.vpn || p.proxy || p.hosting || p.tor);
  } catch {
    return false;                // never block a scan because a third party is slow
  }
}

/**
 * Device integrity. Phase 2 (native apps) wires Google Play Integrity and Apple App Attest here.
 * Until then web scans carry no attestation and get no penalty for it; the native app
 * will REQUIRE a valid token, and a failed one adds the device_integrity_fail signal.
 */
async function integrityFailed(platform: Platform, attestation?: string): Promise<boolean> {
  if (platform === 'web') return false;
  if (!attestation) return true;
  const verifier = platform === 'android' ? Deno.env.get('PLAY_INTEGRITY_VERIFIER_URL') : Deno.env.get('APP_ATTEST_VERIFIER_URL');
  if (!verifier) return false;   // not configured yet → do not punish users for our missing setup
  try {
    const res = await fetch(verifier, { method: 'POST', body: JSON.stringify({ token: attestation }), signal: AbortSignal.timeout(1500) });
    if (!res.ok) return false;
    const v = await res.json();
    return v.verdict !== 'ok';
  } catch {
    return false;
  }
}

export async function evaluateRisk(input: RiskInput): Promise<RiskFlags> {
  const [vpn, integrity] = await Promise.all([isVpnOrHosting(input.ip), integrityFailed(input.platform, input.attestation)]);
  return { vpn, mock_location: Boolean(input.mockLocation), integrity_failed: integrity };
}
