import { createClient, type SupabaseClient } from 'npm:@supabase/supabase-js@2';
import { httpStatus, message } from './result_codes.ts';

const CORS = {
  'Access-Control-Allow-Origin': Deno.env.get('APP_ORIGIN') ?? '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, idempotency-key, accept-language',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};

export function preflight(req: Request): Response | null {
  return req.method === 'OPTIONS' ? new Response('ok', { headers: CORS }) : null;
}

export function reply(req: Request, body: Record<string, unknown>): Response {
  const code = String(body.code ?? 'INTERNAL');
  const locale = (req.headers.get('accept-language') ?? 'ar').startsWith('en') ? 'en' : 'ar';
  const params = { ...(body.params as Record<string, unknown> ?? {}), points: body.points };
  return new Response(JSON.stringify({ ...body, message: message(code, params, locale) }), {
    status: httpStatus(code),
    headers: { ...CORS, 'content-type': 'application/json; charset=utf-8' },
  });
}

/** Service-role client: bypasses RLS, used only after the caller is authenticated. */
export function serviceClient(): SupabaseClient {
  return createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

/** Verifies the user's JWT with Supabase Auth and returns the user id. */
export async function requireUser(req: Request): Promise<string | null> {
  const auth = req.headers.get('authorization');
  if (!auth?.startsWith('Bearer ')) return null;
  const client = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
    global: { headers: { Authorization: auth } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await client.auth.getUser();
  return error || !data.user ? null : data.user.id;
}

export function clientIp(req: Request): string | null {
  const xf = req.headers.get('x-forwarded-for');
  const ip = xf?.split(',')[0]?.trim() || req.headers.get('cf-connecting-ip') || null;
  return ip && /^[0-9a-fA-F:.]{3,45}$/.test(ip) ? ip : null;
}

/** Maps `AMOUNI:<CODE>` exceptions raised by database functions to a result code. */
export function dbErrorCode(err: { message?: string } | null): string {
  const m = err?.message ?? '';
  const hit = m.match(/AMOUNI:([A-Z_]+)/);
  return hit ? hit[1] : 'INTERNAL';
}
