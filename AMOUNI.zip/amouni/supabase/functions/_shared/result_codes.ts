// Single source of truth for result codes and the copy users see.
// Rejection messages never reveal which risk signal triggered.

export type ResultCode =
  | 'OK' | 'HELD' | 'STEP_UP' | 'REVIEW' | 'REJECTED'
  | 'QR_UNKNOWN' | 'QR_EXPIRED' | 'DYNAMIC_STALE' | 'DYNAMIC_REQUIRED' | 'SPOT_CLOSED' | 'SOLD_OUT'
  | 'ALREADY_FOUND' | 'PLACE_COOLDOWN' | 'TOO_FAR' | 'NO_LOCATION' | 'DAILY_LIMIT' | 'ACCOUNT_LIMITED'
  | 'REPLAY' | 'RATE_LIMITED' | 'STEP_UP_EXPIRED' | 'NOT_PENDING'
  | 'BAD_REQUEST' | 'UNAUTHENTICATED' | 'FORBIDDEN' | 'INTERNAL';

type Copy = { ar: string; en: string; ku?: string };

export const MESSAGES: Record<ResultCode, Copy> = {
  OK:               { ar: 'لكيتها! +{points} نقطة', en: 'Found it! +{points} points' },
  HELD:             { ar: 'لكيتها! النقاط تتثبت خلال 24 ساعة', en: 'Found it! Points confirm within 24 hours' },
  STEP_UP:          { ar: 'خطوة أخيرة: امسح شاشة الكاشير حتى نثبتها', en: 'One last step: scan the cashier screen to confirm' },
  REVIEW:           { ar: 'نتأكد من مسحك، نبلغك قريباً', en: "We're checking your scan and will notify you soon" },
  REJECTED:         { ar: 'ما كدرنا نتأكد من هالمسح', en: "We couldn't verify this scan" },
  QR_UNKNOWN:       { ar: 'هذا مو باركود AMOUNI', en: 'This is not an AMOUNI code' },
  QR_EXPIRED:       { ar: 'هذا الباركود انتهى، دوّر على الجديد بالمحل', en: 'This code has expired — look for the new one in the shop' },
  DYNAMIC_STALE:    { ar: 'امسح الشاشة مرة ثانية', en: 'Scan the screen again' },
  DYNAMIC_REQUIRED: { ar: 'هاي الفرصة تنمسح من شاشة الكاشير بس', en: 'This one is scanned from the cashier screen only' },
  SPOT_CLOSED:      { ar: 'هاي الفرصة مو شغّالة هسه', en: "This spot isn't active right now" },
  SOLD_OUT:         { ar: 'خلصت. أكو فرصة ثانية قريبة', en: "It's gone. There's another one nearby" },
  ALREADY_FOUND:    { ar: 'لكيتها قبل. دوّر على فرصة جديدة', en: 'Already found. Look for a new one' },
  PLACE_COOLDOWN:   { ar: 'ارجعله بعد {days_left} يوم', en: 'Come back in {days_left} days' },
  TOO_FAR:          { ar: 'لازم تكون داخل المحل', en: 'You need to be inside the place' },
  NO_LOCATION:      { ar: 'فعّل الموقع بس وقت المسح', en: 'Turn on location for the scan' },
  DAILY_LIMIT:      { ar: 'وصلت لحدّ اليوم، ارجع باچر', en: "You've reached today's limit — come back tomorrow" },
  ACCOUNT_LIMITED:  { ar: 'حسابك تحت المراجعة. تواصل ويانا', en: 'Your account is under review. Contact us' },
  REPLAY:           { ar: 'ابدأ اللقطة من جديد', en: 'Start the hunt again' },
  RATE_LIMITED:     { ar: 'شوية شوية! جرّب بعد دقيقة', en: 'Slow down — try again in a minute' },
  STEP_UP_EXPIRED:  { ar: 'انتهى وقت التأكيد، نراجع مسحك يدوياً', en: 'Confirmation window ended; we will review manually' },
  NOT_PENDING:      { ar: 'هذا المسح مو بانتظار تأكيد', en: 'This scan is not awaiting confirmation' },
  BAD_REQUEST:      { ar: 'صار خطأ بالطلب', en: 'Bad request' },
  UNAUTHENTICATED:  { ar: 'سجّل دخولك أولاً', en: 'Please sign in' },
  FORBIDDEN:        { ar: 'ما عندك صلاحية', en: 'Not allowed' },
  INTERNAL:         { ar: 'صار خلل، جرّب مرة ثانية', en: 'Something went wrong, try again' },
};

export function message(code: string, params: Record<string, unknown> = {}, locale: 'ar' | 'en' = 'ar'): string {
  const copy = MESSAGES[code as ResultCode] ?? MESSAGES.INTERNAL;
  return (copy[locale] ?? copy.ar).replace(/\{(\w+)\}/g, (_, k) => String(params[k] ?? ''));
}

// HTTP status for a scan result. Business outcomes are 200; only transport problems are errors.
export function httpStatus(code: string): number {
  switch (code) {
    case 'BAD_REQUEST': return 400;
    case 'UNAUTHENTICATED': return 401;
    case 'FORBIDDEN': return 403;
    case 'RATE_LIMITED': return 429;
    case 'INTERNAL': return 500;
    default: return 200;
  }
}
