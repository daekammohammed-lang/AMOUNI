import { strict as assert } from 'node:assert';
const assertEquals = (a: unknown, b: unknown) => assert.deepStrictEqual(a, b);
import { httpStatus, message, MESSAGES } from './result_codes.ts';

Deno.test('every code has Arabic and English copy', () => {
  for (const [code, copy] of Object.entries(MESSAGES)) {
    if (!copy.ar || !copy.en) throw new Error(`missing copy for ${code}`);
  }
});

Deno.test('placeholders are filled', () => {
  assertEquals(message('OK', { points: 280 }), 'لكيتها! +280 نقطة');
  assertEquals(message('PLACE_COOLDOWN', { days_left: 3 }, 'en'), 'Come back in 3 days');
});

Deno.test('business outcomes are HTTP 200, transport problems are not', () => {
  assertEquals(httpStatus('TOO_FAR'), 200);
  assertEquals(httpStatus('RATE_LIMITED'), 429);
  assertEquals(httpStatus('UNAUTHENTICATED'), 401);
});

Deno.test('unknown codes never leak internals', () => {
  assertEquals(message('SOMETHING_ODD'), MESSAGES.INTERNAL.ar);
});
