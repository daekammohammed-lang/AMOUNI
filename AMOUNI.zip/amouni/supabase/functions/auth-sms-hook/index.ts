// Supabase Auth "Send SMS" hook.
// Delivers the login code by WhatsApp first (≈25× cheaper than SMS to Iraq), falls back to SMS.
// In local development (AMOUNI_DEV_OTP_INBOX=true) codes are kept in memory and readable at
// GET /functions/v1/auth-sms-hook?phone=… so the app can show them — never enable that in production.
//
// Configure in Supabase → Auth → Hooks → Send SMS → HTTPS, URL of this function, secret → SEND_SMS_HOOK_SECRET.

const DEV_INBOX = Deno.env.get('AMOUNI_DEV_OTP_INBOX') === 'true';
const inbox = new Map<string, { code: string; at: number }>();

async function verifySignature(req: Request, body: string): Promise<boolean> {
  const secret = Deno.env.get('SEND_SMS_HOOK_SECRET') ?? '';           // "v1,whsec_<base64>"
  const id = req.headers.get('webhook-id'), ts = req.headers.get('webhook-timestamp'), sig = req.headers.get('webhook-signature');
  if (!secret || !id || !ts || !sig) return false;
  if (Math.abs(Date.now() / 1000 - Number(ts)) > 300) return false;   // replayed or very late
  const raw = Uint8Array.from(atob(secret.replace(/^v1,whsec_/, '')), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('raw', raw, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${id}.${ts}.${body}`)));
  const expected = btoa(String.fromCharCode(...mac));
  return sig.split(' ').some((s) => s.split(',')[1] === expected);
}

async function sendWhatsApp(phone: string, code: string): Promise<boolean> {
  const token = Deno.env.get('WHATSAPP_TOKEN'), phoneId = Deno.env.get('WHATSAPP_PHONE_ID');
  const template = Deno.env.get('WHATSAPP_OTP_TEMPLATE') ?? 'amouni_login_code';
  if (!token || !phoneId) return false;
  const res = await fetch(`https://graph.facebook.com/v21.0/${phoneId}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'content-type': 'application/json' },
    body: JSON.stringify({
      messaging_product: 'whatsapp', to: phone, type: 'template',
      template: { name: template, language: { code: 'ar' }, components: [
        { type: 'body', parameters: [{ type: 'text', text: code }] },
        { type: 'button', sub_type: 'url', index: '0', parameters: [{ type: 'text', text: code }] },
      ] },
    }),
    signal: AbortSignal.timeout(5000),
  }).catch(() => null);
  return Boolean(res?.ok);
}

async function sendSms(phone: string, code: string): Promise<boolean> {
  const sid = Deno.env.get('TWILIO_ACCOUNT_SID'), tok = Deno.env.get('TWILIO_AUTH_TOKEN'), from = Deno.env.get('TWILIO_FROM');
  if (!sid || !tok || !from) return false;
  const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: 'POST',
    headers: { Authorization: 'Basic ' + btoa(`${sid}:${tok}`), 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ To: '+' + phone.replace(/^\+/, ''), From: from, Body: `رمز دخول AMOUNI: ${code}` }),
    signal: AbortSignal.timeout(5000),
  }).catch(() => null);
  return Boolean(res?.ok);
}

Deno.serve(async (req) => {
  const url = new URL(req.url);
  if (req.method === 'GET') {
    if (!DEV_INBOX) return new Response('not found', { status: 404 });
    const phone = (url.searchParams.get('phone') ?? '').replace(/\D/g, '');
    const hit = inbox.get(phone);
    return Response.json(hit && Date.now() - hit.at < 10 * 60_000 ? { code: hit.code } : {}, {
      headers: { 'Access-Control-Allow-Origin': '*' },
    });
  }
  const body = await req.text();
  if (!(await verifySignature(req, body))) return new Response(JSON.stringify({ error: { http_code: 401, message: 'bad signature' } }), { status: 401 });

  const { user, sms } = JSON.parse(body) as { user: { phone: string }; sms: { otp: string } };
  const phone = String(user.phone ?? '').replace(/\D/g, '');
  if (DEV_INBOX) {
    inbox.set(phone, { code: sms.otp, at: Date.now() });
    console.log(`[dev otp] ${phone} → ${sms.otp}`);
    return Response.json({});
  }
  if (await sendWhatsApp(phone, sms.otp) || await sendSms(phone, sms.otp)) return Response.json({});
  return new Response(JSON.stringify({ error: { http_code: 500, message: 'could not deliver code' } }), { status: 500 });
});
