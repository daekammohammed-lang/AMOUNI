// POST /functions/v1/step-up
// Confirms a medium-risk scan by scanning the branch's cashier screen within the time window.
import { z } from 'npm:zod@3';
import { dbErrorCode, preflight, reply, requireUser, serviceClient } from '../_shared/http.ts';

const Body = z.object({
  scan_id: z.string().uuid(),
  payload: z.string().min(1).max(200),
  lat: z.number().min(-90).max(90).nullable(),
  lng: z.number().min(-180).max(180).nullable(),
  accuracy: z.number().min(0).max(10_000).nullable(),
}).refine((b) => (b.lat === null) === (b.lng === null), { message: 'lat and lng go together' });

Deno.serve(async (req) => {
  const pf = preflight(req); if (pf) return pf;
  if (req.method !== 'POST') return reply(req, { code: 'BAD_REQUEST' });
  const userId = await requireUser(req);
  if (!userId) return reply(req, { code: 'UNAUTHENTICATED' });

  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return reply(req, { code: 'BAD_REQUEST' });
  const b = parsed.data;

  const { data, error } = await serviceClient().rpc('step_up_v1', {
    p_user: userId, p_scan_id: b.scan_id, p_payload: b.payload, p_lat: b.lat, p_lng: b.lng, p_accuracy: b.accuracy,
  });
  if (error) {
    console.error('step_up_v1', error.message);
    return reply(req, { code: dbErrorCode(error) });
  }
  return reply(req, data as Record<string, unknown>);
});
