-- =====================================================================
-- AMOUNI · Staging seed — Ramadi pilot (fictional businesses).
-- Runs as the database owner. NEVER run against production.
-- Demo phones (staging OTP is configured in Supabase Auth → Phone test numbers):
--   user  علي حسين      9647701234567  (E.164 without +, as Supabase Auth stores it)
--   owner كافيه الفرات  9647801112233
--   admin               9647700000000
-- =====================================================================

insert into public.cities (id, slug, name_ar, name_en, name_ku, centroid, active) values
  ('00000000-0000-4000-8000-000000000001', 'ramadi', 'الرمادي', 'Ramadi', 'ڕومادی',
   extensions.st_setsrid(extensions.st_makepoint(43.3001, 33.4262), 4326)::extensions.geography, true);

insert into public.districts (id, city_id, name_ar, name_en, centroid)
select ('00000000-0000-4000-8001-' || lpad(n::text, 12, '0'))::uuid, '00000000-0000-4000-8000-000000000001', name_ar, name_en,
       extensions.st_setsrid(extensions.st_makepoint(lng, lat), 4326)::extensions.geography
from (values (1,'حي الملعب','Al-Malaab',33.4280,43.3010),(2,'حي الحوز','Al-Hawz',33.4229,43.2957),(3,'شارع 20','20th Street',33.4296,43.2963),
             (4,'حي الأندلس','Al-Andalus',33.4212,43.3079),(5,'حي العزيزية','Al-Aziziya',33.4327,43.3052),(6,'حي المعلمين','Al-Muallimeen',33.4193,43.2926),
             (7,'حي الضباط','Al-Dhubbat',33.4284,43.3117),(8,'حي التأميم','Al-Tameem',33.4157,43.3004),(9,'حي الجمعية','Al-Jamiya',33.4349,43.2911),
             (10,'الكورنيش','Corniche',33.4398,43.3149)) d(n, name_ar, name_en, lat, lng);

-- Demo people
insert into auth.users (id, phone) values
  ('00000000-0000-4000-8002-000000000001', '9647701234567'),
  ('00000000-0000-4000-8002-000000000002', '9647801112233'),
  ('00000000-0000-4000-8002-000000000003', '9647700000000');
-- On a real Supabase Auth schema, make the demo users look exactly like phone sign-ups.
do $$ begin
  if exists (select 1 from information_schema.columns where table_schema = 'auth' and table_name = 'users' and column_name = 'instance_id') then
    execute $q$update auth.users set instance_id = '00000000-0000-0000-0000-000000000000', aud = 'authenticated', role = 'authenticated',
              phone_confirmed_at = now(), created_at = now(), updated_at = now(), raw_app_meta_data = '{"provider":"phone","providers":["phone"]}',
              raw_user_meta_data = '{}', is_sso_user = false,
              confirmation_token = '', recovery_token = '', email_change_token_new = '', email_change = '',
              email_change_token_current = '', phone_change = '', phone_change_token = '', reauthentication_token = ''
            where id in ('00000000-0000-4000-8002-000000000001','00000000-0000-4000-8002-000000000002','00000000-0000-4000-8002-000000000003')$q$;
  end if;
end $$;
update public.profiles set display_name = 'علي حسين', city_id = '00000000-0000-4000-8000-000000000001' where id = '00000000-0000-4000-8002-000000000001';
update public.profiles set display_name = 'مصطفى عادل', city_id = '00000000-0000-4000-8000-000000000001' where id = '00000000-0000-4000-8002-000000000002';
update public.profiles set display_name = 'مكارم', city_id = '00000000-0000-4000-8000-000000000001' where id = '00000000-0000-4000-8002-000000000003';
insert into public.platform_roles (user_id, role) values ('00000000-0000-4000-8002-000000000003', 'super_admin');

-- Merchants, branches, spots
do $$
declare
  r record; mid uuid; bid uuid; sid uuid; rid uuid;
  owner uuid := '00000000-0000-4000-8002-000000000002';
  city uuid := '00000000-0000-4000-8000-000000000001';
begin
  for r in select * from (values
    (1,'كافيه الفرات','coffee',33.4271,43.3024,1,'silver','لقطة القهوة الأولى','normal',60,null::int,'إسبريسو مجاني','time',100,'{"from":"15:00","to":"18:00"}','على الكاونتر جنب ماكينة القهوة', 60, 40),
    (2,'مطعم بيت الكص','food',33.4229,43.2957,2,'gold','لقطة الغداء','normal',80,null,null,'new_customer',100,'{}','قرب باب المطبخ', 60, 60),
    (3,'حلويات الأنبار','sweets',33.4296,43.2963,3,'basic','ساعة الحلو','normal',50,null,'قطعة كنافة',null,null,'{}','على الثلاجة الزجاجية', 60, 30),
    (4,'مول الرمادي سنتر','mall',33.4212,43.3079,4,'gold','Golden Drop — مول الرمادي','golden_drop',500,10,'سماعات لاسلكية',null,null,'{}','بالطابق الأرضي قرب النافورة', 120, 200),
    (5,'نادي القوة الرياضي','fitness',33.4327,43.3052,5,'basic','لقطة التمرين','normal',70,null,null,'new_customer',80,'{}','قرب الاستقبال', 60, 40),
    (6,'صالون لمسة','beauty',33.4193,43.2926,6,'basic','لقطة الإطلالة','normal',60,null,null,null,null,'{}','جنب المراية الكبيرة', 60, 15),
    (7,'مكتبة دار المعرفة','books',33.4284,43.3117,7,'basic','لقطة القارئ','normal',40,null,null,'time',60,'{"from":"10:00","to":"13:00"}','بين رف الروايات والكاشير', 60, 25),
    (8,'برگر ستريت','food',33.4157,43.3004,8,'silver','First Finder — برگر ستريت','first_finder',150,5,'برگر كلاسيك',null,null,'{}','على شاشة الطلبات', 60, 50),
    (9,'عصائر الواحة','juice',33.4349,43.2911,9,'basic','لقطة الانتعاش','normal',40,null,null,'time',50,'{"from":"14:00","to":"17:00"}','تحت قائمة العصائر', 60, 30),
    (10,'فن زون للألعاب','fun',33.4398,43.3149,10,'silver','لقطة اللعب','normal',90,null,null,'new_customer',120,'{}','عند باب صالة الألعاب', 80, 80),
    (11,'بيت الشاي البغدادي','coffee',33.4318,43.2975,1,'basic','فرصة مخفية','mystery',200,null,'استكان شاي + كليجة',null,null,'{}','على الجدار جنب الشبّاك', 60, 30)
  ) v(n, name, cat, lat, lng, dist, plan, title, kind, pts, qty, instant, boost, boost_amt, boost_rule, hint, geofence, capacity)
  loop
    mid := ('00000000-0000-4000-8003-' || lpad(r.n::text, 12, '0'))::uuid;
    bid := ('00000000-0000-4000-8004-' || lpad(r.n::text, 12, '0'))::uuid;
    insert into public.merchants (id, display_name, category, status, plan, created_by) values (mid, r.name, r.cat, 'active', r.plan, owner);
    insert into public.merchant_settings (merchant_id, avg_ticket_iqd, cpv_iqd) values (mid, 12000, 1500);
    insert into public.branches (id, merchant_id, city_id, district_id, name, location, geofence_m, capacity, hint_ar, cashier_mode)
    values (bid, mid, city, ('00000000-0000-4000-8001-' || lpad(r.dist::text, 12, '0'))::uuid, r.name,
            extensions.st_setsrid(extensions.st_makepoint(r.lng, r.lat), 4326)::extensions.geography, r.geofence, r.capacity, r.hint, r.kind = 'golden_drop' or r.n = 1);
    insert into private.branch_secrets (branch_id) values (bid);
    insert into public.merchant_members (merchant_id, user_id, role, added_by) values (mid, owner, 'owner', owner);
    perform private.issue_qr(bid, 'الكاشير', 'monthly', null, owner);

    rid := null;
    if r.instant is not null then
      insert into public.rewards (merchant_id, title_ar, value_iqd, stock, validity_days, active)
      values (mid, r.instant, 3000, 200, 14, true) returning id into rid;
    end if;
    insert into public.spots (branch_id, title_ar, kind, base_points, cap_points, instant_reward_id, qty_total, qty_left,
                              requires_dynamic, mystery_radius_m, mystery_center, status, ends_at)
    values (bid, r.title, r.kind, r.pts, case when r.kind = 'golden_drop' then 600 else 500 end, rid, r.qty, r.qty,
            r.kind = 'golden_drop', case when r.kind = 'mystery' then 150 end,
            case when r.kind = 'mystery' then extensions.st_project(extensions.st_setsrid(extensions.st_makepoint(r.lng, r.lat), 4326)::extensions.geography, 60, radians(220)) end,
            'live', case when r.kind in ('golden_drop','first_finder') then now() + interval '6 hours' end)
    returning id into sid;
    if r.boost is not null then
      insert into public.boosts (spot_id, kind, amount, rule, source) values (sid, r.boost, r.boost_amt, r.boost_rule::jsonb, 'merchant');
    end if;
  end loop;
  update public.branches set hours = '{"0":[["16:00","21:00"]],"1":[["16:00","21:00"]],"2":[["16:00","21:00"]],"3":[["16:00","21:00"]],"4":[["16:00","21:00"]],"5":[["16:00","21:00"]],"6":[["16:00","21:00"]]}'
  where id = '00000000-0000-4000-8004-000000000003';
end $$;

-- Points store (priced by AMOUNI)
insert into public.rewards (merchant_id, title_ar, value_iqd, cost_points, stock, validity_days, active) values
  ('00000000-0000-4000-8003-000000000009', 'عصير طبيعي كبير',   3000,  300, 40, 14, true),
  ('00000000-0000-4000-8003-000000000007', 'خصم 25% على الكتب', 3500,  350, 60, 30, true),
  ('00000000-0000-4000-8003-000000000001', 'لاتيه بأي نكهة',    4000,  400, 50, 14, true),
  ('00000000-0000-4000-8003-000000000003', 'علبة حلويات صغيرة', 6000,  600, 25, 14, true),
  ('00000000-0000-4000-8003-000000000005', 'تمرين يوم كامل',    7000,  700, 20, 30, true),
  ('00000000-0000-4000-8003-000000000010', 'ساعة ألعاب',        8000,  800, 30, 30, true),
  ('00000000-0000-4000-8003-000000000002', 'صحن كص عائلي',     16000, 1600, 10, 14, true);

insert into public.missions (code, kind, title_ar, rule, reward_points) values
  ('daily_new_2',  'daily',  'اكتشف مكانين جداد اليوم', '{"metric":"new_merchants","target":2}', 150),
  ('weekly_4',     'weekly', 'زر 4 أماكن هالأسبوع',     '{"metric":"distinct_branches","target":4}', 500);

-- Welcome balance for the demo user (an audited adjustment, like any other).
select private.post_tx('adjust', 'seed', 'welcome-ali',
  jsonb_build_array(jsonb_build_object('wallet', private.wallet('amouni_marketing'), 'amount', -1250),
                    jsonb_build_object('wallet', private.wallet('user_available', '00000000-0000-4000-8002-000000000001'), 'amount', 1250)),
  null, 'staging seed');
